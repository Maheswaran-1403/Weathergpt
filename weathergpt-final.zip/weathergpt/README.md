# WeatherGPT

**Conversational AI for Weather Forecasting, Alerts, and Climate Information**
Smart India Hackathon 2026 prototype.

## Objective

WeatherGPT is a real, end-to-end weather intelligence platform: a React/TypeScript
frontend backed by a Node.js/Express server that talks to live meteorological
APIs (Open-Meteo, IMD/NDMA, ECMWF & GFS model endpoints), grounds a Gemini-based
chatbot in that real data, and never fabricates a weather value, AQI reading, or
official warning it doesn't actually have.

## Zero Fabrication Policy

This is the single most important design rule in the codebase:

> If a live data source fails or is unavailable, WeatherGPT says so
> ("Live weather data is currently unavailable.") — it never invents a
> plausible-looking number to paper over the gap.

Concretely:
- There is no synthetic/estimated weather generator anywhere in the code.
  `fetchWeather()` and `fetchAirQuality()` throw a `WeatherUnavailableError`
  on failure; every API route catches that and returns HTTP 503 with an
  honest message instead of guessed data.
- IMD/NDMA warnings distinguish **official warning found**, **no matching
  official warning found**, and **official warning data unavailable** —
  never collapsed into a false "all clear."
- Gemini is only ever given real, retrieved numbers to talk about, is
  instructed never to invent or declare an official warning, and — if
  `GEMINI_API_KEY` isn't configured — falls back to a plain, non-AI summary
  built from the same real retrieved numbers (clearly labeled as such),
  not a fabricated one.
- NWP model comparisons pull actual named-model output (`ecmwf_ifs025`,
  `gfs_seamless` via Open-Meteo's `models=` parameter) rather than
  presenting a generic blended forecast as if it were a specific model.
- WRF and satellite/radar have no publicly available, zero-credential data
  source, so the app reports "architecturally supported but requires a
  configured provider" instead of faking either.

## Architecture

```
React + TypeScript frontend (Vite)
        |
        v
Node.js / Express backend  (server.ts, server/services/*)
        |
        +-- weatherService.ts   -> Open-Meteo (current/hourly/daily/air quality)
        +-- geocodingService.ts -> Open-Meteo Geocoding
        +-- imdService.ts       -> IMD (api.imd.gov.in, key-gated) + NDMA/Sachet CAP (public)
        +-- nwpService.ts       -> Open-Meteo model-specific endpoints (ECMWF, GFS) + WRF status stub
        +-- climateService.ts   -> Open-Meteo Historical Archive (ERA5-derived)
        +-- geminiService.ts    -> Gemini (chat, briefings) grounded in the above
        +-- advisoryService.ts  -> deterministic agro/decision-support rule engine + Gemini copy
```

All secret-requiring calls happen server-side only. No API key is ever sent
to the browser or to Gemini.

## Features

- Live current/hourly/daily weather, feels-like, humidity, wind, pressure,
  UV, sunrise/sunset, air quality (Open-Meteo).
- Location search, reverse geocoding, favorites/recents (works globally,
  not just Indian cities).
- IMD district warnings + nowcasts, NDMA/Sachet CAP alerts, with distinct
  found / not-found / unavailable states and full source attribution.
- WeatherGPT chatbot grounded in live retrieved data (Gemini), multilingual
  (English, Tamil, Hindi, Telugu, Kannada, Malayalam, Marathi, Bengali),
  with browser-based voice input/output.
- **NWP Models** page: real ECMWF vs GFS comparison table, model agreement
  indicator, and AI interpretation of the retrieved values only.
- Historical climate trends and period-vs-period comparison (Open-Meteo
  Archive / ERA5), always labeled as historical analysis, not prediction.
- Agriculture advisory (rule-based + AI copy) and a general Decision
  Support Center (travel, outdoor activity, aviation/marine indicators —
  advisory language only, never a certified operational claim).
- Weather briefings, dark/light/system theme, mobile-first responsive
  layout, `/api/health` diagnostics that actually pings each provider.

## API Routes

See `server.ts` for the full list, including `/api/weather/current|hourly|daily|forecast|air-quality`,
`/api/weather/nwp` and `/api/weather/nwp/compare`, `/api/imd/*`, `/api/alerts`,
`/api/climate/trends`, `/api/chat`, `/api/advisory`, `/api/briefing`, `/api/health`.

## Setup

1. `npm install`
2. Copy `.env.example` to `.env` and fill in whichever keys you have —
   see the comments in that file for what each one unlocks and what
   happens when it's left blank.
3. `npm run dev` (development, with Vite HMR) or `npm run build && npm start`
   (production build served by Express).

## Environment Variables

| Variable | Required? | Effect if missing |
|---|---|---|
| `GEMINI_API_KEY` | For AI chat/briefings | Falls back to a plain, non-AI summary of the same real data |
| `IMD_API_KEY` / `IMD_AUTH_TOKEN` | Optional | NDMA/Sachet public CAP feed is still used for official warnings |
| `WRF_ENDPOINT_URL` | Optional | WRF page reports "not configured" instead of fabricating data |
| `APP_URL` | Optional | Used for self-referential links only |

## Limitations

- IMD's `api.imd.gov.in` direct gateway requires an official credential this
  repo does not ship with; without one, official warnings are still sourced
  from the public NDMA/Sachet CAP feed, clearly labeled as such.
- WRF and satellite/radar layers are architecturally stubbed (real service
  interfaces exist) but have no data behind them until a real provider is
  configured — they say so rather than showing fake output.
- NWP comparison currently covers ECMWF and GFS; additional models can be
  added in `nwpService.ts`'s `MODEL_CONFIG` map using any other Open-Meteo
  model ID.

## Future Enhancements

- Real IMD gateway credential once available.
- Push notifications backed by a server-side scheduler (currently
  browser-notification permission only, as specified).
- Satellite/radar overlay once a provider is connected.
