import { GoogleGenAI, Type } from '@google/genai';
import { AgroWeatherAnalysis, AgriculturalAdvisoryInput, AgriculturalAdvisoryOutput, DecisionSupportItem, NormalizedWeather, WeatherAlert } from '../types';

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const MODEL_NAME = process.env.GEMINI_MODEL_NAME || 'gemini-3.8-flash';

export async function generateAgriAdvisory(
  input: AgriculturalAdvisoryInput,
  weatherData: NormalizedWeather,
  alerts: WeatherAlert[] = []
): Promise<AgriculturalAdvisoryOutput> {
  const ai = getGeminiClient();
  const current = weatherData.current;
  const today = weatherData.daily?.[0];
  const tomorrow = weatherData.daily?.[1];
  const day3 = weatherData.daily?.[2];

  // 1. Core Meteorological Variables
  const temp = current.temperature;
  const tempMax = today?.tempMax ?? temp;
  const tempMin = today?.tempMin ?? temp;
  const humidity = current.relativeHumidity;
  const rainToday = today?.precipitationSum ?? current.precipitation ?? 0;
  const rainProb = today?.precipitationProbabilityMax ?? 0;
  const rainTomorrow = tomorrow?.precipitationSum ?? 0;
  const rainProbTomorrow = tomorrow?.precipitationProbabilityMax ?? 0;
  const forecast3DaySum = Number((rainToday + rainTomorrow + (day3?.precipitationSum ?? 0)).toFixed(1));
  const windSpeed = current.windSpeed;
  const windGusts = today?.windGustsMax ?? current.windGusts ?? windSpeed;
  const windDirection = current.windDirection ?? 0;

  // 2. Heat Stress & Agro-Climatic Index
  // Crop heat stress assessment
  let heatStressLevel: 'Low' | 'Moderate' | 'High' | 'Severe' = 'Low';
  let heatStressSeverity: 'None' | 'Low' | 'Moderate' | 'High' | 'Severe' = 'None';
  let heatIndex = Math.round(temp + (0.5555 * ((humidity / 100) * 6.11 * Math.exp(5417.7530 * ((1 / 273.16) - (1 / (273.15 + temp)))) - 10)));
  if (isNaN(heatIndex)) heatIndex = Math.round(temp);

  if (tempMax >= 42 || (tempMax >= 38 && humidity > 50)) {
    heatStressLevel = 'Severe';
    heatStressSeverity = 'Severe';
  } else if (tempMax >= 37 || (tempMax >= 34 && humidity > 60)) {
    heatStressLevel = 'High';
    heatStressSeverity = 'High';
  } else if (tempMax >= 33 || (tempMax >= 30 && humidity > 70)) {
    heatStressLevel = 'Moderate';
    heatStressSeverity = 'Moderate';
  } else {
    heatStressLevel = 'Low';
    heatStressSeverity = 'None';
  }

  // Crop stage vulnerability to heat
  const stageLower = input.cropStage.toLowerCase();
  let heatImpactOnStage = '';
  if (stageLower.includes('flower') || stageLower.includes('pollin') || stageLower.includes('boot')) {
    heatImpactOnStage = tempMax > 34
      ? `Critical vulnerability: High daytime temperatures (${tempMax}°C) during ${input.cropStage} can cause pollen sterility, desiccation, and poor seed set.`
      : `Temperature is within tolerable thermal threshold for floral fertilization.`;
  } else if (stageLower.includes('grain') || stageLower.includes('fruit')) {
    heatImpactOnStage = tempMax > 36
      ? `Thermal stress during ${input.cropStage} accelerates forced maturity, shrinking grain weight and impairing starch accumulation.`
      : `Moderate thermal regime; favorable for steady grain/fruit development.`;
  } else if (stageLower.includes('germ') || stageLower.includes('seed') || stageLower.includes('nursery')) {
    heatImpactOnStage = tempMax > 36
      ? `Young seedlings have shallow root systems and will dehydrate rapidly under current solar irradiance.`
      : `Adequate soil temperature supports seedling emergence.`;
  } else {
    heatImpactOnStage = tempMax > 38
      ? `Vegetative canopy may experience temporary wilting during peak midday hours (12:00 PM - 3:30 PM).`
      : `Vegetative photosynthesis operating within standard metabolic range.`;
  }

  // 3. Humidity & Disease Risk Factor
  const diseaseRiskFactor: 'Low' | 'Moderate' | 'High' =
    humidity >= 78 ? 'High' : humidity >= 60 ? 'Moderate' : 'Low';
  const humidityAssessment =
    humidity >= 80
      ? `Elevated atmospheric humidity (${humidity}%) significantly promotes fungal spore germination (blast, mildew, blight) and bacterial leaf lesions.`
      : humidity >= 60
      ? `Moderate humidity (${humidity}%); standard monitoring advised for foliar fungal development.`
      : `Low atmospheric humidity (${humidity}%); dry canopy suppresses most fungal pathogen spread but may increase spider mite activity.`;

  // 4. Rainfall & Precipitation Assessment
  const willRain = rainToday >= 3 || rainProb >= 50;
  const isHeavyRainExpected = rainToday >= 20 || forecast3DaySum >= 35;
  const rainfallAssessment = isHeavyRainExpected
    ? `Substantial precipitation forecasted (${rainToday} mm today, ~${forecast3DaySum} mm 3-day accumulated) with ${rainProb}% probability. Water stagnation hazard is high.`
    : willRain
    ? `Rainfall anticipated (${rainToday} mm, ${rainProb}% probability today; ~${rainTomorrow} mm tomorrow). Topsoil will receive natural precipitation.`
    : `Primarily dry conditions (${rainToday} mm rain expected, ${rainProb}% probability). Crop relies on active soil water reserves.`;

  // 5. Wind & Drift / Lodging
  const driftRisk: 'Low' | 'Moderate' | 'High' =
    windSpeed > 18 || windGusts > 25 ? 'High' : windSpeed > 12 ? 'Moderate' : 'Low';
  const lodgingRisk: 'Low' | 'Moderate' | 'High' =
    windGusts > 40 ? 'High' : windGusts > 25 ? 'Moderate' : 'Low';

  // 6. Active Severe Weather Alerts
  const severeAlertsList = alerts.map(a => ({
    type: a.type,
    severity: a.severity,
    action: a.recommendedAction
  }));
  const hasSevereWeatherAlert = alerts.some(a => a.severity === 'RED' || a.severity === 'ORANGE');

  // Multi-day Forecast Outlook
  const forecastOutlookSummary = `Next 3-day projection: Today ${tempMax}°C / ${tempMin}°C (${rainProb}% rain, ${rainToday}mm); Day 2 ${tomorrow?.tempMax ?? tempMax}°C (${rainProbTomorrow}% rain, ${rainTomorrow}mm); Day 3 ${day3?.tempMax ?? tempMax}°C (${day3?.precipitationProbabilityMax ?? 0}% rain). Cumulative rainfall: ${forecast3DaySum}mm.`;

  const weatherAnalysis: AgroWeatherAnalysis = {
    temperature: {
      current: temp,
      min: tempMin,
      max: tempMax,
      heatStressLevel,
      assessment: `Current ${temp}°C (Day Max ${tempMax}°C / Min ${tempMin}°C). Heat stress index: ${heatIndex}. ${heatImpactOnStage}`
    },
    humidity: {
      relativeHumidity: humidity,
      assessment: humidityAssessment,
      diseaseRiskFactor
    },
    rainfall: {
      todayPrecipitation: rainToday,
      precipitationProbability: rainProb,
      forecast3DaySum,
      assessment: rainfallAssessment
    },
    wind: {
      speed: windSpeed,
      gusts: windGusts,
      direction: windDirection,
      driftRisk,
      lodgingRisk
    },
    heatStress: {
      index: heatIndex,
      severity: heatStressSeverity,
      impactOnStage: heatImpactOnStage
    },
    forecast: {
      outlookSummary: forecastOutlookSummary,
      trend: rainToday > 10 ? 'Wet Synoptic Window' : tempMax > 37 ? 'Heat Surge Window' : 'Stable Agro-climatic Window'
    },
    severeWeatherAlerts: {
      count: alerts.length,
      alerts: severeAlertsList,
      hasActiveAlert: alerts.length > 0
    }
  };

  const weatherSummary = `Temp: ${temp}°C (Max ${tempMax}°C, Min ${tempMin}°C), Humidity: ${humidity}%, Rain Sum: ${rainToday}mm (PoP ${rainProb}%), 3-Day Rain: ${forecast3DaySum}mm, Wind: ${windSpeed} km/h (Gusts: ${windGusts} km/h), Heat Stress: ${heatStressLevel}, Active IMD Alerts: ${alerts.length}.`;

  const strictLabel = 'AI-generated weather-based advisory.';
  const strictDisclaimer = 'AI-generated weather-based advisory. Never present it as an official agricultural recommendation. Consult local Krishi Vigyan Kendra (KVK) or State Agricultural Department extension officers for certified field decisions.';

  // Deterministic Agrometeorological Rule Engine (Baseline & Fallback)
  const buildRuleBasedAdvisory = (): AgriculturalAdvisoryOutput => {
    // 1. Irrigation Advice
    let irrigationStatus: 'Hold / Postpone' | 'Light Irrigation' | 'Standard Irrigation' | 'Drainage Required' = 'Standard Irrigation';
    let irrigationRecommendation = '';
    let irrigationTiming = 'Early morning (6:00 AM - 8:30 AM) or late evening (5:00 PM - 6:30 PM)';
    let waterScore = 50;

    if (isHeavyRainExpected || alerts.some(a => a.type.toLowerCase().includes('flood') || a.type.toLowerCase().includes('heavy rain'))) {
      irrigationStatus = 'Drainage Required';
      irrigationRecommendation = `Postpone all irrigation immediately. Heavy rainfall of ~${forecast3DaySum} mm expected across the next 72 hours. Open field bund outlets and drainage ditches to prevent root asphyxiation and standing pools.`;
      irrigationTiming = 'Suspend water application; focus on active furrow drainage';
      waterScore = 10;
    } else if (willRain) {
      irrigationStatus = 'Hold / Postpone';
      irrigationRecommendation = `Hold off on irrigation. Precipitation probability of ${rainProb}% (${rainToday} mm today) will meet baseline consumptive water demand for ${input.crop}. Re-evaluate topsoil moisture post-shower.`;
      irrigationTiming = 'Postpone for 24-36 hours pending rainfall accumulation';
      waterScore = 25;
    } else if (heatStressLevel === 'High' || heatStressLevel === 'Severe') {
      irrigationStatus = 'Light Irrigation';
      irrigationRecommendation = `High atmospheric demand and daytime heat (${tempMax}°C) accelerate evapotranspiration. Provide light, frequent irrigation to maintain soil moisture in root zones and cool micro-canopy temperatures. Avoid flood irrigation during midday sun.`;
      irrigationTiming = 'Strictly early morning (5:30 AM - 8:00 AM) or sunset (5:30 PM - 7:00 PM)';
      waterScore = 85;
    } else {
      irrigationStatus = 'Standard Irrigation';
      irrigationRecommendation = `Maintain scheduled irrigation depth according to ${input.cropStage} water requirements. Soil moisture depletion is at normal seasonal rates.`;
      irrigationTiming = 'Early morning hours (6:30 AM - 9:00 AM)';
      waterScore = 60;
    }

    // 2. Spraying Suitability
    let sprayingSuitabilityStatus: 'Suitable' | 'Marginal' | 'Unsuitable' = 'Suitable';
    let sprayingRecommendation = '';
    let sprayingWindow = 'Morning window 7:00 AM - 10:00 AM';
    const sprayLimitingFactors: string[] = [];

    if (willRain || rainProb >= 45) {
      sprayLimitingFactors.push(`Precipitation probability (${rainProb}%) risks washing away pesticide/fungicide residue`);
    }
    if (windSpeed > 15 || windGusts > 22) {
      sprayLimitingFactors.push(`Wind speed (${windSpeed} km/h, gusts ${windGusts} km/h) exceeds safe drift threshold (max 12-15 km/h)`);
    }
    if (tempMax > 34) {
      sprayLimitingFactors.push(`High ambient temperature (${tempMax}°C) increases droplet evaporation and risk of foliar chemical phytotoxicity`);
    }
    if (alerts.some(a => a.type.toLowerCase().includes('thunderstorm') || a.type.toLowerCase().includes('lightning'))) {
      sprayLimitingFactors.push(`Active IMD convective storm/lightning alert in district prohibits field labor`);
    }

    if (sprayLimitingFactors.length >= 2 || willRain || windSpeed > 20 || hasSevereWeatherAlert) {
      sprayingSuitabilityStatus = 'Unsuitable';
      sprayingRecommendation = `Field spraying of pesticides, insecticides, or foliar micronutrients is NOT recommended today. ${sprayLimitingFactors.join('; ')}.`;
      sprayingWindow = 'Spraying suspended until weather stabilizes';
    } else if (sprayLimitingFactors.length === 1) {
      sprayingSuitabilityStatus = 'Marginal';
      sprayingRecommendation = `Exercise caution if spraying is mandatory. ${sprayLimitingFactors[0]}. Use hollow-cone anti-drift nozzles and adhere strictly to low wind early morning hours.`;
      sprayingWindow = 'Strictly 6:30 AM - 8:30 AM (before wind velocity and temperature rise)';
    } else {
      sprayingSuitabilityStatus = 'Suitable';
      sprayingRecommendation = `Weather conditions are favorable for crop protection and foliar fertilizer sprays. Calm wind (${windSpeed} km/h), no rainfall expected, and moderate temperature ensure good droplet deposition and uptake.`;
      sprayingWindow = 'Optimal: 7:00 AM - 10:30 AM or 4:00 PM - 6:00 PM';
    }

    // 3. Rain Protection
    let rainThreatLevel: 'Low' | 'Moderate' | 'High' | 'Severe' = 'Low';
    let rainRec = '';
    const rainActions: string[] = [];

    if (isHeavyRainExpected || alerts.some(a => a.type.toLowerCase().includes('rain') || a.type.toLowerCase().includes('flood'))) {
      rainThreatLevel = 'Severe';
      rainRec = `Severe rainfall hazard. Inundation and root suffocation pose immediate risk to ${input.crop} at ${input.cropStage}. Implement emergency drainage protocols.`;
      rainActions.push('Open field trenches and drain excess standing water to perimeter canals');
      rainActions.push('Ensure nursery beds and seedbeds are elevated 15-20 cm above field level');
      rainActions.push('Shift harvested grain/produce immediately to raised platforms under waterproof tarpaulins');
      rainActions.push('Provide earthing up for tall plants to resist soil softening and lodging');
    } else if (willRain) {
      rainThreatLevel = 'Moderate';
      rainRec = `Moderate precipitation (${rainToday} mm, ${rainProb}% PoP). Maintain standard drainage to prevent localized ponding in low-lying field corners.`;
      rainActions.push('Inspect and clear field bunds of weeds and accumulated silt');
      rainActions.push('Ensure nursery seedling trays are covered if intense downpours occur');
      rainActions.push('Avoid leaving bagged fertilizer or freshly harvested crop out in the open');
    } else {
      rainThreatLevel = 'Low';
      rainRec = `No immediate rainfall threat. Field hydrology is stable under current benign atmospheric conditions.`;
      rainActions.push('Maintain regular farm soil conservation practices');
      rainActions.push('Keep field drainage channels unblocked as a routine operational measure');
    }

    // 4. Heat Protection
    let heatStressStatus: 'Low' | 'Moderate' | 'High' | 'Severe' = heatStressLevel;
    let heatRec = '';
    const heatActions: string[] = [];

    if (heatStressLevel === 'Severe' || heatStressLevel === 'High') {
      heatRec = `Intense heat alert (Forecast High: ${tempMax}°C). Heat stress threatens ${input.crop} at ${input.cropStage}. Accelerated transpiration will induce cellular moisture deficits and pollen vulnerability.`;
      heatActions.push('Apply organic mulch (paddy straw, dried leaves, or crop stubble) to shade root zones and curb soil evaporation');
      heatActions.push('Provide micro-irrigation or light sprinkler misting in early morning to lower ambient canopy temperature');
      heatActions.push('For high-value vegetable/nursery crops, deploy 50% agro-shade nets');
      heatActions.push('Avoid nitrogenous fertilizer top-dressing during peak heat waves to prevent leaf burning');
    } else if (heatStressLevel === 'Moderate') {
      heatRec = `Moderate daytime warmth (${tempMax}°C). Canopy is coping, but soil surface may dry quickly.`;
      heatActions.push('Maintain protective mulch layer in fruit or vegetable tree basins');
      heatActions.push('Monitor crop canopy between 1:00 PM and 3:00 PM for temporary moisture stress flagging');
    } else {
      heatRec = `Temperatures (${tempMax}°C) are within standard vegetative/reproductive comfort zone for ${input.crop}.`;
      heatActions.push('Normal crop management; no supplemental thermal protection required');
    }

    // 5. Harvest Considerations
    let harvestSuitability: 'Favorable' | 'Caution' | 'Unfavorable' = 'Favorable';
    let harvestRec = '';
    let harvestDrying = '';

    if (willRain || isHeavyRainExpected || hasSevereWeatherAlert) {
      harvestSuitability = 'Unfavorable';
      harvestRec = `Suspension of harvesting operations strongly advised. Precipitation and damp atmospheric conditions will cause grain wetting, mold contamination, and mechanical harvesting difficulties.`;
      harvestDrying = `Do not cut mature crop. For produce already harvested, immediately transfer into moisture-proof granaries or elevated platforms under secure tarpaulins. Keep threshing yard drains clear.`;
    } else if (humidity > 75 || rainProb > 30) {
      harvestSuitability = 'Caution';
      harvestRec = `Harvesting possible with vigilance. Elevated humidity (${humidity}%) will delay morning dew drying on crop heads.`;
      harvestDrying = `Begin harvesting only after 11:00 AM once dew dries. Spread harvested grain in thin layers on clean drying floors during peak afternoon sun to bring moisture content down to safe storage threshold (<12-14%).`;
    } else {
      harvestSuitability = 'Favorable';
      harvestRec = `Optimal harvest window. Dry weather (${rainToday} mm rain, ${rainProb}% PoP), adequate sunshine, and low surface moisture provide ideal conditions for harvesting mature ${input.crop}.`;
      harvestDrying = `Direct sun-drying of grains and produce on threshing yards is optimal. Ensure clean, moisture-free gunny bags or hermetic silos for final storage.`;
    }

    // 6. Weather-Related Crop Risk
    let overallRisk: 'Low' | 'Moderate' | 'High' | 'Severe' = 'Low';
    if (hasSevereWeatherAlert || isHeavyRainExpected || heatStressLevel === 'Severe') {
      overallRisk = 'Severe';
    } else if (willRain || heatStressLevel === 'High' || lodgingRisk === 'High' || diseaseRiskFactor === 'High') {
      overallRisk = 'High';
    } else if (heatStressLevel === 'Moderate' || diseaseRiskFactor === 'Moderate' || driftRisk === 'Moderate') {
      overallRisk = 'Moderate';
    }

    const pestRisk = heatStressLevel === 'High' || heatStressLevel === 'Severe'
      ? `Warm, dry spells accelerate reproduction cycles of sucking pests (whiteflies, thrips, aphids, mites). Inspect underside of young leaves.`
      : `Moderate pest activity. Monitor for seasonal borers or leaf folders typical of ${input.cropStage}.`;

    const diseaseRisk = diseaseRiskFactor === 'High'
      ? `High relative humidity (${humidity}%) combined with warm temperature creates an optimal micro-climate for fungal spore release (blast, blight, rust, downey mildew). Avoid excessive vegetative crowding.`
      : diseaseRiskFactor === 'Moderate'
      ? `Moderate fungal risk. Inspect lower leaves for circular or necrotic water-soaked lesions.`
      : `Low disease pressure. Atmospheric dry air curtails foliar fungal infection cycles.`;

    const physicalHazardRisk = lodgingRisk === 'High'
      ? `Wind gusts exceeding ${windGusts} km/h pose high lodging risk for tall/mature crops. Provide staking or bamboo support.`
      : alerts.some(a => a.type.toLowerCase().includes('hail'))
      ? `Hailstorm alert detected. Physical shredding of leaves and mechanical injury risk is elevated.`
      : `No severe physical mechanical wind or hail hazards under current weather telemetry.`;

    const riskSummary = `Overall crop weather risk is ${overallRisk}. Key variables of concern: ${
      [
        heatStressLevel !== 'Low' ? `Heat stress (${tempMax}°C)` : null,
        willRain ? `Precipitation (${rainToday} mm, ${rainProb}%)` : null,
        diseaseRiskFactor === 'High' ? `Elevated humidity (${humidity}%)` : null,
        lodgingRisk === 'High' ? `Gusty winds (${windGusts} km/h)` : null,
        alerts.length > 0 ? `${alerts.length} active IMD severe alerts` : null
      ].filter(Boolean).join(', ') || 'Benign agro-meteorological metrics'
    }.`;

    return {
      crop: input.crop,
      cropStage: input.cropStage,
      location: input.location,
      irrigationAdvice: {
        status: irrigationStatus,
        recommendation: irrigationRecommendation,
        timing: irrigationTiming,
        waterRequirementScore: waterScore
      },
      sprayingSuitability: {
        suitability: sprayingSuitabilityStatus,
        recommendation: sprayingRecommendation,
        optimalWindow: sprayingWindow,
        limitingFactors: sprayLimitingFactors
      },
      rainProtection: {
        threatLevel: rainThreatLevel,
        recommendation: rainRec,
        drainageActions: rainActions
      },
      heatProtection: {
        stressLevel: heatStressStatus,
        recommendation: heatRec,
        mitigationActions: heatActions
      },
      harvestConsiderations: {
        suitability: harvestSuitability,
        recommendation: harvestRec,
        dryingAndStorage: harvestDrying
      },
      weatherRelatedCropRisk: {
        overallRisk,
        summary: riskSummary,
        pestRisk,
        diseaseRisk,
        physicalHazardRisk
      },
      weatherAnalysis,
      label: strictLabel,
      disclaimer: strictDisclaimer,
      isOfficialRecommendation: false,
      irrigationRecommendation,
      sprayingRecommendation,
      diseaseRiskIndication: `${diseaseRisk} ${pestRisk}`,
      harvestRecommendation: harvestRec,
      generalPrecautions: `Regularly scout fields at 3-day intervals. Follow certified package of practices approved by your State Agricultural University or ICAR-KVK.`,
      weatherSummary,
      source: 'Agromet Meteorological Analysis Engine',
      generatedAt: new Date().toISOString()
    };
  };

  const baselineAdvisory = buildRuleBasedAdvisory();

  if (!ai) {
    return baselineAdvisory;
  }

  // AI-Assisted Enrichment using Gemini
  const prompt = `
Generate an agricultural weather advisory for the following crop profile:
Crop: ${input.crop}
Crop Stage: ${input.cropStage}
Location: ${input.location}

ANALYZED REAL WEATHER & FORECAST DATA:
- Temperature: Current ${temp}°C, Daily Max ${tempMax}°C, Daily Min ${tempMin}°C
- Relative Humidity: ${humidity}%
- Rainfall: Today ${rainToday} mm (Probability: ${rainProb}%), Tomorrow ${rainTomorrow} mm (Probability: ${rainProbTomorrow}%), 3-Day Accumulated: ${forecast3DaySum} mm
- Wind: Current ${windSpeed} km/h, Max Gusts ${windGusts} km/h, Direction ${windDirection}°
- Heat Stress Index: ${heatIndex} (Assessed Level: ${heatStressLevel})
- Severe Weather Alerts (${alerts.length} active): ${alerts.map(a => `[${a.severity}] ${a.type}: ${a.recommendedAction}`).join('; ') || 'No active severe warnings'}

REQUIRED DELIVERABLES:
1. irrigationAdvice:
   - status: "Hold / Postpone" | "Light Irrigation" | "Standard Irrigation" | "Drainage Required"
   - recommendation: specific practical advice considering soil moisture, rain forecast & heat
   - timing: best time of day
   - waterRequirementScore: number (0-100)
2. sprayingSuitability:
   - suitability: "Suitable" | "Marginal" | "Unsuitable"
   - recommendation: spraying advice for pesticides, fungicides & foliar fertilizers
   - optimalWindow: specific safe hours window or reason for cancellation
   - limitingFactors: list of weather limiting factors (wind, rain, heat, alerts)
3. rainProtection:
   - threatLevel: "Low" | "Moderate" | "High" | "Severe"
   - recommendation: drainage and protective measures against excess water
   - drainageActions: list of 2-4 actionable bullet points
4. heatProtection:
   - stressLevel: "Low" | "Moderate" | "High" | "Severe"
   - recommendation: canopy, mulching, or misting advice against thermal stress
   - mitigationActions: list of 2-4 actionable bullet points
5. harvestConsiderations:
   - suitability: "Favorable" | "Caution" | "Unfavorable"
   - recommendation: harvest advice for mature produce under these weather conditions
   - dryingAndStorage: post-harvest moisture and storage instructions
6. weatherRelatedCropRisk:
   - overallRisk: "Low" | "Moderate" | "High" | "Severe"
   - summary: concise risk synthesis
   - pestRisk: pest flare-up analysis based on temperature/humidity
   - diseaseRisk: fungal/bacterial disease trajectory
   - physicalHazardRisk: lodging, squalls, hail or thermal injury risks

STRICT COMPLIANCE DIRECTIVES:
- Clearly label output as "AI-generated weather-based advisory."
- Never present it as an official agricultural recommendation.
- Provide actionable agronomic details tailored specifically to ${input.crop} at the ${input.cropStage} stage.
`;

  try {
    const res = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction: `You are an expert Agrometeorologist providing actionable, science-grounded crop guidance based purely on real meteorological telemetry.
Never claim or present this as an official government or ICAR/KVK advisory. Always emphasize that this is an AI-generated weather-based advisory.`,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            irrigationAdvice: {
              type: Type.OBJECT,
              properties: {
                status: { type: Type.STRING },
                recommendation: { type: Type.STRING },
                timing: { type: Type.STRING },
                waterRequirementScore: { type: Type.NUMBER }
              },
              required: ['status', 'recommendation', 'timing', 'waterRequirementScore']
            },
            sprayingSuitability: {
              type: Type.OBJECT,
              properties: {
                suitability: { type: Type.STRING },
                recommendation: { type: Type.STRING },
                optimalWindow: { type: Type.STRING },
                limitingFactors: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ['suitability', 'recommendation', 'optimalWindow', 'limitingFactors']
            },
            rainProtection: {
              type: Type.OBJECT,
              properties: {
                threatLevel: { type: Type.STRING },
                recommendation: { type: Type.STRING },
                drainageActions: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ['threatLevel', 'recommendation', 'drainageActions']
            },
            heatProtection: {
              type: Type.OBJECT,
              properties: {
                stressLevel: { type: Type.STRING },
                recommendation: { type: Type.STRING },
                mitigationActions: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ['stressLevel', 'recommendation', 'mitigationActions']
            },
            harvestConsiderations: {
              type: Type.OBJECT,
              properties: {
                suitability: { type: Type.STRING },
                recommendation: { type: Type.STRING },
                dryingAndStorage: { type: Type.STRING }
              },
              required: ['suitability', 'recommendation', 'dryingAndStorage']
            },
            weatherRelatedCropRisk: {
              type: Type.OBJECT,
              properties: {
                overallRisk: { type: Type.STRING },
                summary: { type: Type.STRING },
                pestRisk: { type: Type.STRING },
                diseaseRisk: { type: Type.STRING },
                physicalHazardRisk: { type: Type.STRING }
              },
              required: ['overallRisk', 'summary', 'pestRisk', 'diseaseRisk', 'physicalHazardRisk']
            }
          },
          required: [
            'irrigationAdvice',
            'sprayingSuitability',
            'rainProtection',
            'heatProtection',
            'harvestConsiderations',
            'weatherRelatedCropRisk'
          ]
        }
      }
    });

    const parsed = JSON.parse(res.text || '{}');

    // Merge AI generated content with validated telemetry
    const result: AgriculturalAdvisoryOutput = {
      crop: input.crop,
      cropStage: input.cropStage,
      location: input.location,
      irrigationAdvice: {
        status: (parsed.irrigationAdvice?.status as any) || baselineAdvisory.irrigationAdvice.status,
        recommendation: parsed.irrigationAdvice?.recommendation || baselineAdvisory.irrigationAdvice.recommendation,
        timing: parsed.irrigationAdvice?.timing || baselineAdvisory.irrigationAdvice.timing,
        waterRequirementScore: typeof parsed.irrigationAdvice?.waterRequirementScore === 'number'
          ? parsed.irrigationAdvice.waterRequirementScore
          : baselineAdvisory.irrigationAdvice.waterRequirementScore
      },
      sprayingSuitability: {
        suitability: (parsed.sprayingSuitability?.suitability as any) || baselineAdvisory.sprayingSuitability.suitability,
        recommendation: parsed.sprayingSuitability?.recommendation || baselineAdvisory.sprayingSuitability.recommendation,
        optimalWindow: parsed.sprayingSuitability?.optimalWindow || baselineAdvisory.sprayingSuitability.optimalWindow,
        limitingFactors: Array.isArray(parsed.sprayingSuitability?.limitingFactors) && parsed.sprayingSuitability.limitingFactors.length > 0
          ? parsed.sprayingSuitability.limitingFactors
          : baselineAdvisory.sprayingSuitability.limitingFactors
      },
      rainProtection: {
        threatLevel: (parsed.rainProtection?.threatLevel as any) || baselineAdvisory.rainProtection.threatLevel,
        recommendation: parsed.rainProtection?.recommendation || baselineAdvisory.rainProtection.recommendation,
        drainageActions: Array.isArray(parsed.rainProtection?.drainageActions) && parsed.rainProtection.drainageActions.length > 0
          ? parsed.rainProtection.drainageActions
          : baselineAdvisory.rainProtection.drainageActions
      },
      heatProtection: {
        stressLevel: (parsed.heatProtection?.stressLevel as any) || baselineAdvisory.heatProtection.stressLevel,
        recommendation: parsed.heatProtection?.recommendation || baselineAdvisory.heatProtection.recommendation,
        mitigationActions: Array.isArray(parsed.heatProtection?.mitigationActions) && parsed.heatProtection.mitigationActions.length > 0
          ? parsed.heatProtection.mitigationActions
          : baselineAdvisory.heatProtection.mitigationActions
      },
      harvestConsiderations: {
        suitability: (parsed.harvestConsiderations?.suitability as any) || baselineAdvisory.harvestConsiderations.suitability,
        recommendation: parsed.harvestConsiderations?.recommendation || baselineAdvisory.harvestConsiderations.recommendation,
        dryingAndStorage: parsed.harvestConsiderations?.dryingAndStorage || baselineAdvisory.harvestConsiderations.dryingAndStorage
      },
      weatherRelatedCropRisk: {
        overallRisk: (parsed.weatherRelatedCropRisk?.overallRisk as any) || baselineAdvisory.weatherRelatedCropRisk.overallRisk,
        summary: parsed.weatherRelatedCropRisk?.summary || baselineAdvisory.weatherRelatedCropRisk.summary,
        pestRisk: parsed.weatherRelatedCropRisk?.pestRisk || baselineAdvisory.weatherRelatedCropRisk.pestRisk,
        diseaseRisk: parsed.weatherRelatedCropRisk?.diseaseRisk || baselineAdvisory.weatherRelatedCropRisk.diseaseRisk,
        physicalHazardRisk: parsed.weatherRelatedCropRisk?.physicalHazardRisk || baselineAdvisory.weatherRelatedCropRisk.physicalHazardRisk
      },
      weatherAnalysis,
      label: strictLabel,
      disclaimer: strictDisclaimer,
      isOfficialRecommendation: false,
      irrigationRecommendation: parsed.irrigationAdvice?.recommendation || baselineAdvisory.irrigationRecommendation,
      sprayingRecommendation: parsed.sprayingSuitability?.recommendation || baselineAdvisory.sprayingRecommendation,
      diseaseRiskIndication: parsed.weatherRelatedCropRisk?.diseaseRisk || baselineAdvisory.diseaseRiskIndication,
      harvestRecommendation: parsed.harvestConsiderations?.recommendation || baselineAdvisory.harvestRecommendation,
      generalPrecautions: 'Cross-verify field interventions with local extension services and seasonal agronomic calendars.',
      weatherSummary,
      source: 'Gemini Agrometeorological Advisory Intelligence',
      generatedAt: new Date().toISOString()
    };

    return result;
  } catch (err) {
    console.error('AI Agri advisory error:', err);
    return baselineAdvisory;
  }
}

export function generateDecisionSupport(weatherData: NormalizedWeather, alerts: WeatherAlert[] = []): DecisionSupportItem[] {
  const temp = weatherData.current.temperature;
  const wind = weatherData.current.windSpeed;
  const aqi = weatherData.airQuality?.usAqi ?? 45;
  const rainSum = weatherData.daily?.[0]?.precipitationSum ?? 0;
  const rainProb = weatherData.daily?.[0]?.precipitationProbabilityMax ?? 0;
  const hasSevereAlert = alerts.some(a => a.severity === 'RED' || a.severity === 'ORANGE');

  return [
    {
      category: 'Agriculture',
      currentCondition: `${weatherData.current.weatherCondition}, ${temp}°C, Humidity ${weatherData.current.relativeHumidity}%`,
      forecast: `Rain probability today: ${rainProb}% (${rainSum} mm). Winds up to ${weatherData.daily?.[0]?.windGustsMax ?? wind} km/h.`,
      relevantWarnings: alerts.filter(a => a.type.toLowerCase().includes('rain') || a.type.toLowerCase().includes('heat')).map(a => a.type),
      recommendation: rainProb > 50
        ? 'Hold chemical applications; ensure nursery drainage channels are open.'
        : 'Favorable condition for farm fieldwork, irrigation and harvesting.',
      statusLevel: rainProb > 70 || hasSevereAlert ? 'Adverse' : rainProb > 40 ? 'Caution' : 'Favorable',
      confidence: 'High (Calibrated with synoptic forecast)'
    },
    {
      category: 'Travel',
      currentCondition: `Visibility ${weatherData.hourly?.[0]?.visibility ?? 10} km, Condition: ${weatherData.current.weatherCondition}`,
      forecast: `${weatherData.daily?.[0]?.weatherCondition} with wind gusts of ${weatherData.daily?.[0]?.windGustsMax ?? wind} km/h`,
      relevantWarnings: alerts.map(a => a.type),
      recommendation: hasSevereAlert
        ? 'Non-essential travel should be deferred due to active weather warnings.'
        : rainSum > 20
        ? 'Expect wet roadways and traffic delays in low-lying zones.'
        : 'Road conditions are dry and favorable for transit.',
      statusLevel: hasSevereAlert ? 'Severe' : rainSum > 15 ? 'Caution' : 'Favorable',
      confidence: 'High'
    },
    {
      category: 'Outdoor Activity',
      currentCondition: `Temp ${temp}°C, UV Index ${weatherData.current.uvIndex ?? 5}, AQI ${aqi}`,
      forecast: `High of ${weatherData.daily?.[0]?.tempMax}°C, UV Peak ${weatherData.daily?.[0]?.uvIndexMax ?? 6}`,
      relevantWarnings: alerts.filter(a => a.type.toLowerCase().includes('heat') || a.type.toLowerCase().includes('storm')).map(a => a.type),
      recommendation: temp > 38
        ? 'Reschedule strenuous outdoor sports or heavy labor away from 12 PM - 3 PM to avoid dehydration.'
        : aqi > 150
        ? 'Sensitive groups should reduce prolonged outdoor exertion due to poor air quality.'
        : 'Excellent conditions for recreational outdoor sports and events.',
      statusLevel: temp > 40 || aqi > 200 ? 'Adverse' : temp > 35 || aqi > 100 ? 'Caution' : 'Favorable',
      confidence: 'Very High'
    },
    {
      category: 'Urban Planning',
      currentCondition: `Surface Pressure ${weatherData.current.pressure} hPa, Cloud Cover ${weatherData.current.cloudCover}%`,
      forecast: `Accumulated 24-hr precipitation expected at ${rainSum} mm`,
      relevantWarnings: alerts.filter(a => a.type.toLowerCase().includes('rain') || a.type.toLowerCase().includes('flood')).map(a => a.type),
      recommendation: rainSum > 50
        ? 'Alert municipal stormwater and pump station crews for potential water accumulation at underpasses.'
        : 'Normal municipal infrastructure operational status.',
      statusLevel: rainSum > 65 ? 'Severe' : rainSum > 30 ? 'Caution' : 'Favorable',
      confidence: 'High'
    },
    {
      category: 'Disaster Preparedness',
      currentCondition: `${alerts.length} Active Meteorological Advisories`,
      forecast: `Maximum wind gusts: ${weatherData.daily?.[0]?.windGustsMax ?? wind} km/h`,
      relevantWarnings: alerts.map(a => `[${a.severity}] ${a.type}`),
      recommendation: alerts.length > 0
        ? 'Maintain vigilance; check communication channels and keep emergency backup power ready.'
        : 'All synoptic parameters indicate normal baseline readiness; no disaster alert triggered.',
      statusLevel: hasSevereAlert ? 'Severe' : alerts.length > 0 ? 'Caution' : 'Favorable',
      confidence: 'High (IMD Benchmark)'
    },
    {
      category: 'Aviation',
      currentCondition: `Visibility ${weatherData.hourly?.[0]?.visibility ?? 10} km, Winds ${wind} km/h from ${weatherData.current.windDirection}°, QNH ${weatherData.current.pressure} hPa`,
      forecast: `Crosswind component and convective activity monitored for terminal area`,
      relevantWarnings: alerts.filter(a => a.type.toLowerCase().includes('fog') || a.type.toLowerCase().includes('storm')).map(a => a.type),
      recommendation: (weatherData.hourly?.[0]?.visibility ?? 10) < 2
        ? 'Low visibility procedures (LVP) may be required during early morning fog or dense rain showers.'
        : 'VFR/IFR meteorological conditions favorable for aerodrome operations.',
      statusLevel: (weatherData.hourly?.[0]?.visibility ?? 10) < 2 || wind > 45 ? 'Adverse' : 'Favorable',
      confidence: 'High'
    },
    {
      category: 'Marine',
      currentCondition: `Coastal Wind ${wind} km/h, Gusts ${weatherData.current.windGusts} km/h`,
      forecast: `Maximum sustained gusts over sea area: ${weatherData.daily?.[0]?.windGustsMax ?? wind} km/h`,
      relevantWarnings: alerts.filter(a => a.type.toLowerCase().includes('cyclone') || a.type.toLowerCase().includes('wind')).map(a => a.type),
      recommendation: wind > 40 || hasSevereAlert
        ? 'Fishermen are advised not to venture into deep sea or coastal waters due to squally weather.'
        : 'Sea conditions slight to moderate; normal coastal fishery operations permitted.',
      statusLevel: wind > 45 ? 'Severe' : wind > 30 ? 'Caution' : 'Favorable',
      confidence: 'High'
    }
  ];
}
