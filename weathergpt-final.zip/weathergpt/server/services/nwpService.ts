import { cache } from '../cache';
import { NwpModelResult, NwpComparisonResult, NwpVariableComparison, NwpModelId } from '../types';

/**
 * NWP (Numerical Weather Prediction) Model Service
 *
 * Uses Open-Meteo's model-specific forecast endpoint (the `models=` parameter)
 * to pull REAL, named-model output rather than Open-Meteo's generic
 * "best_match" blend. This is what lets us honestly label a value as
 * "ECMWF" or "GFS" instead of pretending the default response is one
 * specific model (see Part 9 of the WeatherGPT spec).
 *
 * Real Open-Meteo model IDs used here:
 *   - ECMWF IFS 0.25°  -> ecmwf_ifs025
 *   - NCEP GFS Seamless -> gfs_seamless
 *
 * WRF (Weather Research and Forecasting model) has NO public Open-Meteo or
 * other zero-key endpoint we can call. Per the Zero Fabrication Policy we
 * never invent WRF data - see getWrfStatus() below and Part 10 of the spec.
 */

const MODEL_CONFIG: Record<NwpModelId, { apiModelId: string; label: string }> = {
  ecmwf: { apiModelId: 'ecmwf_ifs025', label: 'ECMWF IFS (0.25°)' },
  gfs: { apiModelId: 'gfs_seamless', label: 'NCEP GFS (Seamless)' },
};

async function fetchModelData(model: NwpModelId, lat: number, lon: number): Promise<NwpModelResult> {
  const cfg = MODEL_CONFIG[model];
  const cacheKey = `nwp_${model}_${lat.toFixed(3)}_${lon.toFixed(3)}`;
  const cached = cache.get<NwpModelResult>(cacheKey);
  if (cached) return cached;

  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&models=${cfg.apiModelId}&hourly=temperature_2m,precipitation_probability,precipitation,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover&forecast_days=7&timezone=auto`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);

  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) {
      return {
        model,
        modelLabel: cfg.label,
        apiModelId: cfg.apiModelId,
        available: false,
        unavailableReason: `${cfg.label} endpoint responded with HTTP ${res.status}.`,
        hourly: [],
        source: `Open-Meteo (${cfg.label})`,
        fetchedAt: new Date().toISOString(),
      };
    }
    const data = await res.json();
    const times: string[] = data.hourly?.time || [];
    if (times.length === 0) {
      return {
        model,
        modelLabel: cfg.label,
        apiModelId: cfg.apiModelId,
        available: false,
        unavailableReason: `${cfg.label} returned no hourly data for this location.`,
        hourly: [],
        source: `Open-Meteo (${cfg.label})`,
        fetchedAt: new Date().toISOString(),
      };
    }

    const hourly = times.map((t: string, i: number) => ({
      time: t,
      temperature: data.hourly.temperature_2m?.[i],
      precipitationProbability: data.hourly.precipitation_probability?.[i],
      precipitation: data.hourly.precipitation?.[i],
      windSpeed: data.hourly.wind_speed_10m?.[i],
      windDirection: data.hourly.wind_direction_10m?.[i],
      pressure: data.hourly.pressure_msl?.[i],
      cloudCover: data.hourly.cloud_cover?.[i],
    }));

    const result: NwpModelResult = {
      model,
      modelLabel: cfg.label,
      apiModelId: cfg.apiModelId,
      available: true,
      hourly,
      source: `Open-Meteo (${cfg.label})`,
      fetchedAt: new Date().toISOString(),
    };
    cache.set(cacheKey, result, 900); // 15 min TTL
    return result;
  } catch (err: any) {
    return {
      model,
      modelLabel: cfg.label,
      apiModelId: cfg.apiModelId,
      available: false,
      unavailableReason: err.name === 'AbortError' ? `${cfg.label} request timed out.` : `${cfg.label} request failed: ${err.message}`,
      hourly: [],
      source: `Open-Meteo (${cfg.label})`,
      fetchedAt: new Date().toISOString(),
    };
  } finally {
    clearTimeout(timeout);
  }
}

export async function fetchNwpModel(model: NwpModelId, lat: number, lon: number): Promise<NwpModelResult> {
  return fetchModelData(model, lat, lon);
}

/**
 * WRF is mentioned in the problem statement (GFS/WRF) but has no configured,
 * publicly accessible, zero-credential data source. We surface the
 * architecture-supported-but-not-configured status rather than fabricate data.
 */
export function getWrfStatus() {
  const configured = Boolean(process.env.WRF_ENDPOINT_URL);
  return {
    status: configured ? ('CONFIGURED' as const) : ('NOT_CONFIGURED' as const),
    message: configured
      ? 'WRF data source configured.'
      : 'WRF integration is architecturally supported but requires a configured WRF data provider.',
  };
}

export async function compareNwpModels(lat: number, lon: number, locationName?: string): Promise<NwpComparisonResult> {
  const [ecmwf, gfs] = await Promise.all([
    fetchModelData('ecmwf', lat, lon),
    fetchModelData('gfs', lat, lon),
  ]);

  // Compare the nearest upcoming hour that both models actually have data for.
  const nowIso = new Date().toISOString().slice(0, 13);
  const findNearest = (m: NwpModelResult) => {
    if (!m.available) return null;
    let idx = m.hourly.findIndex(h => h.time.startsWith(nowIso));
    if (idx < 0) idx = 0;
    return m.hourly[idx] || null;
  };

  const ePoint = findNearest(ecmwf);
  const gPoint = findNearest(gfs);

  const diff = (a?: number, b?: number) => (typeof a === 'number' && typeof b === 'number' ? Math.round((a - b) * 10) / 10 : null);

  const comparison: NwpVariableComparison[] = [
    {
      variable: 'Temperature',
      unit: '°C',
      ecmwf: ePoint?.temperature ?? null,
      gfs: gPoint?.temperature ?? null,
      difference: diff(ePoint?.temperature, gPoint?.temperature),
    },
    {
      variable: 'Rain Probability',
      unit: '%',
      ecmwf: ePoint?.precipitationProbability ?? null,
      gfs: gPoint?.precipitationProbability ?? null,
      difference: diff(ePoint?.precipitationProbability, gPoint?.precipitationProbability),
    },
    {
      variable: 'Rainfall',
      unit: 'mm',
      ecmwf: ePoint?.precipitation ?? null,
      gfs: gPoint?.precipitation ?? null,
      difference: diff(ePoint?.precipitation, gPoint?.precipitation),
    },
    {
      variable: 'Wind Speed',
      unit: 'km/h',
      ecmwf: ePoint?.windSpeed ?? null,
      gfs: gPoint?.windSpeed ?? null,
      difference: diff(ePoint?.windSpeed, gPoint?.windSpeed),
    },
    {
      variable: 'Pressure',
      unit: 'hPa',
      ecmwf: ePoint?.pressure ?? null,
      gfs: gPoint?.pressure ?? null,
      difference: diff(ePoint?.pressure, gPoint?.pressure),
    },
    {
      variable: 'Cloud Cover',
      unit: '%',
      ecmwf: ePoint?.cloudCover ?? null,
      gfs: gPoint?.cloudCover ?? null,
      difference: diff(ePoint?.cloudCover, gPoint?.cloudCover),
    },
  ];

  // Model agreement is derived only from actual retrieved values - never invented.
  let modelAgreement: NwpComparisonResult['modelAgreement'] = 'UNKNOWN';
  if (ecmwf.available && gfs.available) {
    const tempDiff = Math.abs(comparison[0].difference ?? 0);
    const rainProbDiff = Math.abs(comparison[1].difference ?? 0);
    if (tempDiff <= 1.5 && rainProbDiff <= 15) modelAgreement = 'HIGH';
    else if (tempDiff <= 3 && rainProbDiff <= 35) modelAgreement = 'MODERATE';
    else modelAgreement = 'LOW';
  }

  const wrfStatus = getWrfStatus();

  return {
    location: { latitude: lat, longitude: lon, name: locationName },
    time: new Date().toISOString(),
    ecmwf,
    gfs,
    comparison,
    modelAgreement,
    wrf: wrfStatus,
  };
}
