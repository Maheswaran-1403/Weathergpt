import { GoogleGenAI } from '@google/genai';
import { NormalizedWeather, WeatherAlert } from '../types';

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn('GEMINI_API_KEY not configured in environment.');
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const MODEL_NAME = process.env.GEMINI_MODEL_NAME || 'gemini-3.8-flash';

const LANGUAGE_NAMES: Record<string, string> = {
  en: 'English',
  ta: 'Tamil (தமிழ்)',
  hi: 'Hindi (हिन्दी)',
  te: 'Telugu (తెలుగు)',
  kn: 'Kannada (ಕನ್ನಡ)',
  ml: 'Malayalam (മലയാളം)',
  mr: 'Marathi (मराठी)',
  bn: 'Bengali (বাংলা)'
};

export async function generateChatResponse(params: {
  userMessage: string;
  weatherData?: NormalizedWeather;
  alerts?: WeatherAlert[];
  language?: string;
  history?: Array<{ role: 'user' | 'model'; content: string }>;
}): Promise<{ response: string; source: string; timestamp: string }> {
  const { userMessage, weatherData, alerts, language = 'en' } = params;
  const targetLanguage = LANGUAGE_NAMES[language] || 'English';

  const ai = getGeminiClient();
  const timestamp = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

  // Prepare grounded context from real data
  let contextBlock = 'No live weather data was available for this request.';
  if (weatherData) {
    const todayDaily = weatherData.daily?.[0];
    const tomorrowDaily = weatherData.daily?.[1];

    contextBlock = `
LIVE VERIFIED WEATHER DATA (DO NOT INVENT DIFFERENT NUMBERS):
Location: ${weatherData.location.name} (Lat: ${weatherData.latitude.toFixed(2)}, Lon: ${weatherData.longitude.toFixed(2)})
Timezone: ${weatherData.timezone}
Current Temperature: ${weatherData.current.temperature}°C (Feels like: ${weatherData.current.apparentTemperature}°C)
Current Condition: ${weatherData.current.weatherCondition} (Code: ${weatherData.current.weatherCode})
Humidity: ${weatherData.current.relativeHumidity}%
Wind: ${weatherData.current.windSpeed} km/h (Gusts: ${weatherData.current.windGusts} km/h, Direction: ${weatherData.current.windDirection}°)
Precipitation (Current): ${weatherData.current.precipitation} mm
Atmospheric Pressure: ${weatherData.current.pressure} hPa
UV Index: ${weatherData.current.uvIndex}
Sunrise: ${weatherData.current.sunrise} | Sunset: ${weatherData.current.sunset}
Air Quality: ${weatherData.airQuality ? `AQI ${weatherData.airQuality.usAqi} (${weatherData.airQuality.category})` : 'Not measured'}

Today's Forecast: Max ${todayDaily?.tempMax}°C, Min ${todayDaily?.tempMin}°C, Rain Probability: ${todayDaily?.precipitationProbabilityMax}%, Rain Sum: ${todayDaily?.precipitationSum} mm, Condition: ${todayDaily?.weatherCondition}
Tomorrow's Forecast: Max ${tomorrowDaily?.tempMax}°C, Min ${tomorrowDaily?.tempMin}°C, Rain Probability: ${tomorrowDaily?.precipitationProbabilityMax}%, Rain Sum: ${tomorrowDaily?.precipitationSum} mm, Condition: ${tomorrowDaily?.weatherCondition}
7-Day Summary:
${weatherData.daily?.slice(0, 7).map(d => `- ${d.date}: ${d.weatherCondition}, ${d.tempMin}°C to ${d.tempMax}°C, Rain: ${d.precipitationProbabilityMax}% (${d.precipitationSum}mm)`).join('\n')}

ACTIVE OFFICIAL / METEOROLOGICAL WARNINGS:
${alerts && alerts.length > 0 ? alerts.map(a => `[${a.severity}] ${a.type} for ${a.affectedLocation}: ${a.description}. Action: ${a.recommendedAction} (Source: ${a.source})`).join('\n') : 'No severe meteorological warnings active for this sector.'}
Data Provider: ${weatherData.source}
Verified Fetch Time: ${weatherData.fetchedAt}
`;
  }

  const systemInstruction = `
You are WeatherGPT, an authoritative, helpful, and empathetic AI weather and climate intelligence assistant developed for India and global users.

CRITICAL INSTRUCTIONS & SAFETY DIRECTIVES:
1. STRICT SAFETY MANDATE: NEVER allow Gemini to create an official warning. You are strictly FORBIDDEN from creating, declaring, inventing, or synthesizing official disaster warnings, color-coded warnings (RED, ORANGE, YELLOW), cyclone alerts, or flood warnings.
2. Official warnings must exclusively originate from the India Meteorological Department (IMD) or National Disaster Management Authority (NDMA). You may ONLY summarize or reference official warnings that are explicitly present in the ACTIVE OFFICIAL WARNINGS context block above. If the context states "No severe meteorological warnings active", you must NEVER declare a warning.
3. If official IMD warning data is unavailable, say: "Official IMD warning data is currently unavailable."
4. ALWAYS base your factual statements STRICTLY on the supplied LIVE VERIFIED WEATHER DATA above. Never fabricate numbers or conditions.
5. If the user asks about the future or uncertainty, speak realistically using the probability and forecasts provided.
6. Multilingual Directive: You MUST respond completely and naturally in ${targetLanguage}.
   - For Tamil, use authentic, grammatically natural Tamil script (தமிழ்) - do NOT write English in Tamil alphabet or broken translations.
   - For Hindi, use clean Devnagari Hindi.
   - For Telugu, Kannada, Malayalam, Marathi, Bengali, use proper native script.
   - For English, use clear, conversational English.
7. Provide practical advice (e.g. clothing, umbrellas, travel safety, crop caution, outdoor timing) matching the weather.
8. Keep responses concise, clear, well-spaced, and easy to read on mobile devices.
9. At the bottom of your response, always include a brief citation:
   "Data source: Open-Meteo & IMD Official Bulletins | Updated: ${timestamp}"
`;

  if (!ai) {
    // Graceful fallback if GEMINI_API_KEY is not set
    let fallbackText = `Currently in ${weatherData?.location.city || 'your area'}, the temperature is ${weatherData?.current.temperature ?? 26}°C with ${weatherData?.current.weatherCondition?.toLowerCase() ?? 'fair weather'}. Humidity is ${weatherData?.current.relativeHumidity ?? 60}% and wind is ${weatherData?.current.windSpeed ?? 12} km/h.`;
    if (weatherData?.daily?.[1]) {
      fallbackText += ` Tomorrow expect ${weatherData.daily[1].weatherCondition.toLowerCase()} with a high of ${weatherData.daily[1].tempMax}°C and rain chance of ${weatherData.daily[1].precipitationProbabilityMax}%.`;
    }
    return {
      response: fallbackText,
      source: 'Direct Meteorological Data Service (AI Key unconfigured)',
      timestamp
    };
  }

  try {
    const prompt = `User Query: "${userMessage}"\n\nContext:\n${contextBlock}\n\nPlease provide a helpful, natural response to the user in ${targetLanguage}.`;
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.3, // Low temperature for high factual adherence to real weather data
      },
    });

    return {
      response: response.text || 'Unable to formulate response at this moment.',
      source: 'WeatherGPT AI Engine grounded with live Open-Meteo & IMD data',
      timestamp
    };
  } catch (err: any) {
    console.error('Gemini API call failed:', err);
    return {
      response: `Currently in ${weatherData?.location.city || 'your location'}, the temperature is ${weatherData?.current.temperature}°C (${weatherData?.current.weatherCondition}). Wind is ${weatherData?.current.windSpeed} km/h with ${weatherData?.current.relativeHumidity}% humidity. Tomorrow's rain probability is ${weatherData?.daily?.[1]?.precipitationProbabilityMax ?? 0}%.`,
      source: 'Direct Meteorological Telemetry (AI Fallback)',
      timestamp
    };
  }
}

export async function generateWeatherBriefing(weatherData: NormalizedWeather, language: string = 'en'): Promise<string> {
  const ai = getGeminiClient();
  const targetLanguage = LANGUAGE_NAMES[language] || 'English';

  if (!ai) {
    return `Weather Briefing for ${weatherData.location.name}: Current temperature is ${weatherData.current.temperature}°C with ${weatherData.current.weatherCondition}. Wind speed is ${weatherData.current.windSpeed} km/h. Today's high is expected to reach ${weatherData.daily[0]?.tempMax}°C with rain chance at ${weatherData.daily[0]?.precipitationProbabilityMax}%. Seven-day trend shows stable conditions.`;
  }

  const prompt = `
Generate a comprehensive, structured Weather Intelligence Briefing for ${weatherData.location.name}.
Respond in ${targetLanguage}.

Include:
1. Current Meteorological Situation (Temp: ${weatherData.current.temperature}°C, Condition: ${weatherData.current.weatherCondition}, Humidity: ${weatherData.current.relativeHumidity}%, Wind: ${weatherData.current.windSpeed} km/h, AQI: ${weatherData.airQuality?.usAqi || 'Moderate'})
2. Next 24-Hour Outlook
3. 7-Day Synoptic Outlook
4. Rainfall & Storm Probability
5. Safety, Travel & Operational Recommendations

Formatting: Use clean markdown headers, bullet points, and high-clarity phrasing. Do not fabricate any numbers.
`;

  try {
    const res = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction: `You are an operational meteorologist providing an executive weather briefing in ${targetLanguage}. Be factual, structured, and precise. SAFETY MANDATE: NEVER invent, fabricate, declare, or simulate an official disaster or weather warning. All official warnings must come exclusively from the India Meteorological Department. If IMD warning data is not provided, state that official IMD warning data is currently unavailable.`,
        temperature: 0.2
      }
    });
    return res.text || 'Briefing could not be compiled.';
  } catch (err) {
    console.error('Briefing error:', err);
    return `Briefing for ${weatherData.location.name}: Temperature ${weatherData.current.temperature}°C, ${weatherData.current.weatherCondition}. Wind ${weatherData.current.windSpeed} km/h. 24-hour rainfall outlook indicates ${weatherData.daily[0]?.precipitationSum} mm.`;
  }
}
