import { cache } from '../cache';
import { NormalizedLocation } from '../types';

export async function searchLocations(query: string): Promise<NormalizedLocation[]> {
  if (!query || query.trim().length < 2) return [];
  const cleanQuery = query.trim();
  // If query is a sentence (too long or too many words), skip geocoding lookups
  if (cleanQuery.length > 45 || cleanQuery.split(/\s+/).length > 4) return [];

  const cacheKey = `geo_${cleanQuery.toLowerCase()}`;
  const cached = cache.get<NormalizedLocation[]>(cacheKey);
  if (cached) return cached;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cleanQuery)}&count=10&language=en&format=json`;

    const response = await fetch(url, { signal: controller.signal });

    if (response.ok) {
      const data = await response.json();
      if (data && Array.isArray(data.results) && data.results.length > 0) {
        const results: NormalizedLocation[] = data.results.map((item: any) => ({
          city: item.name,
          name: [item.name, item.admin2, item.admin1, item.country].filter(Boolean).join(', '),
          district: item.admin2 || item.admin3,
          state: item.admin1,
          country: item.country || 'Unknown',
          countryCode: item.country_code,
          latitude: Number(item.latitude),
          longitude: Number(item.longitude),
          timezone: item.timezone || 'Asia/Kolkata',
          elevation: item.elevation,
        }));
        cache.set(cacheKey, results, 86400); // 24h
        return results;
      }
    }
  } catch (error: any) {
    console.warn(`Geocoding lookup error for "${cleanQuery}":`, error.name === 'AbortError' ? 'Timeout' : error.message);
  } finally {
    clearTimeout(timeout);
  }

  return [];
}

export async function reverseGeocode(lat: number, lon: number): Promise<NormalizedLocation> {
  const cacheKey = `rev_geo_${lat.toFixed(3)}_${lon.toFixed(3)}`;
  const cached = cache.get<NormalizedLocation>(cacheKey);
  if (cached) return cached;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 6000);

  try {
    // Using BigDataCloud reverse geocoding API
    const url = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`;
    const response = await fetch(url, { signal: controller.signal });

    if (response.ok) {
      const data = await response.json();
      const city = data.locality || data.city || data.principalSubdivision || `Coordinates (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`;
      const loc: NormalizedLocation = {
        city: city,
        name: [city, data.principalSubdivision, data.countryName].filter(Boolean).join(', '),
        district: data.localityInfo?.administrative?.[2]?.name || data.locality,
        state: data.principalSubdivision,
        country: data.countryName || 'Unknown',
        countryCode: data.countryCode || 'IN',
        latitude: lat,
        longitude: lon,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata',
      };
      cache.set(cacheKey, loc, 86400);
      return loc;
    }
  } catch (err) {
    console.warn('BigDataCloud reverse geocode error, trying Nominatim:', err);
  } finally {
    clearTimeout(timeout);
  }

  const nomController = new AbortController();
  const nomTimeout = setTimeout(() => nomController.abort(), 6000);
  try {
    const nomUrl = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`;
    const nomRes = await fetch(nomUrl, {
      signal: nomController.signal,
      headers: { 'User-Agent': 'WeatherGPT/1.0' }
    });
    if (nomRes.ok) {
      const nomData = await nomRes.json();
      const addr = nomData.address || {};
      const city = addr.city || addr.town || addr.village || addr.county || `Coordinates (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`;
      const loc: NormalizedLocation = {
        city,
        name: nomData.display_name || city,
        district: addr.state_district || addr.county,
        state: addr.state,
        country: addr.country || 'Unknown',
        countryCode: (addr.country_code || 'in').toUpperCase(),
        latitude: lat,
        longitude: lon,
        timezone: 'Asia/Kolkata'
      };
      cache.set(cacheKey, loc, 86400);
      return loc;
    }
  } catch (nomErr: any) {
    console.warn('Nominatim reverse geocode error:', nomErr.name === 'AbortError' ? 'Timeout' : nomErr.message);
  } finally {
    clearTimeout(nomTimeout);
  }

  return {
    city: `Coordinates (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`,
    name: `Coordinates (${lat.toFixed(2)}°, ${lon.toFixed(2)}°)`,
    country: 'India',
    latitude: lat,
    longitude: lon,
    timezone: 'Asia/Kolkata'
  };
}
