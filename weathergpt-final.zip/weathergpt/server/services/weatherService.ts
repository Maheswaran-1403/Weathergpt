import { cache } from '../cache';
import { NormalizedWeather, CurrentWeatherData, HourlyForecastItem, DailyForecastItem, AirQualityData, NormalizedLocation } from '../types';

export function decodeWmoCode(code: number): { condition: string; icon: string } {
  switch (code) {
    case 0:
      return { condition: 'Clear Sky', icon: 'Sun' };
    case 1:
      return { condition: 'Mainly Clear', icon: 'Sun' };
    case 2:
      return { condition: 'Partly Cloudy', icon: 'CloudSun' };
    case 3:
      return { condition: 'Overcast', icon: 'Cloud' };
    case 45:
      return { condition: 'Fog', icon: 'CloudFog' };
    case 48:
      return { condition: 'Depositing Rime Fog', icon: 'CloudFog' };
    case 51:
      return { condition: 'Light Drizzle', icon: 'CloudDrizzle' };
    case 53:
      return { condition: 'Moderate Drizzle', icon: 'CloudDrizzle' };
    case 55:
      return { condition: 'Dense Drizzle', icon: 'CloudDrizzle' };
    case 61:
      return { condition: 'Slight Rain', icon: 'CloudRain' };
    case 63:
      return { condition: 'Moderate Rain', icon: 'CloudRain' };
    case 65:
      return { condition: 'Heavy Rain', icon: 'CloudRainWind' };
    case 71:
      return { condition: 'Slight Snowfall', icon: 'Snowflake' };
    case 73:
      return { condition: 'Moderate Snowfall', icon: 'Snowflake' };
    case 75:
      return { condition: 'Heavy Snowfall', icon: 'Snowflake' };
    case 80:
      return { condition: 'Slight Rain Showers', icon: 'CloudRain' };
    case 81:
      return { condition: 'Moderate Rain Showers', icon: 'CloudRain' };
    case 82:
      return { condition: 'Violent Rain Showers', icon: 'CloudLightning' };
    case 95:
      return { condition: 'Thunderstorm', icon: 'CloudLightning' };
    case 96:
    case 99:
      return { condition: 'Thunderstorm with Hail', icon: 'CloudHail' };
    default:
      return { condition: 'Partly Cloudy', icon: 'CloudSun' };
  }
}

/**
 * Custom error type thrown whenever live weather data cannot be retrieved.
 * Per the Zero Fabrication Policy, WeatherGPT NEVER generates synthetic weather
 * values to paper over an API failure. Callers must catch this and surface
 * "Live weather data is currently unavailable." to the user instead of a guess.
 */
export class WeatherUnavailableError extends Error {
  constructor(message: string = 'Live weather data is currently unavailable.') {
    super(message);
    this.name = 'WeatherUnavailableError';
  }
}

export async function fetchWeather(lat: number, lon: number, locationObj?: Partial<NormalizedLocation>): Promise<NormalizedWeather> {
  const cacheKey = `weather_${lat.toFixed(3)}_${lon.toFixed(3)}`;
  const cached = cache.get<NormalizedWeather>(cacheKey);
  if (cached) return cached;

  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m&hourly=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_direction_10m,uv_index,visibility&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,uv_index_max,precipitation_sum,rain_sum,showers_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant&timezone=auto&forecast_days=7`;

  let data: any = null;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);

  try {
    const res = await fetch(url, { signal: controller.signal });
    if (res.ok) {
      data = await res.json();
    } else {
      console.warn(`Open-Meteo Weather API responded with status ${res.status}: ${res.statusText}`);
    }
  } catch (fetchErr: any) {
    console.warn(`Weather fetch failed for (${lat}, ${lon}):`, fetchErr.name === 'AbortError' ? 'Timeout (12s)' : fetchErr.message);
  } finally {
    clearTimeout(timeout);
  }

  // Zero Fabrication Policy: if the live API failed or returned incomplete data,
  // NEVER synthesize weather values. Throw so the caller can surface an honest
  // "Live weather data is currently unavailable." message instead.
  if (!data || !data.current || typeof data.current.temperature_2m !== 'number') {
    throw new WeatherUnavailableError('Live weather data is currently unavailable from Open-Meteo.');
  }

  const fetchedAt = new Date().toISOString();

  // Current weather
  const currentCode = data.current.weather_code ?? 0;
  const decodedCurrent = decodeWmoCode(currentCode);
  const current: CurrentWeatherData = {
    temperature: Math.round(data.current.temperature_2m * 10) / 10,
    apparentTemperature: Math.round((data.current.apparent_temperature ?? data.current.temperature_2m) * 10) / 10,
    relativeHumidity: data.current.relative_humidity_2m ?? 0,
    weatherCode: currentCode,
    weatherCondition: decodedCurrent.condition,
    weatherIcon: decodedCurrent.icon,
    isDay: Boolean(data.current.is_day ?? 1),
    precipitation: data.current.precipitation ?? 0,
    rain: data.current.rain ?? 0,
    cloudCover: data.current.cloud_cover ?? 0,
    pressure: Math.round(data.current.pressure_msl ?? data.current.surface_pressure ?? 1013),
    windSpeed: Math.round((data.current.wind_speed_10m ?? 0) * 10) / 10,
    windDirection: Math.round(data.current.wind_direction_10m ?? 0),
    windGusts: Math.round((data.current.wind_gusts_10m ?? 0) * 10) / 10,
    uvIndex: data.daily?.uv_index_max?.[0] ?? 0,
    sunrise: data.daily?.sunrise?.[0],
    sunset: data.daily?.sunset?.[0],
    fetchedAt,
    source: 'Open-Meteo World Meteorological Data'
  };

  // Hourly forecast (next 24 hours)
  const hourly: HourlyForecastItem[] = [];
  if (data.hourly && Array.isArray(data.hourly.time)) {
    const currentHourStr = new Date().toISOString().slice(0, 13);
    let startIndex = data.hourly.time.findIndex((t: string) => t.startsWith(currentHourStr));
    if (startIndex < 0) startIndex = 0;
    const count = Math.min(24, data.hourly.time.length - startIndex);

    for (let i = 0; i < count; i++) {
      const idx = startIndex + i;
      const code = data.hourly.weather_code?.[idx] ?? 0;
      const decoded = decodeWmoCode(code);
      hourly.push({
        time: data.hourly.time[idx],
        temperature: Math.round((data.hourly.temperature_2m?.[idx] ?? 0) * 10) / 10,
        apparentTemperature: Math.round((data.hourly.apparent_temperature?.[idx] ?? data.hourly.temperature_2m?.[idx] ?? 0) * 10) / 10,
        relativeHumidity: data.hourly.relative_humidity_2m?.[idx] ?? 0,
        precipitationProbability: data.hourly.precipitation_probability?.[idx] ?? 0,
        precipitation: data.hourly.precipitation?.[idx] ?? 0,
        weatherCode: code,
        weatherCondition: decoded.condition,
        windSpeed: Math.round((data.hourly.wind_speed_10m?.[idx] ?? 0) * 10) / 10,
        windDirection: Math.round(data.hourly.wind_direction_10m?.[idx] ?? 0),
        uvIndex: data.hourly.uv_index?.[idx] ?? 0,
        visibility: Math.round((data.hourly.visibility?.[idx] ?? 10000) / 1000) // in km
      });
    }
  }

  // Daily forecast (7 days)
  const daily: DailyForecastItem[] = [];
  if (data.daily && Array.isArray(data.daily.time)) {
    for (let i = 0; i < data.daily.time.length; i++) {
      const code = data.daily.weather_code?.[i] ?? 0;
      const decoded = decodeWmoCode(code);
      daily.push({
        date: data.daily.time[i],
        weatherCode: code,
        weatherCondition: decoded.condition,
        weatherIcon: decoded.icon,
        tempMax: Math.round((data.daily.temperature_2m_max?.[i] ?? 0) * 10) / 10,
        tempMin: Math.round((data.daily.temperature_2m_min?.[i] ?? 0) * 10) / 10,
        apparentTempMax: Math.round((data.daily.apparent_temperature_max?.[i] ?? 0) * 10) / 10,
        apparentTempMin: Math.round((data.daily.apparent_temperature_min?.[i] ?? 0) * 10) / 10,
        precipitationProbabilityMax: data.daily.precipitation_probability_max?.[i] ?? 0,
        precipitationSum: Math.round((data.daily.precipitation_sum?.[i] ?? 0) * 10) / 10,
        windSpeedMax: Math.round((data.daily.wind_speed_10m_max?.[i] ?? 0) * 10) / 10,
        windGustsMax: Math.round((data.daily.wind_gusts_10m_max?.[i] ?? 0) * 10) / 10,
        windDirectionDominant: Math.round(data.daily.wind_direction_10m_dominant?.[i] ?? 0),
        uvIndexMax: Math.round((data.daily.uv_index_max?.[i] ?? 0) * 10) / 10,
        sunrise: data.daily.sunrise?.[i] ?? '',
        sunset: data.daily.sunset?.[i] ?? ''
      });
    }
  }

  // Air Quality
  let airQuality: AirQualityData | undefined;
  try {
    airQuality = await fetchAirQuality(lat, lon);
  } catch (aqErr) {
    console.warn('Air quality fetch error (non-fatal):', aqErr);
  }

  const resolvedLocation: NormalizedLocation = {
    city: locationObj?.city || 'Selected Location',
    name: locationObj?.name || `${locationObj?.city || 'Location'}, India`,
    district: locationObj?.district,
    state: locationObj?.state,
    country: locationObj?.country || 'India',
    countryCode: locationObj?.countryCode || 'IN',
    latitude: lat,
    longitude: lon,
    timezone: data.timezone || 'Asia/Kolkata',
    elevation: data.elevation
  };

  const normalized: NormalizedWeather = {
    location: resolvedLocation,
    latitude: lat,
    longitude: lon,
    timezone: data.timezone || 'Asia/Kolkata',
    current,
    hourly,
    daily,
    source: 'Open-Meteo Global Forecasting Model',
    fetchedAt,
    airQuality
  };

  cache.set(cacheKey, normalized, 300); // 5 min TTL
  return normalized;
}

export async function fetchAirQuality(lat: number, lon: number): Promise<AirQualityData> {
  const cacheKey = `aq_${lat.toFixed(3)}_${lon.toFixed(3)}`;
  const cached = cache.get<AirQualityData>(cacheKey);
  if (cached) return cached;

  const url = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=european_aqi,us_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone&timezone=auto`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);

  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`Air Quality API error: ${res.status}`);
    const data = await res.json();
    const usAqi = data.current?.us_aqi ?? 50;

    let category: AirQualityData['category'] = 'Good';
    if (usAqi > 300) category = 'Hazardous';
    else if (usAqi > 200) category = 'Very Unhealthy';
    else if (usAqi > 150) category = 'Unhealthy';
    else if (usAqi > 100) category = 'Unhealthy for Sensitive Groups';
    else if (usAqi > 50) category = 'Moderate';

    const aqData: AirQualityData = {
      usAqi,
      europeanAqi: data.current?.european_aqi,
      pm2_5: data.current?.pm2_5 ? Math.round(data.current.pm2_5 * 10) / 10 : undefined,
      pm10: data.current?.pm10 ? Math.round(data.current.pm10 * 10) / 10 : undefined,
      co: data.current?.carbon_monoxide ? Math.round(data.current.carbon_monoxide) : undefined,
      no2: data.current?.nitrogen_dioxide ? Math.round(data.current.nitrogen_dioxide) : undefined,
      so2: data.current?.sulphur_dioxide ? Math.round(data.current.sulphur_dioxide) : undefined,
      o3: data.current?.ozone ? Math.round(data.current.ozone) : undefined,
      category,
      source: 'Copernicus Atmospheric Monitoring Service'
    };

    cache.set(cacheKey, aqData, 900); // 15 min TTL
    return aqData;
  } catch (err: any) {
    console.warn(`Air quality fetch error for (${lat}, ${lon}):`, err.name === 'AbortError' ? 'Timeout' : err.message);
    // Zero Fabrication Policy: never invent an AQI reading. Surface unavailability instead.
    throw new WeatherUnavailableError('Air quality data unavailable.');
  } finally {
    clearTimeout(timeout);
  }
}
