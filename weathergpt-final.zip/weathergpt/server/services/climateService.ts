import { cache } from '../cache';
import { HistoricalClimateData, NormalizedLocation } from '../types';

export async function fetchClimateTrends(
  lat: number,
  lon: number,
  startYear: number = 2018,
  endYear: number = 2024,
  locationObj?: Partial<NormalizedLocation>
): Promise<HistoricalClimateData> {
  const safeStart = Math.max(1980, Math.min(startYear, endYear - 1));
  const safeEnd = Math.min(new Date().getFullYear() - 1, Math.max(safeStart + 1, endYear));
  const cacheKey = `climate_${lat.toFixed(2)}_${lon.toFixed(2)}_${safeStart}_${safeEnd}`;
  const cached = cache.get<HistoricalClimateData>(cacheKey);
  if (cached) return cached;

  const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lat}&longitude=${lon}&start_date=${safeStart}-01-01&end_date=${safeEnd}-12-31&daily=temperature_2m_max,temperature_2m_min,temperature_2m_mean,precipitation_sum&timezone=auto`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);

  const res = await fetch(url, { signal: controller.signal });
  clearTimeout(timeout);

  if (!res.ok) {
    throw new Error(`Open-Meteo Archive API responded with status ${res.status}: ${res.statusText}`);
  }

  const data = await res.json();
  const times: string[] = data.daily?.time || [];
  const tempsMean: number[] = data.daily?.temperature_2m_mean || [];
  const tempsMax: number[] = data.daily?.temperature_2m_max || [];
  const tempsMin: number[] = data.daily?.temperature_2m_min || [];
  const precip: number[] = data.daily?.precipitation_sum || [];

  if (times.length === 0) {
    throw new Error('No historical climate data available from Open-Meteo archive for specified coordinates and years.');
  }

  // Group by year
  const yearBuckets: Record<number, { means: number[]; maxs: number[]; mins: number[]; precips: number[] }> = {};

  for (let i = 0; i < times.length; i++) {
    const y = parseInt(times[i].slice(0, 4), 10);
    if (!yearBuckets[y]) {
      yearBuckets[y] = { means: [], maxs: [], mins: [], precips: [] };
    }
    if (typeof tempsMean[i] === 'number' && !isNaN(tempsMean[i])) yearBuckets[y].means.push(tempsMean[i]);
    if (typeof tempsMax[i] === 'number' && !isNaN(tempsMax[i])) yearBuckets[y].maxs.push(tempsMax[i]);
    if (typeof tempsMin[i] === 'number' && !isNaN(tempsMin[i])) yearBuckets[y].mins.push(tempsMin[i]);
    if (typeof precip[i] === 'number' && !isNaN(precip[i])) yearBuckets[y].precips.push(precip[i]);
  }

  const yearlyAverages: HistoricalClimateData['yearlyAverages'] = [];
  const sortedYears = Object.keys(yearBuckets).map(Number).sort((a, b) => a - b);

  for (const y of sortedYears) {
    const bucket = yearBuckets[y];
    const avgTemp = bucket.means.length > 0 ? bucket.means.reduce((a, b) => a + b, 0) / bucket.means.length : 0;
    const maxTemp = bucket.maxs.length > 0 ? Math.max(...bucket.maxs) : 0;
    const minTemp = bucket.mins.length > 0 ? Math.min(...bucket.mins) : 0;
    const totalRainfall = bucket.precips.reduce((a, b) => a + b, 0);
    const rainyDays = bucket.precips.filter((p) => p >= 2.5).length; // WMO definition of rainy day (>= 2.5mm)

    yearlyAverages.push({
      year: y,
      avgTemp: Math.round(avgTemp * 10) / 10,
      maxTemp: Math.round(maxTemp * 10) / 10,
      minTemp: Math.round(minTemp * 10) / 10,
      totalRainfall: Math.round(totalRainfall * 10) / 10,
      rainyDays
    });
  }

  if (yearlyAverages.length === 0) {
    throw new Error('Failed to parse any valid meteorological year records from archive response.');
  }

  // Calculate comparisons
  const midPoint = Math.floor(yearlyAverages.length / 2);
  const firstHalf = yearlyAverages.slice(0, Math.max(1, midPoint));
  const secondHalf = yearlyAverages.slice(midPoint);

  const historicalAvgRainfall = Math.round(firstHalf.reduce((acc, curr) => acc + curr.totalRainfall, 0) / firstHalf.length);
  const recentAvgRainfall = Math.round(secondHalf.reduce((acc, curr) => acc + curr.totalRainfall, 0) / Math.max(1, secondHalf.length));

  const historicalAvgTemp = firstHalf.reduce((acc, curr) => acc + curr.avgTemp, 0) / firstHalf.length;
  const recentAvgTemp = secondHalf.reduce((acc, curr) => acc + curr.avgTemp, 0) / Math.max(1, secondHalf.length);

  const rainfallTrendPercent = historicalAvgRainfall > 0
    ? Math.round(((recentAvgRainfall - historicalAvgRainfall) / historicalAvgRainfall) * 100)
    : 0;

  const tempTrendDiff = Math.round((recentAvgTemp - historicalAvgTemp) * 10) / 10;
  const overallAvgTemp = Math.round((yearlyAverages.reduce((acc, curr) => acc + curr.avgTemp, 0) / yearlyAverages.length) * 10) / 10;
  const overallTotalRainfall = Math.round(yearlyAverages.reduce((acc, curr) => acc + curr.totalRainfall, 0) / yearlyAverages.length);

  const locName = locationObj?.city || 'Selected Region';
  const explanation = `Climate analysis for ${locName} from ${safeStart} to ${safeEnd} reveals an average annual temperature of ${overallAvgTemp}°C. Compared to earlier baseline records, recent annual temperatures have shifted by ${tempTrendDiff > 0 ? '+' : ''}${tempTrendDiff}°C, while annual rainfall averaged ${recentAvgRainfall} mm (${rainfallTrendPercent >= 0 ? '+' : ''}${rainfallTrendPercent}% change relative to the preceding period). Please note that these are historical meteorological observational trends derived from ECMWF ERA5 reanalysis and not guaranteed future predictions.`;

  const result: HistoricalClimateData = {
    location: {
      city: locationObj?.city || 'Location',
      name: locationObj?.name || 'Location, India',
      district: locationObj?.district,
      state: locationObj?.state,
      country: locationObj?.country || 'India',
      latitude: lat,
      longitude: lon,
      timezone: locationObj?.timezone || 'Asia/Kolkata'
    },
    startYear: safeStart,
    endYear: safeEnd,
    yearlyAverages,
    overallAvgTemp,
    overallTotalRainfall,
    historicalAvgRainfall,
    recentAvgRainfall,
    rainfallTrendPercent,
    tempTrendDiff,
    aiExplanation: explanation,
    source: 'Open-Meteo European Reanalysis & ERA5 Climate Archive'
  };

  cache.set(cacheKey, result, 86400); // 24h
  return result;
}
