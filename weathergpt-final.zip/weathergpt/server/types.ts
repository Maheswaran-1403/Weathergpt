export interface NormalizedLocation {
  city: string;
  name: string;
  district?: string;
  state?: string;
  country: string;
  countryCode?: string;
  latitude: number;
  longitude: number;
  timezone: string;
  elevation?: number;
}

export interface CurrentWeatherData {
  temperature: number;
  apparentTemperature: number;
  relativeHumidity: number;
  weatherCode: number;
  weatherCondition: string;
  weatherIcon: string;
  isDay: boolean;
  precipitation: number;
  rain: number;
  cloudCover: number;
  pressure: number;
  windSpeed: number;
  windDirection: number;
  windGusts: number;
  uvIndex?: number;
  visibility?: number;
  sunrise?: string;
  sunset?: string;
  fetchedAt: string;
  source: string;
}

export interface HourlyForecastItem {
  time: string;
  temperature: number;
  apparentTemperature?: number;
  relativeHumidity: number;
  precipitationProbability: number;
  precipitation: number;
  weatherCode: number;
  weatherCondition: string;
  windSpeed: number;
  windDirection: number;
  uvIndex: number;
  visibility: number;
}

export interface DailyForecastItem {
  date: string;
  weatherCode: number;
  weatherCondition: string;
  weatherIcon: string;
  tempMax: number;
  tempMin: number;
  apparentTempMax: number;
  apparentTempMin: number;
  precipitationProbabilityMax: number;
  precipitationSum: number;
  windSpeedMax: number;
  windGustsMax: number;
  windDirectionDominant: number;
  uvIndexMax: number;
  sunrise: string;
  sunset: string;
}

export interface NormalizedWeather {
  location: NormalizedLocation;
  latitude: number;
  longitude: number;
  timezone: string;
  current: CurrentWeatherData;
  hourly: HourlyForecastItem[];
  daily: DailyForecastItem[];
  source: string;
  fetchedAt: string;
  airQuality?: AirQualityData;
}

export interface AirQualityData {
  usAqi?: number;
  europeanAqi?: number;
  pm2_5?: number;
  pm10?: number;
  co?: number;
  no2?: number;
  so2?: number;
  o3?: number;
  category: 'Good' | 'Moderate' | 'Unhealthy for Sensitive Groups' | 'Unhealthy' | 'Very Unhealthy' | 'Hazardous';
  source: string;
}

export type AlertSeverity = 'GREEN' | 'YELLOW' | 'ORANGE' | 'RED';

export interface WeatherAlert {
  id: string;
  type: string;
  severity: AlertSeverity;
  severityLabel: string;
  colorCode: AlertSeverity;
  affectedLocation: string;
  issueTime: string;
  issueTimeFormatted?: string;
  validTime: string;
  validTimeFormatted?: string;
  validityRange?: string;
  validHours?: number;
  description: string;
  recommendedAction: string;
  source: string;
  isOfficial: boolean;
  lastUpdated: string;
  category: 'NOWCAST' | 'DISTRICT_WARNING' | 'GENERAL';
}

export interface HistoricalClimateData {
  location: NormalizedLocation;
  startYear: number;
  endYear: number;
  yearlyAverages: Array<{
    year: number;
    avgTemp: number;
    maxTemp: number;
    minTemp: number;
    totalRainfall: number;
    rainyDays: number;
  }>;
  overallAvgTemp: number;
  overallTotalRainfall: number;
  historicalAvgRainfall: number;
  recentAvgRainfall: number;
  rainfallTrendPercent: number;
  tempTrendDiff: number;
  aiExplanation?: string;
  source: string;
}

export interface AgriculturalAdvisoryInput {
  crop: string;
  cropStage: string;
  location: string;
  lat: number;
  lon: number;
  language?: string;
}

export interface AgroWeatherAnalysis {
  temperature: {
    current: number;
    min: number;
    max: number;
    heatStressLevel: 'Low' | 'Moderate' | 'High' | 'Severe';
    assessment: string;
  };
  humidity: {
    relativeHumidity: number;
    assessment: string;
    diseaseRiskFactor: 'Low' | 'Moderate' | 'High';
  };
  rainfall: {
    todayPrecipitation: number;
    precipitationProbability: number;
    forecast3DaySum: number;
    assessment: string;
  };
  wind: {
    speed: number;
    gusts: number;
    direction: number;
    driftRisk: 'Low' | 'Moderate' | 'High';
    lodgingRisk: 'Low' | 'Moderate' | 'High';
  };
  heatStress: {
    index: number;
    severity: 'None' | 'Low' | 'Moderate' | 'High' | 'Severe';
    impactOnStage: string;
  };
  forecast: {
    outlookSummary: string;
    trend: string;
  };
  severeWeatherAlerts: {
    count: number;
    alerts: Array<{ type: string; severity: string; action: string }>;
    hasActiveAlert: boolean;
  };
}

export interface AgriculturalAdvisoryOutput {
  crop: string;
  cropStage: string;
  location: string;
  // Core Required Deliverables:
  irrigationAdvice: {
    status: 'Hold / Postpone' | 'Light Irrigation' | 'Standard Irrigation' | 'Drainage Required';
    recommendation: string;
    timing: string;
    waterRequirementScore: number;
  };
  sprayingSuitability: {
    suitability: 'Suitable' | 'Marginal' | 'Unsuitable';
    recommendation: string;
    optimalWindow: string;
    limitingFactors: string[];
  };
  rainProtection: {
    threatLevel: 'Low' | 'Moderate' | 'High' | 'Severe';
    recommendation: string;
    drainageActions: string[];
  };
  heatProtection: {
    stressLevel: 'Low' | 'Moderate' | 'High' | 'Severe';
    recommendation: string;
    mitigationActions: string[];
  };
  harvestConsiderations: {
    suitability: 'Favorable' | 'Caution' | 'Unfavorable';
    recommendation: string;
    dryingAndStorage: string;
  };
  weatherRelatedCropRisk: {
    overallRisk: 'Low' | 'Moderate' | 'High' | 'Severe';
    summary: string;
    pestRisk: string;
    diseaseRisk: string;
    physicalHazardRisk: string;
  };

  // Weather analysis breakdown:
  weatherAnalysis: AgroWeatherAnalysis;

  // Strict Labeling & Disclaimers:
  label: string; // "AI-generated weather-based advisory."
  disclaimer: string;
  isOfficialRecommendation: false;

  // Backward-compatible fields:
  irrigationRecommendation: string;
  sprayingRecommendation: string;
  diseaseRiskIndication: string;
  harvestRecommendation: string;
  generalPrecautions: string;
  weatherSummary: string;
  source: string;
  generatedAt: string;
}

export interface DecisionSupportItem {
  category: 'Agriculture' | 'Travel' | 'Outdoor Activity' | 'Urban Planning' | 'Disaster Preparedness' | 'Aviation' | 'Marine';
  currentCondition: string;
  forecast: string;
  relevantWarnings: string[];
  recommendation: string;
  statusLevel: 'Favorable' | 'Caution' | 'Adverse' | 'Severe';
  confidence: string;
}

export interface ImdCurrentWeatherResult {
  stationId?: string;
  stationName: string;
  observationTime: string;
  temperature?: number;
  relativeHumidity?: number;
  windSpeed?: number;
  windDirection?: number;
  weatherCondition?: string;
  weatherCode?: number;
  pressure?: number;
  rainfall?: number;
  cloudCover?: number;
  source: string;
  isOfficialGateway: boolean;
  apiKeyStatus: {
    configured: boolean;
    secretName: string;
    requiredForDirectGateway: boolean;
    note?: string;
  };
}

export interface ImdDistrictWarningResult {
  district: string;
  state?: string;
  bulletinTime: string;
  colorCode: AlertSeverity;
  colorLabel: string;
  warnings: Array<{
    day: number;
    date: string;
    warningType: string;
    colorCode: AlertSeverity;
    colorLabel: string;
    description: string;
    recommendation: string;
  }>;
  activeAlerts: WeatherAlert[];
  source: string;
  isOfficialGateway: boolean;
  apiKeyStatus: {
    configured: boolean;
    secretName: string;
  };
}

// ============================================================
// NWP (Numerical Weather Prediction) Model Comparison
// ============================================================

export type NwpModelId = 'ecmwf' | 'gfs';

export interface NwpModelPoint {
  time: string;
  temperature?: number;
  precipitationProbability?: number;
  precipitation?: number;
  windSpeed?: number;
  windDirection?: number;
  pressure?: number;
  cloudCover?: number;
}

export interface NwpModelResult {
  model: NwpModelId;
  modelLabel: string;
  apiModelId: string;
  available: boolean;
  unavailableReason?: string;
  hourly: NwpModelPoint[];
  source: string;
  fetchedAt: string;
}

export interface NwpVariableComparison {
  variable: string;
  unit: string;
  ecmwf: number | null;
  gfs: number | null;
  difference: number | null;
}

export interface NwpComparisonResult {
  location: { latitude: number; longitude: number; name?: string };
  time: string;
  ecmwf: NwpModelResult;
  gfs: NwpModelResult;
  comparison: NwpVariableComparison[];
  modelAgreement: 'HIGH' | 'MODERATE' | 'LOW' | 'UNKNOWN';
  wrf: {
    status: 'NOT_CONFIGURED' | 'CONFIGURED';
    message: string;
  };
}

export interface ImdDistrictNowcastResult {
  district: string;
  state?: string;
  bulletinTime: string;
  validHours: number;
  severity: AlertSeverity;
  colorCode: AlertSeverity;
  nowcastEvent: string;
  warningMessage: string;
  instructions: string;
  recommendedAction: string;
  issueTime?: string;
  validTime?: string;
  validityRange?: string;
  hasActiveNowcast: boolean;
  nowcastAlerts: WeatherAlert[];
  source: string;
  isOfficialGateway: boolean;
  apiKeyStatus: {
    configured: boolean;
    secretName: string;
  };
}
