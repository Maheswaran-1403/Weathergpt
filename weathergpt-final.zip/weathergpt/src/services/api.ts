import {
  NormalizedLocation,
  NormalizedWeather,
  ImdStatusData,
  HistoricalClimateData,
  AgriculturalAdvisoryOutput,
  DecisionSupportItem,
  AirQualityData
} from '../types/weather';

export async function searchLocationsApi(query: string): Promise<NormalizedLocation[]> {
  const res = await fetch(`/api/location/search?q=${encodeURIComponent(query)}`);
  if (!res.ok) throw new Error('Failed to search locations');
  return res.json();
}

export async function reverseGeocodeApi(lat: number, lon: number): Promise<NormalizedLocation> {
  const res = await fetch(`/api/location/reverse?lat=${lat}&lon=${lon}`);
  if (!res.ok) throw new Error('Failed to reverse geocode');
  return res.json();
}

export async function fetchWeatherForecastApi(lat: number, lon: number, locationName?: string, state?: string, district?: string): Promise<NormalizedWeather> {
  const params = new URLSearchParams({
    lat: lat.toString(),
    lon: lon.toString()
  });
  if (locationName) params.append('location', locationName);
  if (state) params.append('state', state);
  if (district) params.append('district', district);

  const res = await fetch(`/api/weather/forecast?${params.toString()}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to fetch weather forecast');
  }
  return res.json();
}

export async function fetchAlertsApi(lat: number, lon: number, locationName?: string, state?: string, district?: string): Promise<ImdStatusData> {
  const params = new URLSearchParams({
    lat: lat.toString(),
    lon: lon.toString()
  });
  if (locationName) params.append('location', locationName);
  if (state) params.append('state', state);
  if (district) params.append('district', district);

  const res = await fetch(`/api/alerts?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch alerts');
  return res.json();
}

export async function fetchImdCurrentApi(lat: number, lon: number, locationName?: string): Promise<any> {
  const params = new URLSearchParams({
    lat: lat.toString(),
    lon: lon.toString()
  });
  if (locationName) params.append('location', locationName);
  const res = await fetch(`/api/imd/current?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch IMD current weather');
  return res.json();
}

export async function fetchImdWarningsApi(district: string, state?: string, lat?: number, lon?: number): Promise<any> {
  const params = new URLSearchParams({ district });
  if (state) params.append('state', state);
  if (typeof lat === 'number') params.append('lat', lat.toString());
  if (typeof lon === 'number') params.append('lon', lon.toString());
  const res = await fetch(`/api/imd/warnings?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch IMD district warnings');
  return res.json();
}

export async function fetchImdNowcastApi(district: string, state?: string, lat?: number, lon?: number): Promise<any> {
  const params = new URLSearchParams({ district });
  if (state) params.append('state', state);
  if (typeof lat === 'number') params.append('lat', lat.toString());
  if (typeof lon === 'number') params.append('lon', lon.toString());
  const res = await fetch(`/api/imd/nowcast?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch IMD district nowcast');
  return res.json();
}

export async function fetchAirQualityApi(lat: number, lon: number): Promise<AirQualityData> {
  const res = await fetch(`/api/weather/air-quality?lat=${lat}&lon=${lon}`);
  if (!res.ok) throw new Error('Failed to fetch air quality');
  return res.json();
}

export async function fetchClimateTrendsApi(lat: number, lon: number, startYear: number, endYear: number, location?: string): Promise<HistoricalClimateData> {
  const params = new URLSearchParams({
    lat: lat.toString(),
    lon: lon.toString(),
    startYear: startYear.toString(),
    endYear: endYear.toString()
  });
  if (location) params.append('location', location);

  const res = await fetch(`/api/climate/trends?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch climate trends');
  return res.json();
}

export async function fetchNwpCompareApi(lat: number, lon: number, location?: string): Promise<any> {
  const params = new URLSearchParams({ lat: lat.toString(), lon: lon.toString() });
  if (location) params.append('location', location);
  const res = await fetch(`/api/weather/nwp/compare?${params.toString()}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to compare NWP models');
  }
  return res.json();
}

export async function fetchDecisionSupportApi(lat: number, lon: number, location?: string): Promise<DecisionSupportItem[]> {
  const params = new URLSearchParams({
    lat: lat.toString(),
    lon: lon.toString()
  });
  if (location) params.append('location', location);

  const res = await fetch(`/api/decision-support?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch decision support');
  return res.json();
}

export async function generateAdvisoryApi(params: {
  crop: string;
  cropStage: string;
  location: string;
  lat: number;
  lon: number;
  language?: string;
}): Promise<AgriculturalAdvisoryOutput> {
  const res = await fetch('/api/advisory', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  });
  if (!res.ok) throw new Error('Failed to generate advisory');
  return res.json();
}

export async function generateBriefingApi(lat: number, lon: number, location: string, language: string): Promise<{ briefing: string; generatedAt: string; source: string }> {
  const res = await fetch('/api/briefing', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ lat, lon, location, language })
  });
  if (!res.ok) throw new Error('Failed to generate briefing');
  return res.json();
}

export async function sendChatMessageApi(params: {
  message: string;
  lat: number;
  lon: number;
  location: string;
  language: string;
  history?: Array<{ role: 'user' | 'model'; content: string }>;
}): Promise<{
  response: string;
  source: string;
  timestamp: string;
  detectedLocation?: NormalizedLocation;
  weatherSnippet?: any;
}> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  });
  if (!res.ok) throw new Error('Failed to send message');
  return res.json();
}
