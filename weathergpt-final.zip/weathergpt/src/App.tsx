import React, { useState } from 'react';
import { WeatherProvider, useWeather } from './contexts/WeatherContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { WeatherCard } from './components/WeatherCard';
import { ForecastSection } from './components/ForecastSection';
import { WeatherMap } from './components/WeatherMap';
import { AlertsBanner } from './components/AlertsBanner';
import { AlertsView } from './components/AlertsView';
import { ChatView } from './components/ChatView';
import { ClimateView } from './components/ClimateView';
import { NwpView } from './components/NwpView';
import { AgricultureView } from './components/AgricultureView';
import { DecisionSupportView } from './components/DecisionSupportView';
import { SettingsView } from './components/SettingsView';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { QuickActionButtons } from './components/QuickActionButtons';
import { Loader2, AlertCircle, RefreshCw } from 'lucide-react';

const MainContent: React.FC = () => {
  const { weather, imdData, loading, error, location, refreshWeather } = useWeather();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isVoiceOpen, setIsVoiceOpen] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-[#FAF9F6] dark:bg-[#121210] text-[#1A1A1A] dark:text-[#FAF9F6] flex flex-col font-sans transition-colors">
      {/* Top Navigation */}
      <Navbar
        onOpenVoice={() => setIsVoiceOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Container */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto pb-20 lg:pb-8">
        {/* Sidebar */}
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Content Body */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-full overflow-x-hidden">
          {/* Global Network/Loading banner if initial fetch */}
          {loading && !weather && (
            <div className="p-20 flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-10 h-10 animate-spin text-[#F27D26]" />
              <p className="text-xs font-mono uppercase tracking-widest text-[#A19E95]">
                Retrieving atmospheric telemetry for {location.city}...
              </p>
            </div>
          )}

          {/* Global Error Banner */}
          {error && (
            <div className="mb-6 p-4 border-l-4 border-rose-600 border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] bg-white dark:bg-[#181816] text-[#1A1A1A] dark:text-white flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 font-serif italic">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{error}</span>
              </div>
              <button
                onClick={refreshWeather}
                className="px-3 py-1 bg-[#1A1A1A] hover:bg-black text-white dark:bg-white dark:text-[#1A1A1A] font-mono text-[10px] uppercase font-bold flex items-center gap-1 transition"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Retry</span>
              </button>
            </div>
          )}

          {/* Active View Dispatcher */}
          {activeTab === 'dashboard' && weather && (
            <div className="space-y-6">
              <QuickActionButtons
                onSelectAction={(tab) => setActiveTab(tab)}
                onOpenVoice={() => setIsVoiceOpen(true)}
              />
              <AlertsBanner
                alerts={imdData?.activeAlerts || []}
                onViewAll={() => setActiveTab('alerts')}
              />
              <WeatherCard weather={weather} />
              <ForecastSection hourly={weather.hourly} daily={weather.daily} />
              <WeatherMap location={location} weather={weather} />
            </div>
          )}

          {activeTab === 'chat' && (
            <ChatView onOpenVoiceModal={() => setIsVoiceOpen(true)} />
          )}

          {activeTab === 'forecast' && weather && (
            <div className="space-y-6">
              <ForecastSection hourly={weather.hourly} daily={weather.daily} />
            </div>
          )}

          {activeTab === 'map' && (
            <div className="space-y-6">
              <WeatherMap location={location} weather={weather} />
            </div>
          )}

          {activeTab === 'alerts' && <AlertsView />}

          {activeTab === 'nwp' && <NwpView />}

          {activeTab === 'climate' && <ClimateView />}

          {activeTab === 'agriculture' && <AgricultureView />}

          {activeTab === 'decision' && <DecisionSupportView />}

          {activeTab === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Voice Assistant Modal */}
      <VoiceAssistantModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <WeatherProvider>
      <MainContent />
    </WeatherProvider>
  );
}
