import React, { useEffect, useState } from 'react';
import { Loader2, AlertTriangle, GitCompareArrows, Info, RefreshCw } from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { fetchNwpCompareApi } from '../services/api';

interface NwpVariableComparison {
  variable: string;
  unit: string;
  ecmwf: number | null;
  gfs: number | null;
  difference: number | null;
}

interface NwpCompareResponse {
  location: { latitude: number; longitude: number; name?: string };
  time: string;
  ecmwf: { available: boolean; unavailableReason?: string; modelLabel: string; source: string };
  gfs: { available: boolean; unavailableReason?: string; modelLabel: string; source: string };
  comparison: NwpVariableComparison[];
  modelAgreement: 'HIGH' | 'MODERATE' | 'LOW' | 'UNKNOWN';
  wrf: { status: string; message: string };
}

const agreementColor: Record<string, string> = {
  HIGH: 'text-emerald-600',
  MODERATE: 'text-amber-600',
  LOW: 'text-rose-600',
  UNKNOWN: 'text-[#A19E95]'
};

export const NwpView: React.FC = () => {
  const { location } = useWeather();
  const [data, setData] = useState<NwpCompareResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchNwpCompareApi(location.latitude, location.longitude, location.city);
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load NWP model comparison.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location]);

  const buildInterpretation = (d: NwpCompareResponse): string => {
    if (!d.ecmwf.available && !d.gfs.available) {
      return 'Both ECMWF and GFS model data are currently unavailable, so no comparison can be made right now.';
    }
    if (!d.ecmwf.available) return `ECMWF data is currently unavailable (${d.ecmwf.unavailableReason || 'unknown reason'}); only GFS output is shown below.`;
    if (!d.gfs.available) return `GFS data is currently unavailable (${d.gfs.unavailableReason || 'unknown reason'}); only ECMWF output is shown below.`;

    const tempRow = d.comparison.find(c => c.variable === 'Temperature');
    const rainRow = d.comparison.find(c => c.variable === 'Rain Probability');
    const parts: string[] = [];
    if (tempRow && tempRow.difference !== null) {
      parts.push(
        Math.abs(tempRow.difference) <= 1
          ? `ECMWF and GFS agree closely on temperature (within ${Math.abs(tempRow.difference)}°C).`
          : `ECMWF and GFS diverge on temperature by ${Math.abs(tempRow.difference)}°C (ECMWF: ${tempRow.ecmwf}°C, GFS: ${tempRow.gfs}°C).`
      );
    }
    if (rainRow && rainRow.difference !== null) {
      parts.push(
        Math.abs(rainRow.difference) <= 10
          ? `Rain probability estimates are close (ECMWF ${rainRow.ecmwf}%, GFS ${rainRow.gfs}%).`
          : `Rain probability estimates disagree meaningfully (ECMWF ${rainRow.ecmwf}% vs GFS ${rainRow.gfs}%, a ${Math.abs(rainRow.difference)} point gap) - treat the rain outlook as uncertain.`
      );
    }
    parts.push(`Overall model agreement for this location right now is ${d.modelAgreement}.`);
    return parts.join(' ');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-[#F27D26] block mb-1">
            NWP Model Intelligence
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
            ECMWF vs GFS Model Comparison
          </h2>
          <p className="text-xs font-serif italic text-[#A19E95] mt-1">
            Live, named-model output for <span className="font-bold text-[#1A1A1A] dark:text-white">{location.city}</span> - not a generic blended forecast.
          </p>
        </div>
        <button
          onClick={load}
          className="px-3 py-2 bg-[#1A1A1A] hover:bg-black text-white dark:bg-white dark:text-[#1A1A1A] font-mono text-[10px] uppercase font-bold flex items-center gap-1.5 transition w-fit"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh
        </button>
      </div>

      {loading && (
        <div className="p-16 flex flex-col items-center justify-center gap-3 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
          <Loader2 className="w-8 h-8 animate-spin text-[#F27D26]" />
          <p className="text-xs font-mono text-[#A19E95] uppercase">Retrieving ECMWF & GFS model runs...</p>
        </div>
      )}

      {error && !loading && (
        <div className="p-6 bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-rose-600 border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] text-xs flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          <p className="font-serif italic">{error}</p>
        </div>
      )}

      {!loading && data && (
        <>
          {/* Model cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: 'ecmwf', label: 'ECMWF', d: data.ecmwf },
              { key: 'gfs', label: 'GFS', d: data.gfs }
            ].map(({ key, label, d }) => (
              <div key={key} className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-lg font-serif font-black text-[#1A1A1A] dark:text-white">{label}</span>
                  <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 ${d.available ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                    {d.available ? 'Live' : 'Unavailable'}
                  </span>
                </div>
                <p className="text-[10px] font-mono text-[#A19E95]">{d.modelLabel}</p>
                <p className="text-[10px] font-mono text-[#A19E95] mt-1">{d.available ? `Source: ${d.source}` : d.unavailableReason}</p>
              </div>
            ))}
          </div>

          {/* Comparison table */}
          <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 overflow-x-auto">
            <div className="flex items-center gap-2 mb-4">
              <GitCompareArrows className="w-4 h-4 text-[#F27D26]" />
              <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-white">Model Comparison</h3>
            </div>
            <table className="w-full text-xs font-mono min-w-[500px]">
              <thead>
                <tr className="text-left text-[10px] uppercase text-[#A19E95] border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                  <th className="py-2 pr-4">Variable</th>
                  <th className="py-2 pr-4">ECMWF</th>
                  <th className="py-2 pr-4">GFS</th>
                  <th className="py-2 pr-4">Difference</th>
                </tr>
              </thead>
              <tbody>
                {data.comparison.map(row => (
                  <tr key={row.variable} className="border-b border-[#F2F0EB] dark:border-[#2D2C2A]/60">
                    <td className="py-2 pr-4 font-bold text-[#1A1A1A] dark:text-white">{row.variable}</td>
                    <td className="py-2 pr-4">{row.ecmwf !== null ? `${row.ecmwf} ${row.unit}` : '—'}</td>
                    <td className="py-2 pr-4">{row.gfs !== null ? `${row.gfs} ${row.unit}` : '—'}</td>
                    <td className="py-2 pr-4">{row.difference !== null ? `${row.difference > 0 ? '+' : ''}${row.difference} ${row.unit}` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="mt-4 flex items-center gap-2 text-[10px] font-mono uppercase">
              <span className="text-[#A19E95]">Model Agreement:</span>
              <span className={`font-bold ${agreementColor[data.modelAgreement]}`}>{data.modelAgreement}</span>
            </div>
          </div>

          {/* AI Interpretation - grounded strictly in retrieved values above */}
          <div className="bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-[#F27D26] border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] p-6">
            <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-white mb-2">AI Model Interpretation</h3>
            <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-slate-300">{buildInterpretation(data)}</p>
          </div>

          {/* WRF architecture status */}
          <div className="p-4 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] flex items-start gap-3 text-xs">
            <Info className="w-4 h-4 text-[#A19E95] shrink-0 mt-0.5" />
            <div>
              <p className="font-mono uppercase font-bold text-[10px] text-[#A19E95]">WRF (Weather Research & Forecasting)</p>
              <p className="font-serif italic text-[#1A1A1A] dark:text-slate-300 mt-0.5">{data.wrf.message}</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
