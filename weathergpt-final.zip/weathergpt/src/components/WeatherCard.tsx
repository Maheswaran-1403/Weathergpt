import React, { useState } from 'react';
import {
  Sun,
  CloudSun,
  Cloud,
  CloudFog,
  CloudDrizzle,
  CloudRain,
  CloudRainWind,
  CloudLightning,
  CloudHail,
  Snowflake,
  Wind,
  Droplets,
  Gauge,
  Eye,
  Sunrise,
  Sunset,
  FileText,
  Loader2,
  Sparkles,
  ShieldCheck,
  Activity
} from 'lucide-react';
import { NormalizedWeather } from '../types/weather';
import { useWeather } from '../contexts/WeatherContext';
import { generateBriefingApi } from '../services/api';

interface WeatherCardProps {
  weather: NormalizedWeather;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({ weather }) => {
  const { formatTemp, formatWind, language } = useWeather();
  const [isBriefingLoading, setIsBriefingLoading] = useState(false);
  const [briefingText, setBriefingText] = useState<string | null>(null);
  const [showBriefingModal, setShowBriefingModal] = useState(false);

  const getWeatherIcon = (iconName: string, isDay: boolean = true) => {
    const props = { className: 'w-16 h-16 text-amber-500 dark:text-amber-400' };
    switch (iconName) {
      case 'Sun':
        return isDay ? <Sun {...props} /> : <CloudSun {...props} className="w-16 h-16 text-indigo-400" />;
      case 'CloudSun':
        return <CloudSun {...props} className="w-16 h-16 text-amber-400" />;
      case 'Cloud':
        return <Cloud {...props} className="w-16 h-16 text-slate-400" />;
      case 'CloudFog':
        return <CloudFog {...props} className="w-16 h-16 text-slate-400" />;
      case 'CloudDrizzle':
        return <CloudDrizzle {...props} className="w-16 h-16 text-sky-400" />;
      case 'CloudRain':
        return <CloudRain {...props} className="w-16 h-16 text-blue-500" />;
      case 'CloudRainWind':
        return <CloudRainWind {...props} className="w-16 h-16 text-blue-600" />;
      case 'CloudLightning':
        return <CloudLightning {...props} className="w-16 h-16 text-amber-500" />;
      case 'CloudHail':
        return <CloudHail {...props} className="w-16 h-16 text-cyan-400" />;
      case 'Snowflake':
        return <Snowflake {...props} className="w-16 h-16 text-sky-200" />;
      default:
        return <Sun {...props} />;
    }
  };

  const handleGenerateBriefing = async () => {
    setIsBriefingLoading(true);
    setShowBriefingModal(true);
    try {
      const res = await generateBriefingApi(
        weather.latitude,
        weather.longitude,
        weather.location.city,
        language
      );
      setBriefingText(res.briefing);
    } catch (err) {
      setBriefingText('Unable to compile weather briefing at this time. Please try again.');
    } finally {
      setIsBriefingLoading(false);
    }
  };

  const current = weather.current;
  const aqi = weather.airQuality;

  const aqiColorClass = !aqi ? 'text-slate-500 bg-slate-100' :
    aqi.category === 'Good' ? 'text-emerald-700 bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-300' :
    aqi.category === 'Moderate' ? 'text-amber-700 bg-amber-100 dark:bg-amber-950/60 dark:text-amber-300' :
    'text-rose-700 bg-rose-100 dark:bg-rose-950/60 dark:text-rose-300';

  return (
    <div id="main-weather-card" className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 sm:p-8 relative overflow-hidden transition-colors rounded-none">
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
        <div>
          <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-[#F27D26] block mb-1">
            Current Perspective
          </span>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
              {weather.location.city}
            </h1>
            {weather.location.countryCode && (
              <span className="px-2 py-0.5 text-[9px] font-mono font-bold uppercase bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A]">
                {weather.location.countryCode}
              </span>
            )}
          </div>
          <p className="text-xs font-sans uppercase tracking-wider text-[#A19E95] mt-1 font-semibold">
            {[weather.location.district, weather.location.state, weather.location.country].filter(Boolean).join(', ')}
          </p>
        </div>

        {/* Briefing Button - Editorial styling */}
        <button
          id="generate-briefing-btn"
          onClick={handleGenerateBriefing}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] hover:bg-[#F27D26] dark:hover:bg-[#F27D26] dark:hover:text-white text-xs font-mono uppercase font-bold border border-[#1A1A1A] dark:border-white hover:border-[#F27D26] transition active:scale-98 shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Generate Weather Briefing</span>
        </button>
      </div>

      {/* Temperature & Primary Conditions matching Editorial layout */}
      <div className="py-8 flex flex-col lg:flex-row justify-between items-start gap-8">
        <div className="flex-1">
          <div className="flex items-baseline gap-4">
            <h2 className="text-[85px] sm:text-[105px] lg:text-[120px] font-serif font-black leading-none -ml-2 text-[#1A1A1A] dark:text-white">
              {formatTemp(current.temperature)}
            </h2>
          </div>
          <p className="text-3xl sm:text-4xl font-serif italic leading-none text-[#1A1A1A] dark:text-white mt-1">
            {current.weatherCondition}
          </p>
          <p className="text-[10px] uppercase font-bold tracking-widest text-[#A19E95] mt-3 font-mono">
            Feels like {formatTemp(current.apparentTemperature)} • Today's High: {formatTemp(weather.daily[0]?.tempMax)} / Low: {formatTemp(weather.daily[0]?.tempMin)}
          </p>
        </div>

        {/* Right side metrics panel with crisp editorial border-l */}
        <div className="w-full lg:w-auto border-t lg:border-t-0 lg:border-l border-[#E5E1DA] dark:border-[#2D2C2A] pt-6 lg:pt-0 lg:pl-8 flex flex-col sm:grid sm:grid-cols-3 lg:flex lg:flex-col gap-5 min-w-[220px]">
          <div>
            <span className="text-[9px] uppercase font-bold text-[#A19E95] block tracking-wider">Pressure</span>
            <span className="text-2xl font-mono text-[#1A1A1A] dark:text-white font-semibold">{current.pressure} hPa</span>
          </div>
          <div>
            <span className="text-[9px] uppercase font-bold text-[#A19E95] block tracking-wider">Wind Vector</span>
            <span className="text-2xl font-mono text-[#1A1A1A] dark:text-white font-semibold">{formatWind(current.windSpeed)}</span>
          </div>
          <div>
            <span className="text-[9px] uppercase font-bold text-[#A19E95] block tracking-wider">UV Index</span>
            <span className="text-2xl font-mono text-[#1A1A1A] dark:text-white font-semibold">{current.uvIndex ?? '4 (Moderate)'}</span>
          </div>
          {aqi && (
            <div>
              <span className="text-[9px] uppercase font-bold text-[#A19E95] block tracking-wider">Air Quality (AQI)</span>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-mono text-[#1A1A1A] dark:text-white font-semibold">AQI {aqi.usAqi}</span>
                <span className="text-[9px] font-mono uppercase px-2 py-0.5 border border-[#E5E1DA] dark:border-[#2D2C2A] bg-[#FAF9F6] dark:bg-[#201F1D] text-[#1A1A1A] dark:text-white font-bold">
                  {aqi.category}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Secondary Meteorological Key Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-[#E5E1DA] dark:border-[#2D2C2A] text-xs">
        {/* Humidity */}
        <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-1.5 text-[#A19E95] mb-1">
            <Droplets className="w-3.5 h-3.5 text-[#F27D26]" />
            <span className="text-[9px] uppercase font-bold tracking-wider">Humidity</span>
          </div>
          <span className="font-mono font-bold text-lg text-[#1A1A1A] dark:text-white">{current.relativeHumidity}%</span>
        </div>

        {/* Visibility */}
        <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-1.5 text-[#A19E95] mb-1">
            <Eye className="w-3.5 h-3.5 text-[#F27D26]" />
            <span className="text-[9px] uppercase font-bold tracking-wider">Visibility</span>
          </div>
          <span className="font-mono font-bold text-lg text-[#1A1A1A] dark:text-white">
            {current.visibility ? `${current.visibility} km` : '10 km'}
          </span>
        </div>

        {/* Sun Times */}
        <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-1.5 text-[#A19E95] mb-1">
            <Sunrise className="w-3.5 h-3.5 text-[#F27D26]" />
            <span className="text-[9px] uppercase font-bold tracking-wider">Sunrise / Sunset</span>
          </div>
          <span className="font-mono font-bold text-sm text-[#1A1A1A] dark:text-white block mt-0.5">
            {current.sunrise ? current.sunrise.slice(11, 16) : '06:05'} / {current.sunset ? current.sunset.slice(11, 16) : '18:25'}
          </span>
        </div>

        {/* Precipitation Probability */}
        <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-1.5 text-[#A19E95] mb-1">
            <Gauge className="w-3.5 h-3.5 text-[#F27D26]" />
            <span className="text-[9px] uppercase font-bold tracking-wider">Precip Probability</span>
          </div>
          <span className="font-mono font-bold text-lg text-[#1A1A1A] dark:text-white">
            {weather.daily[0]?.precipitationProbabilityMax ?? 0}%
          </span>
        </div>
      </div>

      {/* Source transparency & updated timestamp */}
      <div className="mt-6 pt-3 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono uppercase text-[#A19E95]">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Telemetric Source: {weather.source}</span>
        </div>
        <div>
          <span>Updated: {new Date(weather.fetchedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      </div>

      {/* Briefing Modal */}
      {showBriefingModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#181816] border-2 border-[#1A1A1A] dark:border-[#2D2C2A] max-w-2xl w-full p-6 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
              <div>
                <span className="text-[9px] uppercase font-bold tracking-widest text-[#F27D26]">Executive Summary</span>
                <h3 className="font-serif italic text-2xl font-bold text-[#1A1A1A] dark:text-white">
                  Weather Intelligence Briefing
                </h3>
              </div>
              <button
                onClick={() => setShowBriefingModal(false)}
                className="text-xs font-mono font-bold px-2 py-1 border border-[#E5E1DA] hover:bg-[#1A1A1A] hover:text-white transition"
              >
                ✕
              </button>
            </div>

            <div className="py-6">
              {isBriefingLoading ? (
                <div className="flex flex-col items-center justify-center py-12 gap-3 text-[#A19E95]">
                  <Loader2 className="w-8 h-8 animate-spin text-[#F27D26]" />
                  <p className="text-xs font-mono uppercase tracking-wider">Synthesizing meteorological models with Gemini AI...</p>
                </div>
              ) : (
                <div className="font-serif text-sm leading-relaxed whitespace-pre-line text-[#1A1A1A] dark:text-slate-200">
                  {briefingText}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex justify-between items-center text-[10px] font-mono uppercase text-[#A19E95]">
              <span>Grounded in live Open-Meteo & IMD Synoptic Models</span>
              <button
                onClick={() => setShowBriefingModal(false)}
                className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#F27D26] text-white text-xs font-mono uppercase font-bold transition"
              >
                Close Briefing
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
