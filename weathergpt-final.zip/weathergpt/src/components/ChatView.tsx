import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  User,
  Send,
  Loader2,
  Sparkles,
  Volume2,
  VolumeX,
  Mic,
  ShieldCheck,
  MapPin,
  RefreshCw
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { ChatMessage } from '../types/weather';
import { sendChatMessageApi } from '../services/api';

interface ChatViewProps {
  onOpenVoiceModal: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({ onOpenVoiceModal }) => {
  const { location, language } = useWeather();
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: `Hello! I am WeatherGPT, your AI weather and climate intelligence assistant. I provide real-time forecasts, IMD alerts, agricultural advisories, and climate analytics strictly grounded in live meteorological telemetry.\n\nHow may I assist you today regarding ${location.city} or any other destination?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      source: 'WeatherGPT Meteorological Engine'
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const QUICK_PROMPTS = [
    `Will it rain in ${location.city} tomorrow?`,
    `Give me a 7-day weather summary for ${location.city}`,
    `Are there any active IMD alerts or heavy rainfall warnings?`,
    `Is it safe for outdoor sports and travel today?`,
    `Pesticide spraying advisory for crops under current winds`,
    `கோயம்புத்தூரில் நாளை மழை பெய்ய வாய்ப்பு உள்ளதா?`,
    `क्या कल बारिश होगी?`
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const message = (textToSend || inputText).trim();
    if (!message || loading) return;

    const userMsgId = `user-${Date.now()}`;
    const newMessages: ChatMessage[] = [
      ...messages,
      {
        id: userMsgId,
        sender: 'user',
        text: message,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];

    setMessages(newMessages);
    setInputText('');
    setLoading(true);

    try {
      // Build history for Gemini
      const history = newMessages.slice(-6).map((m) => ({
        role: m.sender === 'user' ? ('user' as const) : ('model' as const),
        content: m.text
      }));

      const res = await sendChatMessageApi({
        message,
        lat: location.latitude,
        lon: location.longitude,
        location: location.name,
        language,
        history
      });

      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'assistant',
          text: res.response,
          timestamp: res.timestamp || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          source: res.source,
          detectedLocation: res.detectedLocation,
          weatherSnippet: res.weatherSnippet
        }
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-err-${Date.now()}`,
          sender: 'assistant',
          text: 'I could not connect to the meteorological service at this instant. Please check your internet connection or try rephrasing your question.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          source: 'Network Error Handler'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const speakText = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;
    if (playingMessageId === id) {
      window.speechSynthesis.cancel();
      setPlayingMessageId(null);
      return;
    }
    window.speechSynthesis.cancel();

    const clean = text.replace(/[*_#`[\]()]/g, '');
    const utter = new SpeechSynthesisUtterance(clean);
    utter.onend = () => setPlayingMessageId(null);
    utter.onerror = () => setPlayingMessageId(null);

    setPlayingMessageId(id);
    window.speechSynthesis.speak(utter);
  };

  return (
    <div id="chat-view-container" className="flex flex-col h-[calc(100vh-8rem)] max-h-[850px] bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] rounded-none overflow-hidden shadow-xs">
      {/* Header */}
      <div className="p-4 border-b border-[#E5E1DA] dark:border-[#2D2C2A] bg-[#FAF9F6] dark:bg-[#201F1D] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-mono uppercase bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] px-2 py-1 font-bold">
            AI
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-serif font-bold text-[#1A1A1A] dark:text-white text-base">WeatherGPT Intelligence</h2>
              <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#F27D26]">
                Live Grounded
              </span>
            </div>
            <p className="text-[10px] font-mono text-[#A19E95] uppercase">
              Active sector: <span className="font-bold text-[#1A1A1A] dark:text-white">{location.city}</span> ({location.country})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex gap-1 items-center">
            <span className="w-1.5 h-1.5 bg-[#1A1A1A] dark:bg-white rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-[#1A1A1A] dark:bg-white rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-[#1A1A1A] dark:bg-white rounded-full"></span>
          </div>
          <button
            onClick={() => setMessages([messages[0]])}
            title="Reset conversation"
            className="px-2.5 py-1 text-[10px] font-mono uppercase border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white transition flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((m) => {
          const isUser = m.sender === 'user';
          return (
            <div
              key={m.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-7 h-7 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] flex items-center justify-center font-serif italic text-xs font-black shrink-0 mt-1">
                  W
                </div>
              )}

              <div
                className={`max-w-xl p-4 text-xs font-serif leading-relaxed transition ${
                  isUser
                    ? 'bg-[#1A1A1A] text-white rounded-none shadow-xs'
                    : 'bg-[#F7F6F2] dark:bg-[#201F1D] border-l-4 border-[#F27D26] border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-slate-200 rounded-none shadow-xs'
                }`}
              >
                {/* Weather snippet preview if available */}
                {m.weatherSnippet && (
                  <div className="mb-3 p-2.5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#F27D26]" />
                      <span className="font-bold text-[#1A1A1A] dark:text-white">{m.detectedLocation?.city || location.city}</span>
                      <span>•</span>
                      <span>{m.weatherSnippet.temp}°C, {m.weatherSnippet.condition}</span>
                    </div>
                    {m.weatherSnippet.rainProb !== undefined && (
                      <span className="font-bold text-[#F27D26]">Rain: {m.weatherSnippet.rainProb}%</span>
                    )}
                  </div>
                )}

                <p className="whitespace-pre-line text-xs sm:text-[13px] leading-relaxed">{m.text}</p>

                {/* Footer attribution & TTS */}
                <div className="mt-3 pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between text-[10px] font-mono text-[#A19E95]">
                  <div className="flex items-center gap-1.5">
                    {!isUser && <ShieldCheck className="w-3 h-3 text-emerald-600" />}
                    <span>{m.source || (isUser ? 'You' : 'WeatherGPT')}</span>
                    <span>•</span>
                    <span>{m.timestamp}</span>
                  </div>

                  {!isUser && 'speechSynthesis' in window && (
                    <button
                      onClick={() => speakText(m.id, m.text)}
                      className="hover:text-[#F27D26] transition p-1"
                      title="Read aloud"
                    >
                      {playingMessageId === m.id ? (
                        <VolumeX className="w-3.5 h-3.5 text-[#F27D26]" />
                      ) : (
                        <Volume2 className="w-3.5 h-3.5 text-[#A19E95]" />
                      )}
                    </button>
                  )}
                </div>
              </div>

              {isUser && (
                <div className="w-7 h-7 bg-[#E5E1DA] dark:bg-[#2D2C2A] text-[#1A1A1A] dark:text-white flex items-center justify-center font-mono text-xs font-bold shrink-0 mt-1">
                  U
                </div>
              )}
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-3 justify-start">
            <div className="w-7 h-7 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] flex items-center justify-center font-serif italic text-xs font-black shrink-0 mt-1">
              W
            </div>
            <div className="bg-[#F7F6F2] dark:bg-[#201F1D] border-l-4 border-[#F27D26] border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] p-4 flex items-center gap-2 text-xs font-mono text-[#A19E95]">
              <Loader2 className="w-4 h-4 animate-spin text-[#F27D26]" />
              <span>Querying verified meteorological models & synthesizing answer...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested prompts chips */}
      <div className="px-4 py-2 bg-[#FAF9F6] dark:bg-[#201F1D] border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex gap-2 overflow-x-auto scrollbar-none">
        {QUICK_PROMPTS.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(prompt)}
            disabled={loading}
            className="shrink-0 px-2.5 py-1 text-[10px] font-mono uppercase font-bold border border-[#E5E1DA] dark:border-[#2D2C2A] bg-white dark:bg-[#181816] text-[#A19E95] hover:border-black hover:text-[#1A1A1A] dark:hover:text-white transition"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input bar */}
      <div className="p-3 bg-white dark:bg-[#181816] border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center gap-2">
        <button
          onClick={onOpenVoiceModal}
          title="Voice input"
          className="p-2.5 text-white bg-[#F27D26] hover:bg-[#d96a1a] transition shrink-0"
        >
          <Mic className="w-4 h-4" />
        </button>

        <input
          type="text"
          placeholder={`Ask about ${location.city} weather, rain, crops, or travel advisories...`}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          disabled={loading}
          className="flex-1 bg-[#FAF9F6] dark:bg-[#201F1D] text-[#1A1A1A] dark:text-white text-xs sm:text-sm font-serif italic px-4 py-2.5 border border-[#1A1A1A] dark:border-white focus:outline-none transition placeholder-[#A19E95]"
        />

        <button
          onClick={() => handleSendMessage()}
          disabled={!inputText.trim() || loading}
          className="px-4 py-2.5 bg-[#1A1A1A] dark:bg-white hover:bg-[#F27D26] dark:hover:bg-[#F27D26] text-white dark:text-[#1A1A1A] dark:hover:text-white disabled:opacity-50 text-xs font-mono uppercase font-bold transition shrink-0 flex items-center gap-1.5"
        >
          <span>Send</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
