import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Loader2,
  Bot,
  Send,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { sendChatMessageApi } from '../services/api';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Map app language code to speech recognition / synthesis BCP-47 tags
const SPEECH_LANG_MAP: Record<string, string> = {
  en: 'en-IN',
  ta: 'ta-IN',
  hi: 'hi-IN',
  te: 'te-IN',
  kn: 'kn-IN',
  ml: 'ml-IN',
  mr: 'mr-IN',
  bn: 'bn-IN'
};

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({ isOpen, onClose }) => {
  const { location, language } = useWeather();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [speechSynthesisActive, setSpeechSynthesisActive] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check SpeechRecognition API availability
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = SPEECH_LANG_MAP[language] || 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } catch (e) {
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [language]);

  // Handle start/stop
  const toggleListening = () => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setTranscript('');
      setResponse('');
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.warn('Recognition start exception:', e);
      }
    }
  };

  // Speak aloud using SpeechSynthesis
  const speakResponse = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    const cleanText = text.replace(/[*_#`[\]()]/g, ''); // strip markdown chars
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = SPEECH_LANG_MAP[language] || 'en-IN';
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onstart = () => setSpeechSynthesisActive(true);
    utterance.onend = () => setSpeechSynthesisActive(false);
    utterance.onerror = () => setSpeechSynthesisActive(false);

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setSpeechSynthesisActive(false);
    }
  };

  const handleSubmitQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    setIsProcessing(true);
    try {
      const res = await sendChatMessageApi({
        message: queryText,
        lat: location.latitude,
        lon: location.longitude,
        location: location.name,
        language
      });
      setResponse(res.response);
      speakResponse(res.response);
    } catch (err) {
      setResponse('Sorry, I could not process your voice weather query. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div id="voice-assistant-modal" className="fixed inset-0 z-50 bg-[#1A1A1A]/80 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#181816] border border-[#1A1A1A] dark:border-white rounded-none max-w-lg w-full p-6 shadow-2xl relative overflow-hidden">
        {/* Glow effect */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Top bar */}
        <div className="flex items-center justify-between pb-4 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-3">
            <span className="px-2 py-1 text-[10px] font-mono font-bold uppercase bg-[#F27D26] text-white">
              AUDIO
            </span>
            <div>
              <h3 className="font-serif font-bold text-[#1A1A1A] dark:text-white text-lg">Voice Meteorological Assistant</h3>
              <p className="text-[10px] font-mono text-[#A19E95] uppercase">Speech-to-Text & Synthesis ({SPEECH_LANG_MAP[language] || 'en-IN'})</p>
            </div>
          </div>
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="p-1 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white hover:border-black"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="py-6 flex flex-col items-center text-center">
          {!speechSupported ? (
            <div className="p-4 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white text-xs font-serif flex items-center gap-2 max-w-md">
              <AlertCircle className="w-5 h-5 shrink-0 text-[#F27D26]" />
              <span>Voice input is not supported in this browser environment. Please use Chrome or Edge, or type your query in the chat console.</span>
            </div>
          ) : (
            <>
              {/* Giant Interactive Mic Button */}
              <div className="relative my-4">
                {isListening && (
                  <div className="absolute inset-0 rounded-full bg-[#F27D26]/30 animate-ping" />
                )}
                <button
                  id="mic-pulse-btn"
                  onClick={toggleListening}
                  className={`relative w-24 h-24 rounded-full flex items-center justify-center text-white transition shadow-md ${
                    isListening
                      ? 'bg-rose-700 scale-105'
                      : 'bg-[#F27D26] hover:bg-[#d96a1a] hover:scale-105'
                  }`}
                >
                  {isListening ? (
                    <MicOff className="w-9 h-9 animate-pulse" />
                  ) : (
                    <Mic className="w-9 h-9" />
                  )}
                </button>
              </div>

              <p className="text-sm font-serif font-bold text-[#1A1A1A] dark:text-white mb-1">
                {isListening ? 'Listening to your transmission...' : 'Tap the microphone and speak your query'}
              </p>
              <p className="text-xs font-serif italic text-[#A19E95] max-w-xs">
                Ask: "Will it rain in Coimbatore tomorrow?" or "Should I irrigate my crops today?"
              </p>

              {/* Transcript Display */}
              {transcript && (
                <div className="mt-4 p-4 bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-[#1A1A1A] dark:border-white border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] w-full text-left text-xs font-serif">
                  <span className="text-[10px] font-mono font-bold uppercase text-[#A19E95] block mb-1">Acoustic Input:</span>
                  <p className="text-[#1A1A1A] dark:text-white italic">"{transcript}"</p>
                  {!isListening && (
                    <button
                      onClick={() => handleSubmitQuery(transcript)}
                      disabled={isProcessing}
                      className="mt-3 px-3 py-1.5 bg-[#1A1A1A] hover:bg-[#F27D26] text-white text-[10px] font-mono uppercase font-bold flex items-center gap-1.5 transition ml-auto"
                    >
                      {isProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                      <span>Process Query</span>
                    </button>
                  )}
                </div>
              )}

              {/* Processing state */}
              {isProcessing && (
                <div className="mt-4 flex items-center gap-2 text-[#F27D26] text-xs font-mono">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Retrieving live telemetry & synthesizing meteorological brief...</span>
                </div>
              )}

              {/* AI Voice Response */}
              {response && (
                <div className="mt-4 p-4 bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-[#F27D26] border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] w-full text-left text-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono font-bold text-[10px] uppercase tracking-wider text-[#F27D26] flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Synthesized Advisory
                    </span>
                    {speechSynthesisActive ? (
                      <button
                        onClick={stopSpeaking}
                        className="text-rose-600 hover:text-rose-800 flex items-center gap-1 text-[10px] font-mono uppercase font-bold"
                      >
                        <VolumeX className="w-3.5 h-3.5" />
                        <span>Mute</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => speakResponse(response)}
                        className="text-[#1A1A1A] dark:text-white hover:text-[#F27D26] flex items-center gap-1 text-[10px] font-mono uppercase font-bold"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Replay</span>
                      </button>
                    )}
                  </div>
                  <p className="text-[#1A1A1A] dark:text-[#F5F4F0] font-serif leading-relaxed whitespace-pre-line text-sm">
                    {response}
                  </p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex justify-between items-center text-[10px] font-mono uppercase text-[#A19E95]">
          <span>Web Speech Protocol</span>
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="px-3 py-1.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white font-mono uppercase font-bold hover:border-black dark:hover:border-white transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
