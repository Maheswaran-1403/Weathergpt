import React, { useState } from 'react';
import {
  Sprout,
  Droplets,
  ShieldAlert,
  Bug,
  SunMedium,
  CalendarCheck,
  Loader2,
  Sparkles,
  Info,
  CheckCircle2,
  AlertTriangle,
  Wind,
  CloudRain,
  Thermometer,
  ShieldCheck,
  AlertOctagon,
  MapPin,
  RefreshCw
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { AgriculturalAdvisoryOutput } from '../types/weather';
import { generateAdvisoryApi } from '../services/api';

const POPULAR_CROPS = [
  'Rice (Paddy)',
  'Wheat',
  'Cotton',
  'Tomato',
  'Sugarcane',
  'Maize (Corn)',
  'Groundnut',
  'Soybean',
  'Chilli',
  'Onion',
  'Banana',
  'Mustard',
  'Turmeric',
  'Potato',
  'Gram (Chickpea)',
  'Coconut',
  'Other / Custom'
];

const CROP_STAGES = [
  'Nursery / Seedling / Germination',
  'Vegetative Growth',
  'Tillering / Branching',
  'Flowering / Pollination',
  'Grain / Fruit Formation',
  'Maturity / Ripening',
  'Harvest Window'
];

export const AgricultureView: React.FC = () => {
  const { location, weather, language } = useWeather();
  const [selectedCrop, setSelectedCrop] = useState(POPULAR_CROPS[0]);
  const [customCrop, setCustomCrop] = useState('');
  const [selectedStage, setSelectedStage] = useState(CROP_STAGES[1]);
  const [loading, setLoading] = useState(false);
  const [advisory, setAdvisory] = useState<AgriculturalAdvisoryOutput | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const effectiveCrop = selectedCrop === 'Other / Custom' ? (customCrop.trim() || 'Custom Crop') : selectedCrop;

  const handleGenerateAdvisory = async () => {
    if (!weather) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const data = await generateAdvisoryApi({
        crop: effectiveCrop,
        cropStage: selectedStage,
        location: location.city,
        lat: location.latitude,
        lon: location.longitude,
        language
      });
      setAdvisory(data);
    } catch (err: any) {
      console.error('Advisory generation failed:', err);
      setErrorMsg('Failed to generate advisory. Please check your connection and retry.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string, category: 'irrigation' | 'spraying' | 'threat' | 'harvest' | 'risk') => {
    const s = status.toLowerCase();
    if (s.includes('drainage') || s.includes('unsuitable') || s.includes('severe') || s.includes('unfavorable')) {
      return (
        <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-rose-900 text-white flex items-center gap-1">
          <AlertOctagon className="w-3.5 h-3.5" />
          <span>{status}</span>
        </span>
      );
    }
    if (s.includes('hold') || s.includes('postpone') || s.includes('marginal') || s.includes('high') || s.includes('caution')) {
      return (
        <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#ea580c] text-white flex items-center gap-1">
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>{status}</span>
        </span>
      );
    }
    if (s.includes('moderate') || s.includes('light')) {
      return (
        <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-amber-500 text-black flex items-center gap-1">
          <Info className="w-3.5 h-3.5" />
          <span>{status}</span>
        </span>
      );
    }
    return (
      <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-emerald-700 text-white flex items-center gap-1">
        <ShieldCheck className="w-3.5 h-3.5" />
        <span>{status}</span>
      </span>
    );
  };

  return (
    <div id="agriculture-view-container" className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1.5">
              <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-[#F27D26]">
                Agronomic Intelligence
              </span>
              <span className="px-2 py-0.5 text-[9px] font-mono font-bold bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-[#F5F4F0]">
                AI-generated weather-based advisory.
              </span>
            </div>
            <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
              Agrometeorological Advisory Engine
            </h2>
            <p className="text-xs font-serif italic text-[#A19E95] mt-1">
              Real-time atmospheric analysis and agronomic decision modeling for {location.name}
            </p>
          </div>

          <div className="text-right text-xs font-mono hidden sm:block">
            <span className="flex items-center gap-1 justify-end font-bold text-[#1A1A1A] dark:text-white text-[11px]">
              <MapPin className="w-3.5 h-3.5 text-[#F27D26]" />
              <span>{location.city} ({location.latitude.toFixed(2)}°N, {location.longitude.toFixed(2)}°E)</span>
            </span>
            {weather && (
              <span className="text-[10px] text-[#A19E95] block mt-0.5">
                Telemetry Synced: {new Date(weather.fetchedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            )}
          </div>
        </div>

        {/* Mandatory Strict Compliance Disclaimer Box */}
        <div className="mt-4 p-3.5 bg-amber-50 dark:bg-[#201c14] border border-amber-300 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
          <div className="text-[11px] leading-relaxed font-serif">
            <span className="font-mono font-bold uppercase tracking-wider block text-amber-900 dark:text-amber-100">
              Notice: AI-Generated Weather-Based Advisory
            </span>
            <p className="italic text-amber-800 dark:text-amber-300 mt-0.5">
              This advisory is an <strong>AI-generated weather-based advisory</strong> derived from numerical meteorological models. <strong>It is never an official agricultural recommendation.</strong> Farmers and producers should always cross-verify operations with local Krishi Vigyan Kendra (KVK), State Agricultural Department extension officers, or certified agronomists.
            </p>
          </div>
        </div>

        {/* Input Parameters: Crop, Stage, Location */}
        <div className="mt-6 pt-4 border-t border-[#E5E1DA] dark:border-[#2D2C2A] space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Input 1: Crop */}
            <div>
              <label className="block text-[10px] font-mono uppercase font-bold text-[#A19E95] mb-1.5">
                Target Crop
              </label>
              <select
                id="crop-selector"
                value={selectedCrop}
                onChange={(e) => setSelectedCrop(e.target.value)}
                className="w-full p-2.5 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-serif font-bold text-[#1A1A1A] dark:text-white focus:outline-none focus:border-black dark:focus:border-white"
              >
                {POPULAR_CROPS.map((crop) => (
                  <option key={crop} value={crop}>
                    {crop}
                  </option>
                ))}
              </select>
              {selectedCrop === 'Other / Custom' && (
                <input
                  type="text"
                  placeholder="Enter crop name (e.g. Ginger, Barley)"
                  value={customCrop}
                  onChange={(e) => setCustomCrop(e.target.value)}
                  className="mt-2 w-full p-2 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-serif text-[#1A1A1A] dark:text-white focus:outline-none focus:border-black"
                />
              )}
            </div>

            {/* Input 2: Crop Stage */}
            <div>
              <label className="block text-[10px] font-mono uppercase font-bold text-[#A19E95] mb-1.5">
                Crop Growth Stage
              </label>
              <select
                id="stage-selector"
                value={selectedStage}
                onChange={(e) => setSelectedStage(e.target.value)}
                className="w-full p-2.5 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-serif font-bold text-[#1A1A1A] dark:text-white focus:outline-none focus:border-black dark:focus:border-white"
              >
                {CROP_STAGES.map((stg) => (
                  <option key={stg} value={stg}>
                    {stg}
                  </option>
                ))}
              </select>
            </div>

            {/* Input 3: Location / Generate Button */}
            <div className="flex items-end">
              <button
                id="generate-advisory-btn"
                onClick={handleGenerateAdvisory}
                disabled={loading}
                className="w-full py-2.5 px-4 bg-[#1A1A1A] dark:bg-white hover:bg-[#F27D26] dark:hover:bg-[#F27D26] text-white dark:text-[#1A1A1A] dark:hover:text-white text-xs font-mono uppercase font-bold transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-[#F27D26]" />
                    <span>Analyzing Weather Variables...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-[#F27D26]" />
                    <span>Generate Crop Advisory</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-900 text-xs text-rose-800 dark:text-rose-200">
              {errorMsg}
            </div>
          )}
        </div>
      </div>

      {/* Real Weather Variables Analyzed for Location */}
      {weather && (
        <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
            <div>
              <span className="text-[10px] font-mono uppercase font-bold text-[#F27D26] tracking-wider block">
                Agro-Meteorological Telemetry
              </span>
              <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-white">
                Analyzed Weather & Forecast Data ({location.city})
              </h3>
            </div>
            <span className="text-xs font-mono text-[#A19E95]">
              Lat: {location.latitude.toFixed(2)}° • Lon: {location.longitude.toFixed(2)}°
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {/* Temperature */}
            <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#A19E95] uppercase font-bold mb-1">
                <Thermometer className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>Temperature</span>
              </div>
              <div className="text-lg font-serif font-bold text-[#1A1A1A] dark:text-white">
                {weather.current.temperature}°C
              </div>
              <div className="text-[10px] font-mono text-[#73716A] mt-0.5">
                Max {weather.daily[0]?.tempMax ?? weather.current.temperature}° / Min {weather.daily[0]?.tempMin ?? weather.current.temperature}°
              </div>
            </div>

            {/* Humidity */}
            <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#A19E95] uppercase font-bold mb-1">
                <Droplets className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>Humidity</span>
              </div>
              <div className="text-lg font-serif font-bold text-[#1A1A1A] dark:text-white">
                {weather.current.relativeHumidity}%
              </div>
              <div className="text-[10px] font-mono text-[#73716A] mt-0.5">
                {weather.current.relativeHumidity > 75 ? 'Elevated (Fungal risk)' : 'Moderate moisture'}
              </div>
            </div>

            {/* Rainfall */}
            <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#A19E95] uppercase font-bold mb-1">
                <CloudRain className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>Rain Today</span>
              </div>
              <div className="text-lg font-serif font-bold text-[#1A1A1A] dark:text-white">
                {weather.daily[0]?.precipitationSum ?? 0} mm
              </div>
              <div className="text-[10px] font-mono text-[#73716A] mt-0.5">
                {weather.daily[0]?.precipitationProbabilityMax ?? 0}% Probability
              </div>
            </div>

            {/* Wind */}
            <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#A19E95] uppercase font-bold mb-1">
                <Wind className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>Wind & Gusts</span>
              </div>
              <div className="text-lg font-serif font-bold text-[#1A1A1A] dark:text-white">
                {weather.current.windSpeed} km/h
              </div>
              <div className="text-[10px] font-mono text-[#73716A] mt-0.5">
                Gusts: {weather.daily[0]?.windGustsMax ?? weather.current.windGusts ?? weather.current.windSpeed} km/h
              </div>
            </div>

            {/* Heat Stress */}
            <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#A19E95] uppercase font-bold mb-1">
                <SunMedium className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>Heat Stress</span>
              </div>
              <div className="text-lg font-serif font-bold text-[#1A1A1A] dark:text-white">
                {(weather.daily[0]?.tempMax ?? 30) > 38 ? 'High' : (weather.daily[0]?.tempMax ?? 30) > 33 ? 'Moderate' : 'Normal'}
              </div>
              <div className="text-[10px] font-mono text-[#73716A] mt-0.5">
                Solar UV: {weather.current.uvIndex ?? 5}
              </div>
            </div>

            {/* 3-Day Forecast */}
            <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#A19E95] uppercase font-bold mb-1">
                <CalendarCheck className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>3-Day Outlook</span>
              </div>
              <div className="text-lg font-serif font-bold text-[#1A1A1A] dark:text-white">
                {((weather.daily[0]?.precipitationSum ?? 0) + (weather.daily[1]?.precipitationSum ?? 0) + (weather.daily[2]?.precipitationSum ?? 0)).toFixed(1)} mm
              </div>
              <div className="text-[10px] font-mono text-[#73716A] mt-0.5">
                Accumulated Rain
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Generated Advisory Output Section */}
      {advisory ? (
        <div id="advisory-output-section" className="space-y-6">
          {/* Advisory Identification Header */}
          <div className="bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider bg-[#F27D26] text-white">
                  {advisory.label || 'AI-generated weather-based advisory.'}
                </span>
                <span className="text-xs font-mono opacity-80">
                  Target: {advisory.crop} ({advisory.cropStage})
                </span>
              </div>
              <h3 className="font-serif font-bold text-xl tracking-tight">
                Weather-Based Advisory for {advisory.location}
              </h3>
            </div>

            <div className="text-right text-xs font-mono opacity-80">
              <span>Generated: {new Date(advisory.generatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              <span className="block text-[10px] opacity-70">Source: {advisory.source}</span>
            </div>
          </div>

          {/* 6 Core Generated Deliverables Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* 1. Irrigation Advice */}
            <div id="irrigation-advice-card" className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex items-center gap-2 text-[#1A1A1A] dark:text-white">
                  <Droplets className="w-4 h-4 text-[#F27D26]" />
                  <h4 className="font-serif font-bold text-base">1. Irrigation Advice</h4>
                </div>
                {getStatusBadge(advisory.irrigationAdvice?.status || 'Standard Irrigation', 'irrigation')}
              </div>

              <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-[#F5F4F0]">
                {advisory.irrigationAdvice?.recommendation || advisory.irrigationRecommendation}
              </p>

              <div className="pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-[#73716A]">
                <span>
                  <strong className="text-[#1A1A1A] dark:text-white">Timing: </strong>
                  {advisory.irrigationAdvice?.timing || 'Early morning hours'}
                </span>
                {typeof advisory.irrigationAdvice?.waterRequirementScore === 'number' && (
                  <span>
                    Demand Index: {advisory.irrigationAdvice.waterRequirementScore}/100
                  </span>
                )}
              </div>
            </div>

            {/* 2. Spraying Suitability */}
            <div id="spraying-suitability-card" className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex items-center gap-2 text-[#1A1A1A] dark:text-white">
                  <Bug className="w-4 h-4 text-[#F27D26]" />
                  <h4 className="font-serif font-bold text-base">2. Spraying Suitability</h4>
                </div>
                {getStatusBadge(advisory.sprayingSuitability?.suitability || 'Suitable', 'spraying')}
              </div>

              <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-[#F5F4F0]">
                {advisory.sprayingSuitability?.recommendation || advisory.sprayingRecommendation}
              </p>

              <div className="pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] space-y-1.5 text-[11px] font-mono text-[#73716A]">
                <div>
                  <strong className="text-[#1A1A1A] dark:text-white">Optimal Window: </strong>
                  {advisory.sprayingSuitability?.optimalWindow || 'Morning 7:00 AM - 10:00 AM'}
                </div>
                {advisory.sprayingSuitability?.limitingFactors && advisory.sprayingSuitability.limitingFactors.length > 0 && (
                  <div className="text-[10px] text-amber-700 dark:text-amber-400">
                    <span className="font-bold">Limiting Factors: </span>
                    {advisory.sprayingSuitability.limitingFactors.join(' • ')}
                  </div>
                )}
              </div>
            </div>

            {/* 3. Rain Protection */}
            <div id="rain-protection-card" className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex items-center gap-2 text-[#1A1A1A] dark:text-white">
                  <ShieldAlert className="w-4 h-4 text-[#F27D26]" />
                  <h4 className="font-serif font-bold text-base">3. Rain Protection</h4>
                </div>
                {getStatusBadge(advisory.rainProtection?.threatLevel || 'Low', 'threat')}
              </div>

              <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-[#F5F4F0]">
                {advisory.rainProtection?.recommendation || advisory.rainProtectionText || 'Maintain standard drainage channels.'}
              </p>

              {advisory.rainProtection?.drainageActions && advisory.rainProtection.drainageActions.length > 0 && (
                <div className="pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] space-y-1">
                  <span className="text-[10px] font-mono font-bold uppercase text-[#A19E95] block">Action Points:</span>
                  <ul className="space-y-1">
                    {advisory.rainProtection.drainageActions.map((action, i) => (
                      <li key={i} className="text-xs font-serif flex items-start gap-1.5 text-[#1A1A1A] dark:text-[#F5F4F0]">
                        <span className="text-[#F27D26] font-bold">•</span>
                        <span>{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* 4. Heat Protection */}
            <div id="heat-protection-card" className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex items-center gap-2 text-[#1A1A1A] dark:text-white">
                  <SunMedium className="w-4 h-4 text-[#F27D26]" />
                  <h4 className="font-serif font-bold text-base">4. Heat Protection</h4>
                </div>
                {getStatusBadge(advisory.heatProtection?.stressLevel || 'Low', 'threat')}
              </div>

              <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-[#F5F4F0]">
                {advisory.heatProtection?.recommendation || advisory.heatProtectionText || 'Normal thermal comfort zone for this crop.'}
              </p>

              {advisory.heatProtection?.mitigationActions && advisory.heatProtection.mitigationActions.length > 0 && (
                <div className="pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] space-y-1">
                  <span className="text-[10px] font-mono font-bold uppercase text-[#A19E95] block">Mitigation Measures:</span>
                  <ul className="space-y-1">
                    {advisory.heatProtection.mitigationActions.map((action, i) => (
                      <li key={i} className="text-xs font-serif flex items-start gap-1.5 text-[#1A1A1A] dark:text-[#F5F4F0]">
                        <span className="text-[#F27D26] font-bold">•</span>
                        <span>{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* 5. Harvest Considerations */}
            <div id="harvest-considerations-card" className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex items-center gap-2 text-[#1A1A1A] dark:text-white">
                  <CalendarCheck className="w-4 h-4 text-[#F27D26]" />
                  <h4 className="font-serif font-bold text-base">5. Harvest Considerations</h4>
                </div>
                {getStatusBadge(advisory.harvestConsiderations?.suitability || 'Favorable', 'harvest')}
              </div>

              <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-[#F5F4F0]">
                {advisory.harvestConsiderations?.recommendation || advisory.harvestRecommendation}
              </p>

              <div className="pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] text-[11px] font-serif text-[#73716A]">
                <strong className="text-[#1A1A1A] dark:text-white font-mono uppercase text-[10px] block mb-0.5">
                  Post-Harvest Handling & Storage:
                </strong>
                <p className="italic">
                  {advisory.harvestConsiderations?.dryingAndStorage || 'Ensure harvested grains are air-dried below 12-14% moisture before bagging.'}
                </p>
              </div>
            </div>

            {/* 6. Weather-Related Crop Risk */}
            <div id="weather-related-crop-risk-card" className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex items-center gap-2 text-[#1A1A1A] dark:text-white">
                  <AlertTriangle className="w-4 h-4 text-[#F27D26]" />
                  <h4 className="font-serif font-bold text-base">6. Weather-Related Crop Risk</h4>
                </div>
                {getStatusBadge(advisory.weatherRelatedCropRisk?.overallRisk || 'Low', 'risk')}
              </div>

              <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-[#F5F4F0] font-medium">
                {advisory.weatherRelatedCropRisk?.summary || advisory.diseaseRiskIndication}
              </p>

              <div className="pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] space-y-2 text-xs font-serif">
                {advisory.weatherRelatedCropRisk?.pestRisk && (
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase text-[#A19E95] block">Pest Trajectory:</span>
                    <p className="text-[#73716A] text-[11px]">{advisory.weatherRelatedCropRisk.pestRisk}</p>
                  </div>
                )}
                {advisory.weatherRelatedCropRisk?.diseaseRisk && (
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase text-[#A19E95] block">Disease Pressure:</span>
                    <p className="text-[#73716A] text-[11px]">{advisory.weatherRelatedCropRisk.diseaseRisk}</p>
                  </div>
                )}
                {advisory.weatherRelatedCropRisk?.physicalHazardRisk && (
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase text-[#A19E95] block">Physical / Mechanical Hazard:</span>
                    <p className="text-[#73716A] text-[11px]">{advisory.weatherRelatedCropRisk.physicalHazardRisk}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Detailed Weather Telemetry Breakdown Card */}
          {advisory.weatherAnalysis && (
            <div className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
              <h4 className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white">
                Detailed Meteorological Basis of Advisory
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-serif text-[#73716A]">
                <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
                  <span className="font-mono font-bold text-[10px] uppercase block text-[#1A1A1A] dark:text-white mb-1">
                    Thermal Comfort & Canopy
                  </span>
                  <p className="text-[11px]">{advisory.weatherAnalysis.temperature.assessment}</p>
                </div>
                <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
                  <span className="font-mono font-bold text-[10px] uppercase block text-[#1A1A1A] dark:text-white mb-1">
                    Foliar Moisture & Humidity
                  </span>
                  <p className="text-[11px]">{advisory.weatherAnalysis.humidity.assessment}</p>
                </div>
                <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
                  <span className="font-mono font-bold text-[10px] uppercase block text-[#1A1A1A] dark:text-white mb-1">
                    Precipitation & Water Balance
                  </span>
                  <p className="text-[11px]">{advisory.weatherAnalysis.rainfall.assessment}</p>
                </div>
              </div>
            </div>
          )}

          {/* Prominent Mandatory Compliance Disclaimer Footer */}
          <div className="p-5 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-2">
            <div className="flex items-center gap-2 text-[#1A1A1A] dark:text-white font-mono uppercase text-[10px] font-bold tracking-wider">
              <Info className="w-4 h-4 text-[#F27D26]" />
              <span>Mandatory Advisory Notice & Regulatory Guardrail</span>
            </div>
            <div className="p-3 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-serif text-[#73716A] space-y-1">
              <p className="font-bold text-[#1A1A1A] dark:text-white">
                {advisory.label || 'AI-generated weather-based advisory.'}
              </p>
              <p className="italic leading-relaxed">
                {advisory.disclaimer || 'This is an AI-generated weather-based advisory. Never present it as an official agricultural recommendation. For official chemical doses, seed certifications, and region-specific farm operations, consult your local Krishi Vigyan Kendra (KVK) or State Department of Agriculture.'}
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="p-12 text-center bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
          <div className="w-12 h-12 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white flex items-center justify-center mx-auto">
            <Sprout className="w-6 h-6 text-[#F27D26]" />
          </div>
          <h3 className="font-serif font-bold text-[#1A1A1A] dark:text-white text-lg">
            Generate Agrometeorological Advisory
          </h3>
          <p className="text-xs font-serif italic text-[#A19E95] max-w-md mx-auto">
            Select your crop and growth stage above to generate an AI-assisted, weather-calibrated advisory for {location.city} analyzing temperature, humidity, rainfall, wind drift, heat stress, and active alerts.
          </p>
          <span className="inline-block text-[10px] font-mono text-[#A19E95] uppercase">
            Clearly labeled: AI-generated weather-based advisory.
          </span>
        </div>
      )}
    </div>
  );
};
