import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Droplets,
  Thermometer,
  Calendar,
  Sparkles,
  Loader2,
  AlertTriangle,
  FileBarChart2,
  CheckCircle2,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';
import { useWeather } from '../contexts/WeatherContext';
import { HistoricalClimateData } from '../types/weather';
import { fetchClimateTrendsApi } from '../services/api';

export const ClimateView: React.FC = () => {
  const { location } = useWeather();
  const [climateData, setClimateData] = useState<HistoricalClimateData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [startYear, setStartYear] = useState(2018);
  const [endYear, setEndYear] = useState(2024);

  const loadClimateTrends = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchClimateTrendsApi(
        location.latitude,
        location.longitude,
        startYear,
        endYear,
        location.city
      );
      setClimateData(data);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch historical climate trends');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClimateTrends();
  }, [location, startYear, endYear]);

  return (
    <div id="climate-view-container" className="space-y-6">
      {/* Top Header & Year Range Filter */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-[#F27D26] block mb-1">
            Paleo & ERA5 Reanalysis Archive
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
            Historical Climate & Precipitation Analytics
          </h2>
          <p className="text-xs font-serif italic text-[#A19E95] mt-1">
            Analyzing multi-year trends for <span className="font-bold text-[#1A1A1A] dark:text-white">{location.city}</span> ({startYear} – {endYear})
          </p>
        </div>

        {/* Year Selectors */}
        <div className="flex items-center gap-3 bg-[#FAF9F6] dark:bg-[#201F1D] p-2.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-mono">
          <span className="text-[#A19E95] uppercase text-[10px] font-bold">Timeline:</span>
          <select
            value={startYear}
            onChange={(e) => setStartYear(Number(e.target.value))}
            className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] px-2 py-1 font-bold text-[#1A1A1A] dark:text-white focus:outline-none"
          >
            {[2015, 2016, 2017, 2018, 2019, 2020].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
          <span className="text-[#A19E95]">to</span>
          <select
            value={endYear}
            onChange={(e) => setEndYear(Number(e.target.value))}
            className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] px-2 py-1 font-bold text-[#1A1A1A] dark:text-white focus:outline-none"
          >
            {[2022, 2023, 2024, 2025].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading && (
        <div className="p-16 flex flex-col items-center justify-center gap-3 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
          <Loader2 className="w-8 h-8 animate-spin text-[#F27D26]" />
          <p className="text-xs font-mono text-[#A19E95] uppercase">
            Fetching ERA5 / Open-Meteo multi-year reanalysis archives for {location.city}...
          </p>
        </div>
      )}

      {error && !loading && (
        <div className="p-6 bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-rose-600 border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] text-xs text-[#1A1A1A] dark:text-white flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          <div>
            <p className="font-mono uppercase font-bold text-[10px]">Historical data retrieval issue</p>
            <p className="mt-0.5 font-serif italic">{error}</p>
          </div>
        </div>
      )}

      {!loading && climateData && (
        <>
          {/* Summary Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <span className="text-[10px] font-mono uppercase font-bold text-[#A19E95] block">Multi-Year Mean Temp</span>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-serif font-black text-[#1A1A1A] dark:text-white">
                  {climateData.overallAvgTemp}°C
                </span>
                <span
                  className={`text-[10px] font-mono font-bold flex items-center ${
                    climateData.tempTrendDiff >= 0 ? 'text-rose-600' : 'text-sky-600'
                  }`}
                >
                  {climateData.tempTrendDiff >= 0 ? (
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  ) : (
                    <ArrowDownRight className="w-3.5 h-3.5" />
                  )}
                  {Math.abs(climateData.tempTrendDiff)}°C trend
                </span>
              </div>
              <p className="text-[10px] font-serif italic text-[#A19E95] mt-1">Observed mean over {endYear - startYear + 1} years</p>
            </div>

            <div className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <span className="text-[10px] font-mono uppercase font-bold text-[#A19E95] block">Historical Baseline Rain</span>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-serif font-black text-[#1A1A1A] dark:text-white">
                  {climateData.historicalAvgRainfall} <span className="text-base font-normal font-mono">mm</span>
                </span>
              </div>
              <p className="text-[10px] font-serif italic text-[#A19E95] mt-1">Annual cumulative baseline</p>
            </div>

            <div className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <span className="text-[10px] font-mono uppercase font-bold text-[#A19E95] block">Recent Rainfall Shift</span>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-serif font-black text-[#1A1A1A] dark:text-white">
                  {climateData.recentAvgRainfall} <span className="text-base font-normal font-mono">mm</span>
                </span>
                <span
                  className={`text-[10px] font-mono font-bold flex items-center ${
                    climateData.rainfallTrendPercent >= 0 ? 'text-emerald-600' : 'text-amber-600'
                  }`}
                >
                  {climateData.rainfallTrendPercent >= 0 ? '+' : ''}
                  {climateData.rainfallTrendPercent}%
                </span>
              </div>
              <p className="text-[10px] font-serif italic text-[#A19E95] mt-1">Variance relative to historical baseline</p>
            </div>

            <div className="p-5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <span className="text-[10px] font-mono uppercase font-bold text-[#A19E95] block">Annual Rainy Days Avg</span>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-serif font-black text-[#1A1A1A] dark:text-white">
                  {Math.round(
                    climateData.yearlyAverages.reduce((acc, y) => acc + y.rainyDays, 0) /
                      (climateData.yearlyAverages.length || 1)
                  )}{' '}
                  <span className="text-base font-normal font-mono">days</span>
                </span>
              </div>
              <p className="text-[10px] font-serif italic text-[#A19E95] mt-1">Days with precipitation &gt; 1.0 mm</p>
            </div>
          </div>

          {/* Combined Recharts Chart */}
          <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6">
            <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-[#F27D26] block mb-1">
              Dual-Axis Climatology
            </span>
            <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-white mb-1">
              Annual Rainfall (mm) vs Mean Temperature (°C)
            </h3>
            <p className="text-xs font-serif italic text-[#A19E95] mb-6">
              Correlation between cumulative precipitation depth and mean annual thermal envelope
            </p>

            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={climateData.yearlyAverages} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
                  <CartesianGrid strokeDasharray="2 2" vertical={false} stroke="#E5E1DA" opacity={0.8} />
                  <XAxis dataKey="year" tick={{ fill: '#A19E95', fontSize: 11, fontFamily: 'monospace' }} />
                  <YAxis
                    yAxisId="rain"
                    orientation="left"
                    tick={{ fill: '#F27D26', fontSize: 11, fontFamily: 'monospace' }}
                    unit=" mm"
                  />
                  <YAxis
                    yAxisId="temp"
                    orientation="right"
                    domain={['dataMin - 2', 'dataMax + 2']}
                    tick={{ fill: '#1A1A1A', fontSize: 11, fontFamily: 'monospace' }}
                    unit="°C"
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="bg-[#1A1A1A] text-white text-xs p-3 font-mono border border-white space-y-1">
                            <p className="font-bold text-[#F27D26] text-sm uppercase">{d.year}</p>
                            <p>Rainfall: {d.totalRainfall} mm</p>
                            <p>Mean Temp: {d.avgTemp}°C</p>
                            <p>Peak Temp: {d.maxTemp}°C</p>
                            <p>Low Temp: {d.minTemp}°C</p>
                            <p>Rainy Days: {d.rainyDays} days</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: '11px' }} />
                  <Bar yAxisId="rain" dataKey="totalRainfall" name="Total Rainfall (mm)" fill="#F27D26" maxBarSize={32} />
                  <Line yAxisId="temp" type="monotone" dataKey="avgTemp" name="Mean Temp (°C)" stroke="#1A1A1A" strokeWidth={2} dot={{ r: 4, fill: '#1A1A1A' }} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* AI Climate Intelligence Synthesis */}
          <div className="bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-[#F27D26] border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] p-6">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-[#F27D26]" />
              <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-white">
                Gemini Climate Intelligence Synthesis
              </h3>
            </div>
            <p className="text-xs font-serif leading-relaxed text-[#1A1A1A] dark:text-slate-300 whitespace-pre-line">
              {climateData.aiExplanation}
            </p>
            <div className="mt-4 pt-3 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between text-[10px] font-mono uppercase text-[#A19E95]">
              <span>Source: Open-Meteo Historical Archive (ECMWF ERA5 Grounded)</span>
              <span>Regional sector: {location.name}</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
