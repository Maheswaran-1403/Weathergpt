import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { MapPin, Layers, Navigation, ZoomIn, ZoomOut } from 'lucide-react';
import { NormalizedLocation, NormalizedWeather } from '../types/weather';
import { useWeather } from '../contexts/WeatherContext';

interface WeatherMapProps {
  location: NormalizedLocation;
  weather: NormalizedWeather | null;
}

export const WeatherMap: React.FC<WeatherMapProps> = ({ location, weather }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const { formatTemp } = useWeather();

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // If map already exists, just re-center
    if (!mapInstanceRef.current) {
      // Initialize map
      const map = L.map(mapContainerRef.current, {
        center: [location.latitude, location.longitude],
        zoom: 9,
        zoomControl: false,
        attributionControl: false
      });

      // Tile layer from OpenStreetMap
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);

      // Custom pulse marker icon - Editorial signal orange
      const customIcon = L.divIcon({
        className: 'custom-weather-marker',
        html: `
          <div style="position: relative; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
            <div style="position: absolute; width: 32px; height: 32px; border-radius: 9999px; background-color: rgba(242, 125, 38, 0.3); animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
            <div style="position: relative; width: 14px; height: 14px; border-radius: 9999px; background-color: #F27D26; border: 2px solid #ffffff; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);"></div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const marker = L.marker([location.latitude, location.longitude], { icon: customIcon }).addTo(map);
      markerRef.current = marker;
      mapInstanceRef.current = map;
    } else {
      mapInstanceRef.current.setView([location.latitude, location.longitude], 9);
      if (markerRef.current) {
        markerRef.current.setLatLng([location.latitude, location.longitude]);
      }
    }

    // Update popup with current live weather
    if (markerRef.current && weather) {
      const popupContent = `
        <div style="font-family: serif; padding: 6px 8px; min-width: 150px;">
          <h4 style="font-weight: 700; font-size: 15px; margin: 0 0 4px 0; color: #1A1A1A;">${location.city}</h4>
          <p style="font-size: 20px; font-weight: 900; margin: 0 0 2px 0; font-family: monospace; color: #F27D26;">${formatTemp(weather.current.temperature)}</p>
          <p style="font-size: 12px; font-style: italic; margin: 0 0 4px 0; color: #1A1A1A;">${weather.current.weatherCondition}</p>
          <p style="font-size: 10px; font-family: monospace; margin: 0; color: #A19E95;">Wind: ${weather.current.windSpeed} km/h • Hum: ${weather.current.relativeHumidity}%</p>
        </div>
      `;
      markerRef.current.bindPopup(popupContent).openPopup();
    }

    return () => {
      // Cleanup on unmount handled gracefully
    };
  }, [location, weather, formatTemp]);

  // Clean up map when component unmounts
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  const handleZoomIn = () => mapInstanceRef.current?.zoomIn();
  const handleZoomOut = () => mapInstanceRef.current?.zoomOut();
  const handleRecenter = () => {
    mapInstanceRef.current?.setView([location.latitude, location.longitude], 10);
  };

  return (
    <div id="weather-map-container" className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] rounded-none overflow-hidden relative shadow-xs">
      {/* Header */}
      <div className="p-5 border-b border-[#E5E1DA] dark:border-[#2D2C2A] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-widest text-[#F27D26] block mb-1">
            Geographic Telemetry
          </span>
          <h3 className="font-serif font-bold text-[#1A1A1A] dark:text-white text-xl">
            Synoptic Meteorological Map: {location.city}
          </h3>
        </div>
        <div className="text-[10px] font-mono uppercase text-[#A19E95] tracking-wider">
          Lat: {location.latitude.toFixed(2)}° • Lon: {location.longitude.toFixed(2)}°
        </div>
      </div>

      {/* Map stage */}
      <div className="relative h-96 w-full z-10">
        <div ref={mapContainerRef} className="h-full w-full" />

        {/* Map On-Screen Controls */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-1.5">
          <button
            onClick={handleZoomIn}
            className="p-2 bg-white dark:bg-[#181816] text-[#1A1A1A] dark:text-white border border-[#E5E1DA] dark:border-[#2D2C2A] hover:border-black dark:hover:border-white transition"
            title="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-2 bg-white dark:bg-[#181816] text-[#1A1A1A] dark:text-white border border-[#E5E1DA] dark:border-[#2D2C2A] hover:border-black dark:hover:border-white transition"
            title="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={handleRecenter}
            className="p-2 bg-white dark:bg-[#181816] text-[#1A1A1A] dark:text-white border border-[#E5E1DA] dark:border-[#2D2C2A] hover:border-black dark:hover:border-white transition"
            title="Recenter on current location"
          >
            <Navigation className="w-4 h-4" />
          </button>
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 z-20 bg-white/95 dark:bg-[#181816]/95 border border-[#E5E1DA] dark:border-[#2D2C2A] p-2.5 text-[10px] font-mono uppercase flex items-center gap-3 text-[#1A1A1A] dark:text-[#F5F4F0]">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#F27D26]"></span>
            <span>Target Point</span>
          </div>
          <div className="flex items-center gap-1.5 text-[#A19E95]">
            <span>OSM Base GIS</span>
          </div>
        </div>
      </div>
    </div>
  );
};
