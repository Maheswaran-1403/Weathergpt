import React, { useState, useEffect } from 'react';
import {
  Compass,
  Plane,
  Ship,
  Car,
  ShieldAlert,
  Building2,
  Sprout,
  Activity,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { DecisionSupportItem } from '../types/weather';
import { fetchDecisionSupportApi } from '../services/api';

export const DecisionSupportView: React.FC = () => {
  const { location, weather } = useWeather();
  const [items, setItems] = useState<DecisionSupportItem[]>([]);
  const [loading, setLoading] = useState(true);

  const loadDecisions = async () => {
    setLoading(true);
    try {
      const data = await fetchDecisionSupportApi(
        location.latitude,
        location.longitude,
        location.city
      );
      setItems(data);
    } catch (err) {
      console.error('Failed to load decision support:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDecisions();
  }, [location]);

  const getCategoryIcon = (category: string) => {
    const props = { className: 'w-5 h-5' };
    switch (category) {
      case 'Agriculture': return <Sprout {...props} className="w-5 h-5 text-emerald-500" />;
      case 'Travel': return <Car {...props} className="w-5 h-5 text-indigo-500" />;
      case 'Outdoor Activity': return <Activity {...props} className="w-5 h-5 text-orange-500" />;
      case 'Urban Planning': return <Building2 {...props} className="w-5 h-5 text-blue-500" />;
      case 'Disaster Preparedness': return <ShieldAlert {...props} className="w-5 h-5 text-rose-500" />;
      case 'Aviation': return <Plane {...props} className="w-5 h-5 text-sky-500" />;
      case 'Marine': return <Ship {...props} className="w-5 h-5 text-cyan-500" />;
      default: return <Compass {...props} className="w-5 h-5 text-slate-500" />;
    }
  };

  const getStatusBadge = (status: 'Favorable' | 'Caution' | 'Adverse' | 'Severe') => {
    switch (status) {
      case 'Favorable':
        return (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase bg-emerald-700 text-white flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Favorable</span>
          </span>
        );
      case 'Caution':
        return (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase bg-amber-500 text-[#1A1A1A] flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            <span>Caution</span>
          </span>
        );
      case 'Adverse':
        return (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase bg-[#F27D26] text-white flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            <span>Adverse</span>
          </span>
        );
      case 'Severe':
        return (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase bg-rose-900 text-white flex items-center gap-1 animate-pulse">
            <XCircle className="w-3 h-3" />
            <span>Severe</span>
          </span>
        );
    }
  };

  return (
    <div id="decision-support-container" className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-[#F27D26] block mb-1">
            Cross-Sector Operations
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
            Operational Decision Support Matrix
          </h2>
          <p className="text-xs font-serif italic text-[#A19E95] mt-1">
            Cross-sector meteorological impact analysis for {location.city}
          </p>
        </div>

        <button
          onClick={loadDecisions}
          disabled={loading}
          className="p-2 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white hover:border-black dark:hover:border-white transition"
          title="Recalculate decision support"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#F27D26]' : ''}`} />
        </button>
      </div>

      {loading ? (
        <div className="p-16 flex flex-col items-center justify-center gap-3 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A]">
          <Loader2 className="w-8 h-8 animate-spin text-[#F27D26]" />
          <p className="text-xs font-mono text-[#A19E95] uppercase">Evaluating sector thresholds against live synoptic forecast...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {items.map((item, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-5 flex flex-col justify-between hover:border-black dark:hover:border-white transition"
            >
              <div>
                {/* Category & Status */}
                <div className="flex items-center justify-between mb-3 pb-3 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#F27D26]">
                      {getCategoryIcon(item.category)}
                    </div>
                    <h3 className="font-serif font-bold text-base text-[#1A1A1A] dark:text-white">
                      {item.category}
                    </h3>
                  </div>
                  {getStatusBadge(item.statusLevel)}
                </div>

                {/* Conditions & Forecast */}
                <div className="space-y-1 text-xs font-serif text-[#1A1A1A] dark:text-slate-300 mb-3">
                  <p>
                    <span className="font-mono text-[10px] uppercase font-bold text-[#A19E95]">Current: </span>
                    {item.currentCondition}
                  </p>
                  <p>
                    <span className="font-mono text-[10px] uppercase font-bold text-[#A19E95]">Forecast: </span>
                    {item.forecast}
                  </p>
                </div>

                {/* Recommendation */}
                <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-[#1A1A1A] dark:border-white border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-serif">
                  <span className="font-mono font-bold uppercase text-[10px] text-[#A19E95] block mb-1">
                    Guidance:
                  </span>
                  <p className="text-[#1A1A1A] dark:text-white leading-relaxed">
                    {item.recommendation}
                  </p>
                </div>
              </div>

              {/* Confidence Footer */}
              <div className="mt-4 pt-3 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between text-[10px] font-mono uppercase text-[#A19E95]">
                <span>Confidence:</span>
                <span className="font-bold text-[#1A1A1A] dark:text-white">{item.confidence}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
