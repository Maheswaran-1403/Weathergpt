import React, { useState, useEffect } from 'react';
import {
  Settings,
  Languages,
  Thermometer,
  Wind,
  Moon,
  Volume2,
  CheckCircle2,
  MapPin,
  Activity,
  Server,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { SUPPORTED_LANGUAGES, NormalizedLocation } from '../types/weather';

const PRESET_LOCATIONS: NormalizedLocation[] = [
  {
    city: 'Coimbatore',
    name: 'Coimbatore, Tamil Nadu, India',
    district: 'Coimbatore',
    state: 'Tamil Nadu',
    country: 'India',
    countryCode: 'IN',
    latitude: 11.0168,
    longitude: 76.9558,
    timezone: 'Asia/Kolkata'
  },
  {
    city: 'Chennai',
    name: 'Chennai, Tamil Nadu, India',
    district: 'Chennai',
    state: 'Tamil Nadu',
    country: 'India',
    countryCode: 'IN',
    latitude: 13.0827,
    longitude: 80.2707,
    timezone: 'Asia/Kolkata'
  },
  {
    city: 'New Delhi',
    name: 'New Delhi, Delhi, India',
    district: 'New Delhi',
    state: 'Delhi',
    country: 'India',
    countryCode: 'IN',
    latitude: 28.6139,
    longitude: 77.2090,
    timezone: 'Asia/Kolkata'
  },
  {
    city: 'Mumbai',
    name: 'Mumbai, Maharashtra, India',
    district: 'Mumbai',
    state: 'Maharashtra',
    country: 'India',
    countryCode: 'IN',
    latitude: 19.0760,
    longitude: 72.8777,
    timezone: 'Asia/Kolkata'
  },
  {
    city: 'Bengaluru',
    name: 'Bengaluru, Karnataka, India',
    district: 'Bengaluru Urban',
    state: 'Karnataka',
    country: 'India',
    countryCode: 'IN',
    latitude: 12.9716,
    longitude: 77.5946,
    timezone: 'Asia/Kolkata'
  },
  {
    city: 'Kolkata',
    name: 'Kolkata, West Bengal, India',
    district: 'Kolkata',
    state: 'West Bengal',
    country: 'India',
    countryCode: 'IN',
    latitude: 22.5726,
    longitude: 88.3639,
    timezone: 'Asia/Kolkata'
  }
];

export const SettingsView: React.FC = () => {
  const {
    location,
    setLocation,
    tempUnit,
    setTempUnit,
    windUnit,
    setWindUnit,
    language,
    setLanguage,
    theme,
    setTheme,
    voiceEnabled,
    setVoiceEnabled
  } = useWeather();

  const [backendHealth, setBackendHealth] = useState<any>(null);

  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => setBackendHealth(data))
      .catch(() => setBackendHealth({ status: 'offline' }));
  }, []);

  return (
    <div id="settings-view-container" className="space-y-6 max-w-4xl">
      {/* Title */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6">
        <div>
          <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-[#F27D26] block mb-1">
            System Parameters & Local Settings
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
            Settings & Operational Preferences
          </h2>
          <p className="text-xs font-serif italic text-[#A19E95] mt-1">
            Configure units, language localization, telemetry providers, and audio preferences
          </p>
        </div>
      </div>

      {/* Preset Quick Locations */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6">
        <h3 className="text-base font-serif font-bold text-[#1A1A1A] dark:text-white mb-1 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-[#F27D26]" />
          <span>Quick City Presets</span>
        </h3>
        <p className="text-xs font-serif italic text-[#A19E95] mb-4">
          Instantly pivot observation coordinates across key meteorological hubs
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {PRESET_LOCATIONS.map((preset) => {
            const isSelected = location.city.toLowerCase() === preset.city.toLowerCase();
            return (
              <button
                key={preset.city}
                onClick={() => setLocation(preset)}
                className={`p-3 border text-left text-xs font-mono transition flex items-center justify-between ${
                  isSelected
                    ? 'border-[#F27D26] bg-[#FAF9F6] dark:bg-[#201F1D] text-[#1A1A1A] dark:text-white font-bold'
                    : 'border-[#E5E1DA] dark:border-[#2D2C2A] hover:border-black dark:hover:border-white text-[#1A1A1A] dark:text-white'
                }`}
              >
                <span>{preset.city}</span>
                {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-[#F27D26]" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Preferences Grid */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 space-y-6">
        {/* Temperature Unit */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-3">
            <div className="p-1.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#F27D26]">
              <Thermometer className="w-4 h-4" />
            </div>
            <div>
              <span className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white block">
                Temperature Unit
              </span>
              <span className="text-xs font-serif italic text-[#A19E95]">
                Display temperatures in Celsius (°C) or Fahrenheit (°F)
              </span>
            </div>
          </div>

          <div className="flex border border-[#E5E1DA] dark:border-[#2D2C2A]">
            <button
              onClick={() => setTempUnit('C')}
              className={`px-3 py-1.5 text-xs font-mono uppercase font-bold transition ${
                tempUnit === 'C'
                  ? 'bg-[#1A1A1A] text-white dark:bg-white dark:text-[#1A1A1A]'
                  : 'text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white'
              }`}
            >
              Celsius (°C)
            </button>
            <button
              onClick={() => setTempUnit('F')}
              className={`px-3 py-1.5 text-xs font-mono uppercase font-bold transition border-l border-[#E5E1DA] dark:border-[#2D2C2A] ${
                tempUnit === 'F'
                  ? 'bg-[#1A1A1A] text-white dark:bg-white dark:text-[#1A1A1A]'
                  : 'text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white'
              }`}
            >
              Fahrenheit (°F)
            </button>
          </div>
        </div>

        {/* Wind Speed Unit */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-3">
            <div className="p-1.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#F27D26]">
              <Wind className="w-4 h-4" />
            </div>
            <div>
              <span className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white block">
                Wind Speed Unit
              </span>
              <span className="text-xs font-serif italic text-[#A19E95]">
                Display velocity in Kilometers per Hour (km/h) or Miles per Hour (mph)
              </span>
            </div>
          </div>

          <div className="flex border border-[#E5E1DA] dark:border-[#2D2C2A]">
            <button
              onClick={() => setWindUnit('km/h')}
              className={`px-3 py-1.5 text-xs font-mono uppercase font-bold transition ${
                windUnit === 'km/h'
                  ? 'bg-[#1A1A1A] text-white dark:bg-white dark:text-[#1A1A1A]'
                  : 'text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white'
              }`}
            >
              km/h
            </button>
            <button
              onClick={() => setWindUnit('mph')}
              className={`px-3 py-1.5 text-xs font-mono uppercase font-bold transition border-l border-[#E5E1DA] dark:border-[#2D2C2A] ${
                windUnit === 'mph'
                  ? 'bg-[#1A1A1A] text-white dark:bg-white dark:text-[#1A1A1A]'
                  : 'text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white'
              }`}
            >
              mph
            </button>
          </div>
        </div>

        {/* Language Selection */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-3">
            <div className="p-1.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#F27D26]">
              <Languages className="w-4 h-4" />
            </div>
            <div>
              <span className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white block">
                Multilingual AI Interface
              </span>
              <span className="text-xs font-serif italic text-[#A19E95]">
                Select output language for conversational explanations and advisories
              </span>
            </div>
          </div>

          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as any)}
            className="p-2 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-mono font-bold text-[#1A1A1A] dark:text-white focus:outline-none"
          >
            {SUPPORTED_LANGUAGES.map((l) => (
              <option key={l.code} value={l.code}>
                {l.nativeName} ({l.name})
              </option>
            ))}
          </select>
        </div>

        {/* Theme */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-3">
            <div className="p-1.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#F27D26]">
              <Moon className="w-4 h-4" />
            </div>
            <div>
              <span className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white block">
                Visual Theme
              </span>
              <span className="text-xs font-serif italic text-[#A19E95]">
                Adjust app display mode
              </span>
            </div>
          </div>

          <div className="flex border border-[#E5E1DA] dark:border-[#2D2C2A]">
            {(['light', 'dark', 'system'] as const).map((t, idx) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`px-3 py-1.5 text-xs font-mono uppercase font-bold capitalize transition ${
                  idx > 0 ? 'border-l border-[#E5E1DA] dark:border-[#2D2C2A]' : ''
                } ${
                  theme === t
                    ? 'bg-[#1A1A1A] text-white dark:bg-white dark:text-[#1A1A1A]'
                    : 'text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Voice Readout Toggle */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-1.5 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#F27D26]">
              <Volume2 className="w-4 h-4" />
            </div>
            <div>
              <span className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white block">
                Voice Audio Output
              </span>
              <span className="text-xs font-serif italic text-[#A19E95]">
                Enable synthesized speech responses in selected language
              </span>
            </div>
          </div>

          <input
            type="checkbox"
            checked={voiceEnabled}
            onChange={(e) => setVoiceEnabled(e.target.checked)}
            className="w-4 h-4 accent-[#F27D26] cursor-pointer"
          />
        </div>
      </div>

      {/* System & Architecture Diagnostics */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6">
        <h3 className="text-base font-serif font-bold text-[#1A1A1A] dark:text-white mb-3 flex items-center gap-2">
          <Server className="w-4 h-4 text-[#F27D26]" />
          <span>System Diagnostics & Telemetry Pipeline</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
          <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between">
            <span className="text-[#A19E95] uppercase text-[10px]">Express Backend Server</span>
            <span className="font-bold text-emerald-700 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>PORT 3000 LIVE</span>
            </span>
          </div>

          <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between">
            <span className="text-[#A19E95] uppercase text-[10px]">Open-Meteo Synoptic API</span>
            <span className="font-bold text-emerald-700 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>LIVE SYNCED</span>
            </span>
          </div>

          <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between">
            <span className="text-[#A19E95] uppercase text-[10px]">IMD Alert Engine</span>
            <span className="font-bold text-emerald-700 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>CRITERIA BENCHMARK</span>
            </span>
          </div>

          <div className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] flex items-center justify-between">
            <span className="text-[#A19E95] uppercase text-[10px]">Gemini Generative AI Model</span>
            <span className="font-bold text-[#F27D26] flex items-center gap-1">
              <Cpu className="w-3.5 h-3.5" />
              <span>{backendHealth?.geminiConfigured ? 'GEMINI-2.5-FLASH' : 'GROUNDED MODE'}</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
