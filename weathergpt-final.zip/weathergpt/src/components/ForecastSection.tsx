import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  Bar,
  ComposedChart,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';
import {
  Sun,
  CloudSun,
  Cloud,
  CloudFog,
  CloudDrizzle,
  CloudRain,
  CloudRainWind,
  CloudLightning,
  CloudHail,
  Snowflake,
  Wind,
  Droplets,
  Calendar,
  Clock
} from 'lucide-react';
import { HourlyForecastItem, DailyForecastItem } from '../types/weather';
import { useWeather } from '../contexts/WeatherContext';

interface ForecastSectionProps {
  hourly: HourlyForecastItem[];
  daily: DailyForecastItem[];
}

export const ForecastSection: React.FC<ForecastSectionProps> = ({ hourly, daily }) => {
  const { formatTemp, formatWind } = useWeather();
  const [activeTab, setActiveTab] = useState<'hourly' | 'daily'>('hourly');

  const getWeatherIconSmall = (iconName: string) => {
    const props = { className: 'w-5 h-5 text-amber-500' };
    switch (iconName) {
      case 'Sun': return <Sun {...props} />;
      case 'CloudSun': return <CloudSun {...props} className="w-5 h-5 text-amber-400" />;
      case 'Cloud': return <Cloud {...props} className="w-5 h-5 text-slate-400" />;
      case 'CloudFog': return <CloudFog {...props} className="w-5 h-5 text-slate-400" />;
      case 'CloudDrizzle': return <CloudDrizzle {...props} className="w-5 h-5 text-sky-400" />;
      case 'CloudRain': return <CloudRain {...props} className="w-5 h-5 text-blue-500" />;
      case 'CloudRainWind': return <CloudRainWind {...props} className="w-5 h-5 text-blue-600" />;
      case 'CloudLightning': return <CloudLightning {...props} className="w-5 h-5 text-amber-500" />;
      case 'CloudHail': return <CloudHail {...props} className="w-5 h-5 text-cyan-400" />;
      case 'Snowflake': return <Snowflake {...props} className="w-5 h-5 text-sky-200" />;
      default: return <Sun {...props} />;
    }
  };

  // Format hourly chart data
  const chartData = hourly.slice(0, 24).map((h) => {
    const d = new Date(h.time);
    const hourLabel = d.toLocaleTimeString([], { hour: 'numeric', hour12: true });
    return {
      time: hourLabel,
      temp: h.temperature,
      rainProb: h.precipitationProbability,
      precip: h.precipitation,
      condition: h.weatherCondition,
      wind: h.windSpeed
    };
  });

  return (
    <div id="forecast-section" className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 sm:p-8 rounded-none transition-colors">
      {/* Header with toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-widest border-b border-black dark:border-white inline-block mb-2">
            Atmospheric Progression
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
            Outlook & Synoptic Trajectory
          </h2>
        </div>

        <div className="flex border border-[#E5E1DA] dark:border-[#2D2C2A] bg-[#FAF9F6] dark:bg-[#201F1D] p-0.5">
          <button
            id="tab-hourly"
            onClick={() => setActiveTab('hourly')}
            className={`px-3 py-1 text-xs font-mono uppercase font-bold transition ${
              activeTab === 'hourly'
                ? 'bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A]'
                : 'text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white'
            }`}
          >
            24-Hour Trend
          </button>
          <button
            id="tab-daily"
            onClick={() => setActiveTab('daily')}
            className={`px-3 py-1 text-xs font-mono uppercase font-bold transition ${
              activeTab === 'daily'
                ? 'bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A]'
                : 'text-[#A19E95] hover:text-[#1A1A1A] dark:hover:text-white'
            }`}
          >
            7-Day Horizon
          </button>
        </div>
      </div>

      {/* Hourly Chart */}
      {activeTab === 'hourly' && (
        <div className="pt-6">
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F27D26" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#F27D26" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="2 2" vertical={false} stroke="#E5E1DA" opacity={0.6} />
                <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#A19E95', fontFamily: 'monospace' }} tickLine={false} />
                <YAxis
                  yAxisId="left"
                  tick={{ fontSize: 10, fill: '#A19E95', fontFamily: 'monospace' }}
                  tickLine={false}
                  unit="°"
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  domain={[0, 100]}
                  tick={{ fontSize: 10, fill: '#F27D26', fontFamily: 'monospace' }}
                  tickLine={false}
                  unit="%"
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#1A1A1A] text-white text-xs p-3 border border-[#E5E1DA] font-mono">
                          <p className="font-bold text-[#F27D26] mb-1">{data.time}</p>
                          <p>Temperature: {data.temp}°C</p>
                          <p>Rain Probability: {data.rainProb}%</p>
                          <p>Rain Volume: {data.precip} mm</p>
                          <p className="text-[#A19E95]">Wind: {data.wind} km/h</p>
                          <p className="font-serif italic mt-1 text-amber-200">{data.condition}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar yAxisId="right" dataKey="rainProb" fill="#1A1A1A" radius={[0, 0, 0, 0]} maxBarSize={12} opacity={0.4} />
                <Area yAxisId="left" type="monotone" dataKey="temp" stroke="#F27D26" strokeWidth={2.5} fillOpacity={1} fill="url(#tempGradient)" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Hourly Timeline horizontal scroll strip */}
          <div className="mt-4 pt-4 border-t border-[#E5E1DA] dark:border-[#2D2C2A] flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
            {hourly.slice(0, 14).map((item, idx) => (
              <div
                key={idx}
                className="shrink-0 flex flex-col items-center justify-between p-2.5 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] w-20 text-center"
              >
                <span className="text-[10px] font-mono uppercase text-[#A19E95]">
                  {new Date(item.time).toLocaleTimeString([], { hour: 'numeric', hour12: true })}
                </span>
                <div className="my-1.5">
                  {getWeatherIconSmall(item.weatherCode > 50 ? 'CloudRain' : 'Sun')}
                </div>
                <span className="font-mono font-bold text-xs text-[#1A1A1A] dark:text-white">
                  {formatTemp(item.temperature)}
                </span>
                <span className="text-[10px] font-mono text-[#F27D26] font-semibold mt-1">
                  {item.precipitationProbability}%
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7-Day Forecast Cards */}
      {activeTab === 'daily' && (
        <div className="pt-6 space-y-2">
          {daily.map((day, idx) => {
            const dateObj = new Date(day.date);
            const isToday = idx === 0;
            const isTomorrow = idx === 1;
            const dayName = isToday
              ? 'Today'
              : isTomorrow
              ? 'Tomorrow'
              : dateObj.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });

            return (
              <div
                key={day.date}
                className={`flex flex-col sm:flex-row sm:items-center justify-between p-3.5 border transition ${
                  isToday
                    ? 'bg-[#FAF9F6] dark:bg-[#201F1D] border-[#1A1A1A] dark:border-white'
                    : 'bg-white dark:bg-[#181816] border-[#E5E1DA] dark:border-[#2D2C2A]'
                }`}
              >
                {/* Day name & icon */}
                <div className="flex items-center gap-3 w-48">
                  <div className="p-2 border border-[#E5E1DA] dark:border-[#2D2C2A] bg-[#FAF9F6] dark:bg-[#201F1D]">
                    {getWeatherIconSmall(day.weatherIcon)}
                  </div>
                  <div>
                    <span className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white block">
                      {dayName}
                    </span>
                    <span className="text-xs font-serif italic text-[#A19E95]">
                      {day.weatherCondition}
                    </span>
                  </div>
                </div>

                {/* Rain probability & precipitation */}
                <div className="flex items-center gap-5 my-2 sm:my-0 text-xs font-mono">
                  <div className="flex items-center gap-1.5 text-[#F27D26] font-semibold">
                    <Droplets className="w-3.5 h-3.5" />
                    <span>{day.precipitationProbabilityMax}%</span>
                    {day.precipitationSum > 0 && (
                      <span className="text-[#A19E95]">({day.precipitationSum} mm)</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 text-[#A19E95]">
                    <Wind className="w-3.5 h-3.5" />
                    <span>{formatWind(day.windSpeedMax)}</span>
                  </div>
                </div>

                {/* Temp Max / Min range */}
                <div className="flex items-center gap-2 font-mono font-bold text-sm">
                  <span className="text-[#1A1A1A] dark:text-white">{formatTemp(day.tempMax)}</span>
                  <span className="text-[#A19E95] font-normal">/</span>
                  <span className="text-[#A19E95] font-normal">{formatTemp(day.tempMin)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
