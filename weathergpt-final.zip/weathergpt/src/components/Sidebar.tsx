import React from 'react';
import {
  LayoutDashboard,
  Bot,
  CalendarDays,
  Map as MapIcon,
  AlertTriangle,
  TrendingUp,
  Sprout,
  Compass,
  Settings,
  ShieldAlert,
  GitCompareArrows
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const { imdData } = useWeather();
  const alertCount = imdData?.activeAlerts?.length ?? 0;

  const NAV_ITEMS = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'chat', label: 'AI WeatherGPT', icon: Bot, badge: 'AI' },
    { id: 'forecast', label: 'Forecast', icon: CalendarDays },
    { id: 'map', label: 'Weather Map', icon: MapIcon },
    { id: 'nwp', label: 'NWP Models', icon: GitCompareArrows },
    {
      id: 'alerts',
      label: 'Alerts & IMD',
      icon: AlertTriangle,
      badge: alertCount > 0 ? alertCount.toString() : undefined,
      badgeColor: 'bg-amber-500 text-white'
    },
    { id: 'climate', label: 'Climate Analytics', icon: TrendingUp },
    { id: 'agriculture', label: 'Agriculture', icon: Sprout },
    { id: 'decision', label: 'Decision Support', icon: Compass },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <>
      {/* Desktop & Tablet Sidebar */}
      <aside id="app-sidebar" className="hidden lg:flex flex-col w-[240px] border-r border-[#E5E1DA] dark:border-[#2D2C2A] bg-white dark:bg-[#181816] shrink-0 select-none p-6">
        <div className="mb-8">
          <h1 className="text-2xl font-black tracking-tighter leading-none italic uppercase font-serif text-[#1A1A1A] dark:text-white">
            WeatherGPT
          </h1>
          <p className="text-[9px] uppercase tracking-widest text-[#A19E95] mt-1.5 font-bold">
            Climate Intelligence v4.0
          </p>
        </div>

        <div className="flex flex-col gap-4">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`w-full text-left transition flex items-center justify-between py-1 ${
                  isActive
                    ? 'text-black dark:text-white font-bold border-b-2 border-black dark:border-white pb-1.5'
                    : 'text-[#A19E95] hover:text-black dark:hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {isActive ? (
                    <span className="w-2 h-2 rounded-full bg-[#F27D26] shrink-0" />
                  ) : (
                    <Icon className="w-4 h-4 text-[#A19E95] shrink-0" />
                  )}
                  <span className="text-xs uppercase tracking-wider font-semibold">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-xs font-mono font-bold ${
                      isActive ? 'bg-[#F27D26] text-white' : 'bg-[#E5E1DA] dark:bg-[#2D2C2A] text-[#1A1A1A] dark:text-[#A19E95]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Local Alert Editorial Box */}
        <div className="mt-auto pt-6 border-t border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="bg-[#F27D26] text-white p-4 rounded-xs shadow-xs">
            <p className="text-[10px] uppercase font-bold tracking-widest mb-1 font-sans">
              Local Alert
            </p>
            <p className="text-xs font-serif italic leading-relaxed">
              {imdData?.activeAlerts && imdData.activeAlerts.length > 0
                ? `${imdData.activeAlerts[0].type} for ${imdData.activeAlerts[0].affectedLocation}. Precautions advised for the next 24 hours.`
                : 'Normal atmospheric conditions across synoptic sector. No severe warning.'}
            </p>
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <nav id="mobile-bottom-nav" className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#181816]/95 backdrop-blur-md border-t border-[#E5E1DA] dark:border-[#2D2C2A] px-2 py-1 flex items-center justify-around shadow-sm">
        {NAV_ITEMS.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`mobile-nav-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-2 text-[10px] uppercase tracking-wider font-semibold transition ${
                isActive
                  ? 'text-[#F27D26] border-t-2 border-[#F27D26] -mt-[2px]'
                  : 'text-[#A19E95] hover:text-black dark:hover:text-white'
              }`}
            >
              <div className="relative">
                <Icon className="w-4 h-4 mb-0.5" />
                {item.badge && (
                  <span className="absolute -top-1 -right-2 w-3.5 h-3.5 rounded-full bg-[#F27D26] text-white text-[8px] flex items-center justify-center font-bold font-mono">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="truncate max-w-[60px] text-[9px]">{item.label}</span>
            </button>
          );
        })}
        {/* More button to toggle to other views */}
        <button
          id="mobile-nav-more"
          onClick={() => setActiveTab(activeTab === 'climate' ? 'agriculture' : activeTab === 'agriculture' ? 'decision' : 'climate')}
          className={`flex flex-col items-center justify-center py-1.5 px-2 text-[10px] uppercase tracking-wider font-semibold ${
            ['climate', 'agriculture', 'decision', 'settings'].includes(activeTab)
              ? 'text-[#F27D26]'
              : 'text-[#A19E95]'
          }`}
        >
          <Compass className="w-4 h-4 mb-0.5" />
          <span className="text-[9px]">More</span>
        </button>
      </nav>
    </>
  );
};
