import React from 'react';
import {
  CloudSun,
  Calendar,
  CloudRain,
  AlertTriangle,
  Sprout,
  TrendingUp,
  Plane,
  Car,
  Mic
} from 'lucide-react';

interface QuickActionButtonsProps {
  onSelectAction: (actionId: string) => void;
  onOpenVoice: () => void;
}

export const QuickActionButtons: React.FC<QuickActionButtonsProps> = ({ onSelectAction, onOpenVoice }) => {
  const ACTIONS = [
    { id: 'dashboard', label: 'Current Weather', icon: CloudSun, color: 'text-amber-500' },
    { id: 'forecast', label: '7-Day Forecast', icon: Calendar, color: 'text-indigo-500' },
    { id: 'forecast', label: 'Rain Prediction', icon: CloudRain, color: 'text-sky-500' },
    { id: 'alerts', label: 'Weather Alerts', icon: AlertTriangle, color: 'text-rose-500' },
    { id: 'agriculture', label: 'Crop Advisory', icon: Sprout, color: 'text-emerald-500' },
    { id: 'climate', label: 'Climate Trends', icon: TrendingUp, color: 'text-purple-500' },
    { id: 'decision', label: 'Aviation Brief', icon: Plane, color: 'text-blue-500' },
    { id: 'decision', label: 'Travel Advisory', icon: Car, color: 'text-teal-500' },
  ];

  return (
    <div id="quick-action-strip" className="mb-6 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
      <button
        onClick={onOpenVoice}
        className="shrink-0 px-3 py-1.5 bg-[#F27D26] hover:bg-[#d96a1a] text-white text-[10px] font-mono uppercase font-bold flex items-center gap-1.5 transition rounded-none"
      >
        <Mic className="w-3.5 h-3.5 animate-pulse" />
        <span>Voice Query</span>
      </button>

      {ACTIONS.map((action, idx) => {
        const Icon = action.icon;
        return (
          <button
            key={idx}
            onClick={() => onSelectAction(action.id)}
            className="shrink-0 px-3 py-1.5 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-[#F5F4F0] hover:border-[#1A1A1A] dark:hover:border-white text-[10px] font-mono uppercase font-bold flex items-center gap-1.5 transition rounded-none"
          >
            <Icon className="w-3.5 h-3.5 text-[#A19E95]" />
            <span>{action.label}</span>
          </button>
        );
      })}
    </div>
  );
};
