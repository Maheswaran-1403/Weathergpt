import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  MapPin,
  Compass,
  Languages,
  Sun,
  Moon,
  Mic,
  RefreshCw,
  Loader2,
  CloudLightning,
  AlertCircle
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { SUPPORTED_LANGUAGES, NormalizedLocation, SupportedLanguage } from '../types/weather';
import { searchLocationsApi } from '../services/api';

interface NavbarProps {
  onOpenVoice: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenVoice, activeTab, setActiveTab }) => {
  const {
    location,
    setLocation,
    useCurrentLocation,
    language,
    setLanguage,
    theme,
    setTheme,
    refreshWeather,
    loading
  } = useWeather();

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<NormalizedLocation[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const langRef = useRef<HTMLDivElement>(null);

  // Debounced search
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      setIsDropdownOpen(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await searchLocationsApi(searchQuery);
        setSearchResults(results);
        setIsDropdownOpen(results.length > 0);
      } catch (err) {
        console.warn('Search query error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Click outside to close
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setIsLangOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectLocation = (loc: NormalizedLocation) => {
    setLocation(loc);
    setSearchQuery('');
    setIsDropdownOpen(false);
  };

  return (
    <header id="app-header" className="sticky top-0 z-30 bg-white/95 dark:bg-[#181816]/95 backdrop-blur-sm border-b border-[#E5E1DA] dark:border-[#2D2C2A] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-[72px] flex items-center justify-between gap-3">
        {/* Brand (visible on mobile or for context) */}
        <div className="flex items-center gap-3 cursor-pointer shrink-0" onClick={() => setActiveTab('dashboard')}>
          <div className="w-9 h-9 bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] flex items-center justify-center font-serif italic font-black text-base shadow-xs">
            W
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif italic font-bold text-lg tracking-tight text-[#1A1A1A] dark:text-white uppercase">WeatherGPT</span>
              <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase bg-[#F27D26] text-white">
                SIH v4.0
              </span>
            </div>
            <p className="text-[9px] uppercase tracking-widest text-[#A19E95] font-bold hidden sm:block">Climate Intelligence</p>
          </div>
        </div>

        {/* Location Search Bar - Editorial styling with SEARCH tag and italic serif input */}
        <div ref={searchRef} className="relative flex-1 max-w-md mx-2">
          <div className="relative flex items-center bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] px-2 py-1">
            <span className="text-[10px] font-mono uppercase bg-[#1A1A1A] dark:bg-white text-white dark:text-[#1A1A1A] px-2 py-1 font-bold shrink-0">
              Search
            </span>
            <input
              id="location-search-input"
              type="text"
              placeholder={`${location.city}, ${location.state || location.country}`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => searchResults.length > 0 && setIsDropdownOpen(true)}
              className="w-full pl-3 pr-6 py-1 text-sm font-serif italic text-[#1A1A1A] dark:text-white placeholder-[#A19E95] bg-transparent focus:outline-none"
            />
            {isSearching && (
              <Loader2 className="w-3.5 h-3.5 absolute right-3 text-[#F27D26] animate-spin" />
            )}
          </div>

          {/* Autocomplete Dropdown */}
          {isDropdownOpen && (
            <div className="absolute left-0 right-0 mt-1 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] shadow-lg z-50 max-h-72 overflow-y-auto divide-y divide-[#E5E1DA] dark:divide-[#2D2C2A]">
              {searchResults.map((item, idx) => (
                <button
                  key={`${item.latitude}-${item.longitude}-${idx}`}
                  id={`search-result-${idx}`}
                  onClick={() => handleSelectLocation(item)}
                  className="w-full px-4 py-2.5 text-left text-xs hover:bg-[#FAF9F6] dark:hover:bg-[#201F1D] flex items-center gap-2.5 transition"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#F27D26] shrink-0" />
                  <div className="truncate">
                    <span className="font-serif font-bold text-[#1A1A1A] dark:text-white text-sm">{item.city}</span>
                    <span className="text-[11px] font-sans text-[#A19E95] ml-2">
                      {[item.district, item.state, item.country].filter(Boolean).join(', ')}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* System Status & Action Controls */}
        <div className="flex items-center gap-2">
          {/* Editorial System Status */}
          <div className="hidden xl:flex items-center gap-2.5 pr-3 border-r border-[#E5E1DA] dark:border-[#2D2C2A]">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#A19E95]">System Status</span>
            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
          </div>

          {/* Current GPS Location */}
          <button
            id="use-current-location-btn"
            onClick={useCurrentLocation}
            title="Use current GPS location"
            className="p-2 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white hover:border-black dark:hover:border-white transition"
          >
            <Compass className="w-4 h-4" />
          </button>

          {/* Voice Assistant Button */}
          <button
            id="voice-assistant-btn"
            onClick={onOpenVoice}
            title="Voice query & speech response"
            className="px-3 py-2 bg-[#F27D26] hover:bg-[#d96a1a] text-white transition flex items-center gap-1.5 text-xs font-mono uppercase font-bold"
          >
            <Mic className="w-3.5 h-3.5 animate-pulse" />
            <span className="hidden md:inline">Voice</span>
          </button>

          {/* Language Selector Dropdown */}
          <div ref={langRef} className="relative">
            <button
              id="language-selector-btn"
              onClick={() => setIsLangOpen(!isLangOpen)}
              className="p-2 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white hover:border-black dark:hover:border-white transition flex items-center gap-1 text-xs"
              title="Select Language"
            >
              <Languages className="w-4 h-4" />
              <span className="font-mono font-bold uppercase text-[11px] hidden sm:inline">{language}</span>
            </button>

            {isLangOpen && (
              <div className="absolute right-0 mt-1 w-44 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] shadow-lg py-1 z-50">
                <div className="px-3 py-1.5 text-[9px] font-bold text-[#A19E95] uppercase tracking-widest">
                  Select Language
                </div>
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    id={`lang-option-${lang.code}`}
                    onClick={() => {
                      setLanguage(lang.code);
                      setIsLangOpen(false);
                    }}
                    className={`w-full px-3 py-1.5 text-left text-xs font-serif flex items-center justify-between transition ${
                      language === lang.code
                        ? 'bg-[#FAF9F6] dark:bg-[#201F1D] text-[#F27D26] font-bold'
                        : 'text-[#1A1A1A] dark:text-slate-300 hover:bg-[#FAF9F6] dark:hover:bg-[#201F1D]'
                    }`}
                  >
                    <span>{lang.nativeName}</span>
                    <span className="text-[10px] font-mono text-[#A19E95]">({lang.name})</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Theme Toggle */}
          <button
            id="theme-toggle-btn"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            title="Toggle theme"
            className="p-2 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white hover:border-black dark:hover:border-white transition"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-[#1A1A1A]" />}
          </button>

          {/* Refresh Data */}
          <button
            id="refresh-weather-btn"
            onClick={refreshWeather}
            title="Refresh weather telemetry"
            disabled={loading}
            className="p-2 border border-[#E5E1DA] dark:border-[#2D2C2A] text-[#1A1A1A] dark:text-white hover:border-black dark:hover:border-white transition disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#F27D26]' : ''}`} />
          </button>
        </div>
      </div>
    </header>
  );
};
