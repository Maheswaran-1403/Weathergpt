import React from 'react';
import { AlertTriangle, ShieldCheck, Info, ExternalLink } from 'lucide-react';
import { WeatherAlert, AlertSeverity } from '../types/weather';
import { useWeather } from '../contexts/WeatherContext';

interface AlertsBannerProps {
  alerts?: WeatherAlert[];
  onViewAll?: () => void;
}

export const AlertsBanner: React.FC<AlertsBannerProps> = ({ alerts: propAlerts, onViewAll }) => {
  const { imdData } = useWeather();
  const alerts = propAlerts || imdData?.activeAlerts || [];

  // If IMD data is unavailable, explicitly show the required message
  if (imdData?.dataUnavailable) {
    return (
      <div id="alerts-banner-unavailable" className="mb-6 p-4 rounded-none border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-[#201c14] text-amber-900 dark:text-amber-200 flex items-start gap-3">
        <Info className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-serif font-bold text-sm tracking-tight">Official IMD warning data is currently unavailable.</span>
            <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-amber-200 dark:bg-amber-900 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-100">
              OFFLINE NOTICE
            </span>
          </div>
          <p className="text-xs font-serif italic text-amber-700 dark:text-amber-300 mt-1">
            Official IMD warning data is currently unavailable. No synthetic alerts are fabricated. Please check back shortly or consult regional IMD bulletins.
          </p>
        </div>
      </div>
    );
  }

  // If no alerts are active, show GREEN baseline
  if (!alerts || alerts.length === 0) {
    return (
      <div id="alerts-banner-green" className="mb-6 p-4 rounded-none border border-[#E5E1DA] dark:border-[#2D2C2A] bg-white dark:bg-[#181816] text-[#1A1A1A] dark:text-[#F5F4F0] flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-serif font-bold text-sm tracking-tight">No Severe Weather Warning Active</span>
            <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-emerald-700 dark:text-emerald-400">
              GREEN: NO WARNING
            </span>
          </div>
          <p className="text-xs font-serif italic text-[#A19E95] mt-1">
            Atmospheric parameters and synoptic charts indicate normal conditions across this district according to official IMD records.
          </p>
        </div>
      </div>
    );
  }

  const highestSeverity: AlertSeverity = alerts.some((a) => a.severity === 'RED')
    ? 'RED'
    : alerts.some((a) => a.severity === 'ORANGE')
    ? 'ORANGE'
    : alerts.some((a) => a.severity === 'YELLOW')
    ? 'YELLOW'
    : 'GREEN';

  const severityStyles = {
    RED: {
      bg: 'bg-rose-900 text-white',
      border: 'border-rose-950',
      badge: 'bg-white text-rose-900',
      badgeText: 'RED - Immediate Action Required',
      iconColor: 'text-white'
    },
    ORANGE: {
      bg: 'bg-[#F27D26] text-white',
      border: 'border-[#1A1A1A]',
      badge: 'bg-[#1A1A1A] text-white',
      badgeText: 'ORANGE - Be Prepared',
      iconColor: 'text-white'
    },
    YELLOW: {
      bg: 'bg-amber-500 text-[#1A1A1A]',
      border: 'border-amber-600',
      badge: 'bg-[#1A1A1A] text-white',
      badgeText: 'YELLOW - Be Updated',
      iconColor: 'text-[#1A1A1A]'
    },
    GREEN: {
      bg: 'bg-emerald-700 text-white',
      border: 'border-emerald-800',
      badge: 'bg-white text-emerald-900',
      badgeText: 'GREEN - Normal Conditions',
      iconColor: 'text-white'
    }
  }[highestSeverity];

  const primaryAlert = alerts[0];

  return (
    <div id="alerts-banner-active" className={`mb-6 p-4 rounded-none border ${severityStyles.border} ${severityStyles.bg} transition-all`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <AlertTriangle className={`w-5 h-5 ${severityStyles.iconColor} mt-0.5 shrink-0`} />
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-serif font-bold text-sm tracking-tight">Official Weather Warning Active</span>
              <span className={`px-2 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider ${severityStyles.badge}`}>
                {severityStyles.badgeText}
              </span>
            </div>
            <p className="text-xs mt-1 leading-relaxed font-serif italic">
              {primaryAlert.type} ({primaryAlert.affectedLocation}): {primaryAlert.description}
            </p>
            {primaryAlert.recommendedAction && (
              <p className="text-[11px] mt-1.5 font-mono bg-black/20 p-2 rounded-none">
                <span className="font-bold uppercase tracking-wider">Recommended Safety Action: </span>
                {primaryAlert.recommendedAction}
              </p>
            )}
            <div className="flex flex-wrap items-center gap-3 mt-2 text-[10px] font-mono opacity-90">
              <span>Official source: {primaryAlert.source}</span>
              {primaryAlert.validityRange && (
                <>
                  <span>•</span>
                  <span>Validity: {primaryAlert.validityRange}</span>
                </>
              )}
              {primaryAlert.issueTimeFormatted && (
                <>
                  <span>•</span>
                  <span>Issued: {primaryAlert.issueTimeFormatted}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {onViewAll && alerts.length > 1 && (
          <button
            onClick={onViewAll}
            className="text-xs font-mono uppercase font-bold underline shrink-0 hover:opacity-80 flex items-center gap-1"
          >
            <span>+{alerts.length - 1} more</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        )}
      </div>
    </div>
  );
};
