import React from 'react';
import {
  AlertTriangle,
  ShieldCheck,
  Clock,
  MapPin,
  Info,
  Radio,
  ExternalLink,
  ShieldAlert,
  Calendar,
  RefreshCw,
  Eye,
  CheckCircle2,
  AlertOctagon
} from 'lucide-react';
import { useWeather } from '../contexts/WeatherContext';
import { WeatherAlert, AlertSeverity, ImdDistrictWarningDay } from '../types/weather';

export const AlertsView: React.FC = () => {
  const { location, imdData, refreshWeather, loading } = useWeather();

  const alerts = imdData?.activeAlerts || [];
  const districtWarnings = imdData?.districtWarnings;
  const districtNowcast = imdData?.districtNowcast;
  const isDataUnavailable = Boolean(imdData?.dataUnavailable);

  const getSeverityBadge = (sev: AlertSeverity, label?: string) => {
    switch (sev) {
      case 'RED':
        return (
          <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-rose-900 text-white flex items-center gap-1">
            <AlertOctagon className="w-3.5 h-3.5" />
            <span>{label || 'RED WARNING: IMMEDIATE ACTION REQUIRED'}</span>
          </span>
        );
      case 'ORANGE':
        return (
          <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-[#ea580c] text-white flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{label || 'ORANGE ALERT: BE PREPARED'}</span>
          </span>
        );
      case 'YELLOW':
        return (
          <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-amber-500 text-[#1A1A1A] flex items-center gap-1">
            <Info className="w-3.5 h-3.5" />
            <span>{label || 'YELLOW WATCH: BE UPDATED'}</span>
          </span>
        );
      case 'GREEN':
      default:
        return (
          <span className="px-2.5 py-1 text-[10px] font-mono font-bold bg-emerald-700 text-white flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{label || 'GREEN: NO WARNING'}</span>
          </span>
        );
    }
  };

  const getDayColorIndicator = (code: AlertSeverity) => {
    switch (code) {
      case 'RED':
        return 'bg-rose-900 text-white border-rose-950';
      case 'ORANGE':
        return 'bg-[#ea580c] text-white border-[#c2410c]';
      case 'YELLOW':
        return 'bg-amber-500 text-black border-amber-600';
      case 'GREEN':
      default:
        return 'bg-emerald-700 text-white border-emerald-800';
    }
  };

  return (
    <div id="alerts-view-container" className="space-y-6">
      {/* Header card with IMD live status */}
      <div className="bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-[#F27D26] block mb-1">
            Hazard Surveillance & Early Warning
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] dark:text-white tracking-tight">
            IMD Disaster & Severe Weather Operations
          </h2>
          <p className="text-xs font-serif italic text-[#A19E95] mt-1">
            Official India Meteorological Department (IMD) & NDMA Warning System for {location.name}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right text-xs font-mono hidden sm:block">
            <span className={`font-bold block uppercase text-[10px] ${isDataUnavailable ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-700 dark:text-emerald-400'}`}>
              {isDataUnavailable ? 'IMD Gateway Unreachable' : 'Official IMD / NDMA Sync Active'}
            </span>
            <span className="text-[#A19E95] text-[10px]">
              Bulletin: {imdData?.bulletinTime ? new Date(imdData.bulletinTime).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'short', timeStyle: 'short' }) + ' IST' : 'Live Sync'}
            </span>
          </div>

          <button
            onClick={refreshWeather}
            disabled={loading}
            className="p-2.5 border border-[#E5E1DA] dark:border-[#2D2C2A] hover:border-black dark:hover:border-white text-[#1A1A1A] dark:text-white transition"
            title="Refresh official alert bulletins"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#F27D26]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Explicit Unavailability Notice when IMD data cannot be retrieved */}
      {isDataUnavailable && (
        <div id="imd-data-unavailable-card" className="p-6 bg-amber-50 dark:bg-[#201c14] border border-amber-300 dark:border-amber-800 space-y-2">
          <div className="flex items-center gap-2 text-amber-900 dark:text-amber-200">
            <Info className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <h3 className="font-serif font-bold text-lg">Official IMD warning data is currently unavailable.</h3>
          </div>
          <p className="text-xs font-serif italic text-amber-800 dark:text-amber-300 leading-relaxed pl-7">
            Official IMD warning data is currently unavailable. As per safety mandates, automated models and AI systems are strictly prohibited from synthesizing or fabricating alerts. Please check back shortly or consult your regional meteorological centre.
          </p>
        </div>
      )}

      {/* 1. District Nowcast Section (3-Hour Window) */}
      <div className="p-6 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-[#F27D26] shrink-0" />
            <div>
              <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-white">
                IMD District Nowcast (3-Hour Immediate Window)
              </h3>
              <span className="text-[10px] font-mono text-[#A19E95] uppercase">
                High-Resolution Doppler Radar & Severe Convective Cloud Surveillance
              </span>
            </div>
          </div>
          {districtNowcast && getSeverityBadge(districtNowcast.severity, districtNowcast.hasActiveNowcast ? `${districtNowcast.severity} NOWCAST` : 'GREEN: NO NOWCAST')}
        </div>

        {districtNowcast?.hasActiveNowcast ? (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
              <span className="flex items-center gap-1 text-[#1A1A1A] dark:text-white font-bold">
                <MapPin className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>Affected Location: {districtNowcast.district}, {districtNowcast.state || ''}</span>
              </span>
              <span className="text-[#A19E95]">•</span>
              <span className="flex items-center gap-1 text-[#A19E95]">
                <Clock className="w-3.5 h-3.5" />
                <span>Validity: {districtNowcast.validityRange || 'Next 3 Hours'}</span>
              </span>
              {districtNowcast.issueTime && (
                <>
                  <span className="text-[#A19E95]">•</span>
                  <span className="text-[#A19E95]">
                    Issued: {new Date(districtNowcast.issueTime).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'short', timeStyle: 'short' })} IST
                  </span>
                </>
              )}
            </div>

            <div className="p-4 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A]">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#F27D26] block mb-1">
                Hazard Event: {districtNowcast.nowcastEvent}
              </span>
              <p className="text-sm font-serif text-[#1A1A1A] dark:text-[#F5F4F0] leading-relaxed">
                {districtNowcast.warningMessage}
              </p>
            </div>

            {/* Recommended Safety Action */}
            <div className="p-4 bg-rose-50 dark:bg-[#251818] border-l-4 border-rose-600 border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-serif">
              <span className="font-mono font-bold uppercase text-[10px] text-rose-800 dark:text-rose-400 block mb-1">
                Recommended Safety Action (Official NDMA / IMD Protocol):
              </span>
              <p className="text-[#1A1A1A] dark:text-[#F5F4F0] leading-relaxed">
                {districtNowcast.recommendedAction || districtNowcast.instructions}
              </p>
            </div>
          </div>
        ) : (
          <div className="p-4 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
            <div>
              <span className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white block">
                Normal Baseline Convective Atmosphere
              </span>
              <p className="text-xs font-serif italic text-[#A19E95] mt-1 leading-relaxed">
                No localized severe convective cloud signatures (thunderstorm, lightning, squalls &gt; 50 km/h, or hail) detected for {location.city} within the current 3-hour Doppler radar window.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 2. District Warnings 5-Day Outlook Matrix */}
      {districtWarnings && (
        <div className="p-6 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#F27D26] shrink-0" />
              <div>
                <h3 className="font-serif font-bold text-lg text-[#1A1A1A] dark:text-white">
                  IMD 5-Day District Warning Matrix
                </h3>
                <span className="text-[10px] font-mono text-[#A19E95] uppercase">
                  Synoptic Medium-Range Forecast & Color-Coded Vigilance Schedule
                </span>
              </div>
            </div>
            {getSeverityBadge(districtWarnings.colorCode, districtWarnings.colorLabel)}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {districtWarnings.warnings.map((w: ImdDistrictWarningDay) => (
              <div
                key={w.day}
                className="p-3 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] flex flex-col justify-between space-y-2"
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1.5">
                    <span className="text-xs font-mono font-bold text-[#1A1A1A] dark:text-white">
                      Day {w.day}
                    </span>
                    <span className="text-[10px] font-mono text-[#A19E95]">
                      {new Date(w.date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                    </span>
                  </div>

                  <span className={`inline-block w-full text-center px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase mb-2 ${getDayColorIndicator(w.colorCode)}`}>
                    {w.colorLabel || w.colorCode}
                  </span>

                  <p className="text-xs font-serif font-bold text-[#1A1A1A] dark:text-white line-clamp-2">
                    {w.warningType}
                  </p>
                  <p className="text-[11px] font-serif text-[#A19E95] mt-1 leading-normal line-clamp-3">
                    {w.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#E5E1DA] dark:border-[#2D2C2A] text-[10px] font-mono text-[#73716A]">
                  <span className="font-bold block uppercase text-[9px] text-[#A19E95]">Action:</span>
                  <span className="line-clamp-2">{w.recommendation}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Detailed Active Alerts List */}
      <div className="space-y-4">
        <h3 className="font-serif font-bold text-xl text-[#1A1A1A] dark:text-white">
          Active Meteorological Warnings & Bulletins
        </h3>

        {alerts.length === 0 ? (
          <div className="p-10 text-center bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-3">
            <div className="w-12 h-12 border border-[#E5E1DA] dark:border-[#2D2C2A] text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-[#1A1A1A] dark:text-white text-lg">
              No Severe Weather Warnings Active
            </h4>
            <p className="text-xs font-serif italic text-[#A19E95] max-w-md mx-auto">
              All atmospheric indicators for {location.city} are currently within benign operating thresholds. Normal conditions are forecasted over the next 24 to 48 hours.
            </p>
            <span className="inline-block px-3 py-1 text-[10px] font-mono font-bold bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-emerald-700 dark:text-emerald-400 uppercase">
              IMD Status: GREEN (CLEAR)
            </span>
          </div>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.id}
              className="p-6 bg-white dark:bg-[#181816] border border-[#E5E1DA] dark:border-[#2D2C2A] space-y-4"
            >
              {/* Alert Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-serif font-bold text-xl text-[#1A1A1A] dark:text-white">
                      {alert.type}
                    </h4>
                  </div>
                  <div className="flex items-center gap-1 text-xs font-mono text-[#F27D26] mt-0.5">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    <span>Affected Location: {alert.affectedLocation}</span>
                  </div>
                </div>
                {getSeverityBadge(alert.severity, alert.severityLabel)}
              </div>

              {/* Description */}
              <p className="text-sm text-[#1A1A1A] dark:text-[#F5F4F0] leading-relaxed font-serif">
                {alert.description}
              </p>

              {/* Recommended Safety Action */}
              <div className="p-4 bg-[#FAF9F6] dark:bg-[#201F1D] border-l-4 border-[#F27D26] border-y border-r border-[#E5E1DA] dark:border-[#2D2C2A] text-xs font-serif">
                <span className="font-mono font-bold uppercase text-[10px] text-[#F27D26] block mb-1">
                  Recommended Safety Action (Official NDMA Protocol):
                </span>
                <p className="text-[#1A1A1A] dark:text-[#F5F4F0] leading-relaxed font-medium">
                  {alert.recommendedAction}
                </p>
              </div>

              {/* Alert Meta Details */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 text-[10px] font-mono text-[#A19E95] border-t border-[#E5E1DA] dark:border-[#2D2C2A]">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>Issue Time: {alert.issueTimeFormatted || new Date(alert.issueTime).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'short', timeStyle: 'short' }) + ' IST'}</span>
                  </span>
                  <span>•</span>
                  <span>Validity: {alert.validityRange || `${alert.validHours || 24} Hours`}</span>
                </div>

                <div className="font-bold uppercase text-[#1A1A1A] dark:text-white">
                  Source: {alert.source}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Safety Mandate & Official vs AI Advisory Clarification Box */}
      <div className="p-5 bg-[#FAF9F6] dark:bg-[#201F1D] border border-[#E5E1DA] dark:border-[#2D2C2A] text-xs space-y-2 font-serif text-[#A19E95]">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-[#F27D26]" />
          <p className="font-bold text-[#1A1A1A] dark:text-white font-mono uppercase text-[10px] tracking-wider">
            Operational Protocol & Safety Mandate
          </p>
        </div>
        <p className="italic leading-relaxed">
          Official disaster warnings and color codes (Red, Orange, Yellow, Green) are formulated strictly by the India Meteorological Department (IMD) and National Disaster Management Authority (NDMA). Artificial Intelligence models (such as Gemini) are explicitly prohibited from declaring, fabricating, or simulating disaster warnings. If official IMD warning feeds become unreachable, this system explicitly displays &ldquo;Official IMD warning data is currently unavailable.&rdquo; and never fabricates synthetic alerts.
        </p>
      </div>
    </div>
  );
};
