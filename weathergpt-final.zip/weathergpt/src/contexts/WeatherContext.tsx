import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  NormalizedLocation,
  NormalizedWeather,
  ImdStatusData,
  SupportedLanguage
} from '../types/weather';
import { fetchWeatherForecastApi, fetchAlertsApi, reverseGeocodeApi } from '../services/api';

interface WeatherContextType {
  location: NormalizedLocation;
  weather: NormalizedWeather | null;
  imdData: ImdStatusData | null;
  loading: boolean;
  error: string | null;
  tempUnit: 'C' | 'F';
  windUnit: 'km/h' | 'mph';
  language: SupportedLanguage;
  theme: 'light' | 'dark' | 'system';
  voiceEnabled: boolean;
  demoMode: boolean;
  setLocation: (loc: NormalizedLocation) => void;
  setTempUnit: (unit: 'C' | 'F') => void;
  setWindUnit: (unit: 'km/h' | 'mph') => void;
  setLanguage: (lang: SupportedLanguage) => void;
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  setVoiceEnabled: (enabled: boolean) => void;
  setDemoMode: (enabled: boolean) => void;
  refreshWeather: () => Promise<void>;
  useCurrentLocation: () => Promise<void>;
  formatTemp: (celsius?: number) => string;
  formatWind: (kmh?: number) => string;
}

const DEFAULT_LOCATION: NormalizedLocation = {
  city: 'Coimbatore',
  name: 'Coimbatore, Tamil Nadu, India',
  district: 'Coimbatore',
  state: 'Tamil Nadu',
  country: 'India',
  countryCode: 'IN',
  latitude: 11.0168,
  longitude: 76.9558,
  timezone: 'Asia/Kolkata'
};

const WeatherContext = createContext<WeatherContextType | undefined>(undefined);

export const WeatherProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [location, setLocationState] = useState<NormalizedLocation>(() => {
    const saved = localStorage.getItem('weathergpt_location');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return DEFAULT_LOCATION;
  });

  const [weather, setWeather] = useState<NormalizedWeather | null>(null);
  const [imdData, setImdData] = useState<ImdStatusData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [tempUnit, setTempUnitState] = useState<'C' | 'F'>(() => {
    return (localStorage.getItem('weathergpt_temp_unit') as 'C' | 'F') || 'C';
  });

  const [windUnit, setWindUnitState] = useState<'km/h' | 'mph'>(() => {
    return (localStorage.getItem('weathergpt_wind_unit') as 'km/h' | 'mph') || 'km/h';
  });

  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    return (localStorage.getItem('weathergpt_lang') as SupportedLanguage) || 'en';
  });

  const [theme, setThemeState] = useState<'light' | 'dark' | 'system'>(() => {
    return (localStorage.getItem('weathergpt_theme') as 'light' | 'dark' | 'system') || 'light';
  });

  const [voiceEnabled, setVoiceEnabledState] = useState<boolean>(() => {
    return localStorage.getItem('weathergpt_voice') !== 'false';
  });

  const [demoMode, setDemoMode] = useState<boolean>(false);

  const setLocation = useCallback((loc: NormalizedLocation) => {
    setLocationState(loc);
    localStorage.setItem('weathergpt_location', JSON.stringify(loc));
  }, []);

  const setTempUnit = useCallback((unit: 'C' | 'F') => {
    setTempUnitState(unit);
    localStorage.setItem('weathergpt_temp_unit', unit);
  }, []);

  const setWindUnit = useCallback((unit: 'km/h' | 'mph') => {
    setWindUnitState(unit);
    localStorage.setItem('weathergpt_wind_unit', unit);
  }, []);

  const setLanguage = useCallback((lang: SupportedLanguage) => {
    setLanguageState(lang);
    localStorage.setItem('weathergpt_lang', lang);
  }, []);

  const setTheme = useCallback((t: 'light' | 'dark' | 'system') => {
    setThemeState(t);
    localStorage.setItem('weathergpt_theme', t);
  }, []);

  const setVoiceEnabled = useCallback((enabled: boolean) => {
    setVoiceEnabledState(enabled);
    localStorage.setItem('weathergpt_voice', enabled ? 'true' : 'false');
  }, []);

  // Theme synchronization with document element
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else if (theme === 'light') {
      root.classList.remove('dark');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) root.classList.add('dark');
      else root.classList.remove('dark');
    }
  }, [theme]);

  // Load weather and alerts for the selected location
  const loadWeatherData = useCallback(async (loc: NormalizedLocation) => {
    setLoading(true);
    setError(null);
    try {
      const [weatherRes, alertsRes] = await Promise.all([
        fetchWeatherForecastApi(loc.latitude, loc.longitude, loc.city, loc.state, loc.district),
        fetchAlertsApi(loc.latitude, loc.longitude, loc.city, loc.state, loc.district)
      ]);

      setWeather(weatherRes);
      setImdData(alertsRes);
    } catch (err: any) {
      console.error('Weather fetching error:', err);
      setError(err.message || 'Unable to retrieve meteorological telemetry. Retrying shortly.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadWeatherData(location);
  }, [location, loadWeatherData]);

  const refreshWeather = useCallback(async () => {
    await loadWeatherData(location);
  }, [location, loadWeatherData]);

  // Geolocation detection
  const useCurrentLocation = useCallback(async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const lat = pos.coords.latitude;
          const lon = pos.coords.longitude;
          const detected = await reverseGeocodeApi(lat, lon);
          setLocation(detected);
        } catch (err) {
          console.warn('Reverse geocode failed, using raw coordinates', err);
          const rawLoc: NormalizedLocation = {
            city: 'My Location',
            name: `Current GPS (${pos.coords.latitude.toFixed(2)}°, ${pos.coords.longitude.toFixed(2)}°)`,
            country: 'India',
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            timezone: 'Asia/Kolkata'
          };
          setLocation(rawLoc);
        }
      },
      (err) => {
        setLoading(false);
        console.warn('Geolocation permission error:', err);
        setError('Location permission was denied or timed out. You can still search for any city.');
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  }, [setLocation]);

  const formatTemp = useCallback((celsius?: number): string => {
    if (celsius === undefined || isNaN(celsius)) return '--';
    if (tempUnit === 'F') {
      const fahrenheit = Math.round((celsius * 9) / 5 + 32);
      return `${fahrenheit}°F`;
    }
    return `${Math.round(celsius * 10) / 10}°C`;
  }, [tempUnit]);

  const formatWind = useCallback((kmh?: number): string => {
    if (kmh === undefined || isNaN(kmh)) return '--';
    if (windUnit === 'mph') {
      const mph = Math.round(kmh * 0.621371);
      return `${mph} mph`;
    }
    return `${kmh} km/h`;
  }, [windUnit]);

  return (
    <WeatherContext.Provider
      value={{
        location,
        weather,
        imdData,
        loading,
        error,
        tempUnit,
        windUnit,
        language,
        theme,
        voiceEnabled,
        demoMode,
        setLocation,
        setTempUnit,
        setWindUnit,
        setLanguage,
        setTheme,
        setVoiceEnabled,
        setDemoMode,
        refreshWeather,
        useCurrentLocation,
        formatTemp,
        formatWind
      }}
    >
      {children}
    </WeatherContext.Provider>
  );
};

export const useWeather = () => {
  const context = useContext(WeatherContext);
  if (!context) {
    throw new Error('useWeather must be used within a WeatherProvider');
  }
  return context;
};
